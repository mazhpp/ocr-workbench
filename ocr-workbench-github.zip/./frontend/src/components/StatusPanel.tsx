import React from "react";
import { BatchStatus, TaskStatus } from "../api";

function pct(v: number) {
  const n = Math.max(0, Math.min(1, Number.isFinite(v) ? v : 0));
  return `${Math.round(n * 100)}%`;
}

export default function StatusPanel(props: {
  batch: BatchStatus | null;
  selected: TaskStatus | null;
  onSelect: (s: TaskStatus) => void;
}) {
  const b = props.batch;
  if (!b) return <div className="status">未开始</div>;
  const items = b.items || [];
  return (
    <div className="status">
      <div className="statusTop">
        <div>批次：{b.batch_id}</div>
        <div>
          已完成 {b.done_count}/{b.ordered_file_ids.length}，成功 {b.success_count}，失败 {b.failed_count}，等待 {b.waiting_count}
        </div>
      </div>
      <div className="list">
        {items.map((it) => {
          const active = props.selected?.file_id === it.file_id;
          const icon = it.status === "处理完成" ? "✓" : it.status === "失败" ? "⚠" : it.status === "处理中" ? "…" : "";
          return (
            <button key={it.file_id} className={"rowBtn " + (active ? "active" : "")} onClick={() => props.onSelect(it)}>
              <div className="rowMain">
                <div className="rowName">{it.filename}</div>
                <div className="rowMeta">
                  <span className="tag">{icon} {it.status}</span>
                  {it.queue_position ? <span className="tag">队列:{it.queue_position}</span> : null}
                  {it.progress?.total_pages ? <span className="tag">{it.progress.current_page}/{it.progress.total_pages}</span> : null}
                  <span className="tag">{pct(it.progress?.percent || 0)}</span>
                </div>
                {it.error ? <div className="rowErr">{it.error}</div> : null}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

