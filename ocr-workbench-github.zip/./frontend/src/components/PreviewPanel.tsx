import React, { useEffect, useMemo, useState } from "react";
import { BatchStatus, TaskStatus } from "../api";

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

export default function PreviewPanel(props: {
  batch: BatchStatus | null;
  selected: TaskStatus | null;
  markdown: string;
  fetchMarkdown: (fileId: string) => Promise<string>;
  retryOne: (fileId: string) => Promise<void>;
  pageUrl: (fileId: string, pageNo: number) => string;
}) {
  const totalPages = props.selected?.progress?.total_pages || 0;
  const [page, setPage] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [pageInput, setPageInput] = useState("1");
  const [downloadBusy, setDownloadBusy] = useState(false);
  const [downloadMsg, setDownloadMsg] = useState("");
  const [downloadPct, setDownloadPct] = useState(0);

  useEffect(() => {
    setPage(1);
    setPageInput("1");
    setZoom(1);
    setDownloadMsg("");
    setDownloadPct(0);
  }, [props.selected?.file_id]);

  useEffect(() => {
    setPageInput(String(page));
  }, [page]);

  const canPage = totalPages > 0;
  const pageNo = clamp(page, 1, Math.max(1, totalPages || 1));

  const previewUrl = useMemo(() => {
    if (!props.selected) return "";
    if (!canPage) return "";
    return props.pageUrl(props.selected.file_id, pageNo);
  }, [props.selected?.file_id, pageNo, canPage]);

  function setZoomPct(pct: number) {
    setZoom(clamp(pct / 100, 0.5, 2));
  }

  function onWheel(e: React.WheelEvent) {
    if (!e.ctrlKey) return;
    e.preventDefault();
    const dir = e.deltaY > 0 ? -1 : 1;
    const step = 0.1;
    setZoom((z) => clamp(z + dir * step, 0.5, 2));
  }

  function applyPageInput() {
    const v = parseInt(pageInput || "1", 10);
    if (!Number.isFinite(v)) return;
    setPage(clamp(v, 1, Math.max(1, totalPages || 1)));
  }

  useEffect(() => {
    const t = window.setTimeout(() => applyPageInput(), 350);
    return () => window.clearTimeout(t);
  }, [pageInput]);

  function pad2(n: number) {
    return String(n).padStart(2, "0");
  }

  function timestamp(now: Date) {
    const y = now.getFullYear();
    const m = pad2(now.getMonth() + 1);
    const d = pad2(now.getDate());
    const hh = pad2(now.getHours());
    const mm = pad2(now.getMinutes());
    const ss = pad2(now.getSeconds());
    return `${y}${m}${d}_${hh}${mm}${ss}`;
  }

  function saveTextAsFile(text: string, filename: string) {
    const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  function normalizeMd(md: string) {
    const s = md ?? "";
    return s.endsWith("\n") ? s : s + "\n";
  }

  async function downloadSingle() {
    if (!props.selected) return;
    setDownloadBusy(true);
    setDownloadMsg("正在生成下载文件…");
    setDownloadPct(0);
    try {
      const now = new Date();
      let text = props.markdown;
      if (!text || props.selected.status !== "处理完成") {
        if (props.selected.status === "失败") {
          text = `## ${props.selected.filename}\n\n⚠ 失败：${props.selected.error || "未知错误"}\n`;
        } else {
          text = `## ${props.selected.filename}\n\n状态：${props.selected.status}\n`;
        }
      } else {
        text = normalizeMd(text);
      }
      setDownloadPct(40);
      saveTextAsFile(text, `OCR结果_${timestamp(now)}.md`);
      setDownloadPct(100);
      setDownloadMsg("下载完成");
    } catch (e: any) {
      setDownloadMsg(`下载失败：${String(e?.message || e)}`);
    } finally {
      window.setTimeout(() => {
        setDownloadBusy(false);
      }, 600);
    }
  }

  async function downloadMerged() {
    const b = props.batch;
    if (!b) return;
    setDownloadBusy(true);
    setDownloadMsg("正在合并生成…");
    setDownloadPct(0);
    try {
      const now = new Date();
      const items = new Map((b.items || []).map((x) => [x.file_id, x]));
      const total = b.ordered_file_ids.length || 1;
      const parts: string[] = [];
      parts.push(`# OCR结果\n\n生成时间：${now.toISOString()}\n\n`);
      for (let i = 0; i < b.ordered_file_ids.length; i++) {
        const fid = b.ordered_file_ids[i];
        const it = items.get(fid);
        const name = it?.filename || fid;
        parts.push(`---\n\n## ${name}\n\n`);
        if (!it) {
          parts.push("⚠ 未找到文件状态\n\n");
        } else if (it.status === "处理完成") {
          const md = await props.fetchMarkdown(fid);
          parts.push(normalizeMd(md));
        } else if (it.status === "失败") {
          parts.push(`⚠ 失败：${it.error || "未知错误"}\n\n`);
        } else {
          parts.push(`状态：${it.status}\n\n`);
        }
        setDownloadPct(Math.round(((i + 1) / total) * 100));
      }
      const merged = parts.join("");
      saveTextAsFile(merged, `OCR结果_${timestamp(now)}.md`);
      setDownloadMsg("下载完成");
    } catch (e: any) {
      setDownloadMsg(`下载失败：${String(e?.message || e)}`);
    } finally {
      window.setTimeout(() => setDownloadBusy(false), 600);
    }
  }

  async function downloadSeparate() {
    const b = props.batch;
    if (!b) return;
    setDownloadBusy(true);
    setDownloadMsg("正在准备多个文件下载…");
    setDownloadPct(0);
    try {
      const now = new Date();
      const ts = timestamp(now);
      const items = new Map((b.items || []).map((x) => [x.file_id, x]));
      const total = b.ordered_file_ids.length || 1;
      for (let i = 0; i < b.ordered_file_ids.length; i++) {
        const fid = b.ordered_file_ids[i];
        const it = items.get(fid);
        let md = "";
        if (!it) {
          md = `## ${fid}\n\n⚠ 未找到文件状态\n`;
        } else if (it.status === "处理完成") {
          md = await props.fetchMarkdown(fid);
        } else if (it.status === "失败") {
          md = `## ${it.filename}\n\n⚠ 失败：${it.error || "未知错误"}\n`;
        } else {
          md = `## ${it.filename}\n\n状态：${it.status}\n`;
        }
        md = normalizeMd(md);
        const idx = String(i + 1).padStart(2, "0");
        saveTextAsFile(md, `OCR结果_${ts}_${idx}.md`);
        setDownloadPct(Math.round(((i + 1) / total) * 100));
        setDownloadMsg(`已下载 ${i + 1}/${total}`);
        await new Promise((r) => window.setTimeout(r, 120));
      }
      setDownloadMsg("下载完成");
    } catch (e: any) {
      setDownloadMsg(`下载失败：${String(e?.message || e)}`);
    } finally {
      window.setTimeout(() => setDownloadBusy(false), 800);
    }
  }

  async function retrySelected() {
    if (!props.selected) return;
    setDownloadBusy(true);
    setDownloadMsg("正在提交重试…");
    setDownloadPct(0);
    try {
      await props.retryOne(props.selected.file_id);
      setDownloadPct(100);
      setDownloadMsg("已提交重试");
    } catch (e: any) {
      setDownloadMsg(`重试失败：${String(e?.message || e)}`);
    } finally {
      window.setTimeout(() => setDownloadBusy(false), 800);
    }
  }

  return (
    <div className="preview">
      <div className="previewTop">
        <div className="previewTitle">预览</div>
        <div className="controls">
          <button onClick={() => setZoomPct(50)} disabled={!props.selected}>50%</button>
          <button onClick={() => setZoom((z) => clamp(z - 0.1, 0.5, 2))} disabled={!props.selected}>-</button>
          <button onClick={() => setZoomPct(100)} disabled={!props.selected}>100%</button>
          <button onClick={() => setZoom((z) => clamp(z + 0.1, 0.5, 2))} disabled={!props.selected}>+</button>
          <button onClick={() => setZoomPct(200)} disabled={!props.selected}>200%</button>
        </div>
      </div>

      <div className="pagebar">
        <button onClick={() => setPage(1)} disabled={!canPage || pageNo === 1}>首页</button>
        <button onClick={() => setPage((p) => clamp(p - 1, 1, totalPages || 1))} disabled={!canPage || pageNo === 1}>上一页</button>
        <div className="pageIndicator">{canPage ? `${pageNo}/${totalPages}` : "—"}</div>
        <input value={pageInput} onChange={(e) => setPageInput(e.target.value)} disabled={!canPage} />
        <button onClick={() => setPage((p) => clamp(p + 1, 1, totalPages || 1))} disabled={!canPage || pageNo === totalPages}>下一页</button>
        <button onClick={() => setPage(totalPages || 1)} disabled={!canPage || pageNo === totalPages}>末页</button>
      </div>

      <div className="viewer" onWheel={onWheel}>
        {previewUrl ? (
          <div className="canvasWrap">
            <img className="pageImg" src={previewUrl} style={{ transform: `scale(${zoom})` }} />
          </div>
        ) : (
          <div className="empty">
            <div>{props.selected ? props.selected.filename : "请选择文件"}</div>
            <div className="muted">PDF/图片会显示预览页；DOCX/PPTX/XLSX/TXT 可在结果区查看提取内容</div>
          </div>
        )}
      </div>

      <div className="result">
        <div className="resultTitle">识别结果（Markdown 源码）</div>
        <div className="dlbar">
          <button onClick={downloadSingle} disabled={downloadBusy || !props.selected}>下载当前</button>
          <button onClick={downloadMerged} disabled={downloadBusy || !props.batch}>合并下载</button>
          <button onClick={downloadSeparate} disabled={downloadBusy || !props.batch}>单独下载</button>
          <button onClick={retrySelected} disabled={downloadBusy || !props.selected || props.selected.status !== "失败"}>重试当前</button>
          <div className="dlmsg">
            {downloadBusy ? `进度 ${downloadPct}%` : ""}
            {downloadMsg ? ` ${downloadMsg}` : ""}
          </div>
        </div>
        <textarea value={props.markdown || ""} readOnly rows={14} />
      </div>
    </div>
  );
}

