import React from "react";
import { useDropzone } from "react-dropzone";

export default function UploadPanel(props: { onEnqueue: (files: File[]) => void; disabled: boolean }) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    disabled: props.disabled,
    multiple: true,
    onDrop: (accepted) => {
      props.onEnqueue(accepted);
    },
  });

  return (
    <div className="upload">
      <div className={"drop " + (isDragActive ? "active" : "") + (props.disabled ? " disabled" : "")} {...getRootProps()}>
        <input {...getInputProps()} />
        <div className="dropTitle">拖拽文件到此处或点击选择</div>
        <div className="dropHint">支持 PDF / 图片 / TXT / DOCX / PPTX / XLSX</div>
      </div>
    </div>
  );
}

