import React, { useEffect, useMemo, useState } from "react";
import { BatchStatus, ClientConfig, enqueueFiles, getBatch, getResultMarkdown, login, previewPageUrl, retryFile, TaskStatus } from "./api";
import UploadPanel from "./components/UploadPanel";
import PreviewPanel from "./components/PreviewPanel";
import StatusPanel from "./components/StatusPanel";

type OcrUiConfig = {
  apiBase: string;
  username: string;
  password: string;
  token: string;
  priority: number;
  serviceType: string;
  apiBaseHeader: string;
  model: string;
  apiKey: string;
  temperature: string;
  prompt: string;
};

const defaultCfg: OcrUiConfig = {
  apiBase: "http://localhost:9000",
  username: "admin",
  password: "admin",
  token: "",
  priority: 5,
  serviceType: "lmstudio",
  apiBaseHeader: "http://localhost:1234/v1",
  model: "Qwen2-VL-7B-Instruct",
  apiKey: "",
  temperature: "0.1",
  prompt: "",
};

export default function App() {
  const [cfg, setCfg] = useState<OcrUiConfig>(defaultCfg);
  const [batch, setBatch] = useState<BatchStatus | null>(null);
  const [selected, setSelected] = useState<TaskStatus | null>(null);
  const [md, setMd] = useState<string>("");
  const [err, setErr] = useState<string>("");

  const client: ClientConfig | null = useMemo(() => {
    if (!cfg.token) return null;
    return {
      apiBase: cfg.apiBase,
      token: cfg.token,
      ocrHeaders: {
        "x-ocr-service-type": cfg.serviceType,
        "x-ocr-api-base": cfg.apiBaseHeader,
        "x-ocr-api-key": cfg.apiKey,
        "x-ocr-model": cfg.model,
        "x-ocr-temperature": cfg.temperature,
        "x-ocr-prompt": cfg.prompt,
      },
    };
  }, [cfg]);

  async function doLogin() {
    setErr("");
    try {
      const r = await login(cfg.apiBase, cfg.username, cfg.password);
      setCfg((s) => ({ ...s, token: r.access_token }));
    } catch (e: any) {
      setErr(String(e?.message || e));
    }
  }

  async function onEnqueue(files: File[]) {
    setErr("");
    if (!client) {
      setErr("请先登录");
      return;
    }
    try {
      const r = await enqueueFiles(client, files, cfg.priority);
      setBatch({ batch_id: r.batch_id, ordered_file_ids: r.file_ids, done_count: 0, success_count: 0, failed_count: 0, waiting_count: r.file_ids.length, failed: [], items: [] });
      setSelected(null);
      setMd("");
    } catch (e: any) {
      setErr(String(e?.message || e));
    }
  }

  useEffect(() => {
    if (!client || !batch?.batch_id) return;
    let alive = true;
    const tick = async () => {
      try {
        const b = await getBatch(client, batch.batch_id);
        if (!alive) return;
        setBatch(b);
        const cur = selected?.file_id ? b.items.find((x) => x.file_id === selected.file_id) : null;
        if (cur) setSelected(cur);
      } catch {}
    };
    tick();
    const t = window.setInterval(tick, 800);
    return () => {
      alive = false;
      window.clearInterval(t);
    };
  }, [client, batch?.batch_id, selected?.file_id]);

  useEffect(() => {
    if (!client || !selected) return;
    if (selected.status !== "处理完成") return;
    getResultMarkdown(client, selected.file_id)
      .then((t) => setMd(t))
      .catch(() => {});
  }, [client, selected?.file_id, selected?.status]);

  return (
    <div className="app">
      <header className="top">
        <div className="title">OCR 批量识别</div>
        <div className="row">
          <input value={cfg.apiBase} onChange={(e) => setCfg((s) => ({ ...s, apiBase: e.target.value }))} placeholder="API Base" />
          <input value={cfg.username} onChange={(e) => setCfg((s) => ({ ...s, username: e.target.value }))} placeholder="用户名" />
          <input value={cfg.password} onChange={(e) => setCfg((s) => ({ ...s, password: e.target.value }))} placeholder="密码" type="password" />
          <button onClick={doLogin} disabled={!!cfg.token}>登录</button>
          <div className="token">{cfg.token ? "已登录" : "未登录"}</div>
        </div>
        <div className="row">
          <select value={cfg.priority} onChange={(e) => setCfg((s) => ({ ...s, priority: Number(e.target.value) }))}>
            <option value={9}>最高优先级</option>
            <option value={7}>高</option>
            <option value={5}>中</option>
            <option value={3}>低</option>
            <option value={1}>最低</option>
          </select>
          <input value={cfg.serviceType} onChange={(e) => setCfg((s) => ({ ...s, serviceType: e.target.value }))} placeholder="服务类型" />
          <input value={cfg.apiBaseHeader} onChange={(e) => setCfg((s) => ({ ...s, apiBaseHeader: e.target.value }))} placeholder="模型 API Base" />
          <input value={cfg.model} onChange={(e) => setCfg((s) => ({ ...s, model: e.target.value }))} placeholder="模型" />
          <input value={cfg.temperature} onChange={(e) => setCfg((s) => ({ ...s, temperature: e.target.value }))} placeholder="temperature" />
          <input value={cfg.prompt} onChange={(e) => setCfg((s) => ({ ...s, prompt: e.target.value }))} placeholder="prompt" />
        </div>
        {err ? <div className="err">{err}</div> : null}
      </header>

      <main className="grid">
        <section className="panel">
          <UploadPanel onEnqueue={onEnqueue} disabled={!cfg.token} />
          <StatusPanel batch={batch} selected={selected} onSelect={setSelected} />
        </section>
        <section className="panel">
          <PreviewPanel
            batch={batch}
            selected={selected}
            markdown={md}
            fetchMarkdown={async (fileId) => {
              if (!client) throw new Error("not_logged_in");
              return await getResultMarkdown(client, fileId);
            }}
            retryOne={async (fileId) => {
              if (!client) throw new Error("not_logged_in");
              await retryFile(client, fileId);
            }}
            pageUrl={(fileId, pageNo) => (client ? previewPageUrl(client, fileId, pageNo) : "")}
          />
        </section>
      </main>
    </div>
  );
}

