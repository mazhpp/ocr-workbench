export type LoginResponse = { access_token: string; token_type: string };

export type TaskProgress = {
  percent: number;
  current_page: number;
  total_pages: number;
  eta_seconds?: number | null;
};

export type TaskStatus = {
  file_id: string;
  filename: string;
  status: string;
  error: string;
  progress: TaskProgress;
  queue_position?: number | null;
  created_at?: number | null;
  started_at?: number | null;
  finished_at?: number | null;
};

export type BatchStatus = {
  batch_id: string;
  ordered_file_ids: string[];
  done_count: number;
  success_count: number;
  failed_count: number;
  running_file_id?: string | null;
  waiting_count: number;
  failed: TaskStatus[];
  items: TaskStatus[];
};

export type ClientConfig = {
  apiBase: string;
  token: string;
  ocrHeaders: Record<string, string>;
};

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `${res.status}`);
  }
  return (await res.json()) as T;
}

export async function login(apiBase: string, username: string, password: string): Promise<LoginResponse> {
  const res = await fetch(`${apiBase}/v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  return json<LoginResponse>(res);
}

export async function enqueueFiles(cfg: ClientConfig, files: File[], priority: number): Promise<{ batch_id: string; file_ids: string[] }> {
  const form = new FormData();
  for (const f of files) form.append("files", f);
  const url = new URL(`${cfg.apiBase}/v1/files:enqueue`);
  url.searchParams.set("priority", String(priority));
  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { Authorization: `Bearer ${cfg.token}`, ...cfg.ocrHeaders },
    body: form,
  });
  return json(res);
}

export async function getBatch(cfg: ClientConfig, batchId: string): Promise<BatchStatus> {
  const res = await fetch(`${cfg.apiBase}/v1/batches/${batchId}`, {
    headers: { Authorization: `Bearer ${cfg.token}` },
  });
  return json<BatchStatus>(res);
}

export function previewPageUrl(cfg: ClientConfig, fileId: string, pageNo: number): string {
  return `${cfg.apiBase}/v1/files/${fileId}/preview/pages/${pageNo}`;
}

export async function getResultMarkdown(cfg: ClientConfig, fileId: string): Promise<string> {
  const res = await fetch(`${cfg.apiBase}/v1/files/${fileId}/result`, {
    headers: { Authorization: `Bearer ${cfg.token}` },
  });
  if (!res.ok) throw new Error(String(res.status));
  return await res.text();
}

export async function retryFile(cfg: ClientConfig, fileId: string): Promise<void> {
  const res = await fetch(`${cfg.apiBase}/v1/files/${fileId}:retry`, {
    method: "POST",
    headers: { Authorization: `Bearer ${cfg.token}`, ...cfg.ocrHeaders },
  });
  if (!res.ok) throw new Error(String(res.status));
}

