import io
import re
import zipfile
from xml.sax.saxutils import escape


def safe_basename(name: str) -> str:
    s = "" if name is None else str(name)
    s = re.sub(r"[^\w ._-]+", "_", s, flags=re.UNICODE).strip()
    s = re.sub(r"\s+", " ", s).strip()
    return s or "ocr_result"


def strip_html(md: str) -> str:
    if not md:
        return ""
    text = str(md).replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</p\s*>", "\n\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    return text


def markdown_bytes(md: str) -> bytes:
    return (md or "").encode("utf-8")


def _split_blocks(md: str) -> list[dict]:
    s = strip_html(md)
    lines = s.split("\n")
    blocks: list[dict] = []
    buf: list[str] = []
    in_code = False
    code_buf: list[str] = []

    def flush_paragraph():
        nonlocal buf
        if not buf:
            return
        text = " ".join([x.strip() for x in buf if x.strip()]).strip()
        if text:
            blocks.append({"type": "p", "text": text})
        buf = []

    def flush_code():
        nonlocal code_buf
        text = "\n".join(code_buf).rstrip("\n")
        if text.strip():
            blocks.append({"type": "code", "text": text})
        code_buf = []

    for raw in lines:
        line = raw.rstrip("\n")
        if re.match(r"^\s*(`{3,}|~{3,})", line):
            if in_code:
                flush_code()
                in_code = False
            else:
                flush_paragraph()
                in_code = True
            continue
        if in_code:
            code_buf.append(line)
            continue
        if not line.strip():
            flush_paragraph()
            continue
        m = re.match(r"^\s*(#{1,6})\s+(.+?)\s*$", line)
        if m:
            flush_paragraph()
            blocks.append({"type": "h", "level": len(m.group(1)), "text": m.group(2).strip()})
            continue
        m = re.match(r"^\s*([-*+])\s+(.+?)\s*$", line)
        if m:
            flush_paragraph()
            blocks.append({"type": "li", "text": m.group(2).strip()})
            continue
        buf.append(line)

    if in_code:
        flush_code()
    flush_paragraph()
    return blocks


def _p(text: str, style: str | None = None, mono: bool = False, preserve: bool = False) -> str:
    txt = escape(text or "")
    space = ' xml:space="preserve"' if preserve else ""
    ppr = f'<w:pPr><w:pStyle w:val="{escape(style)}"/></w:pPr>' if style else ""
    rpr = ""
    if mono:
        rpr = (
            "<w:rPr>"
            '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="Consolas"/>'
            "</w:rPr>"
        )
    return f"<w:p>{ppr}<w:r>{rpr}<w:t{space}>{txt}</w:t></w:r></w:p>"


def _code_block(text: str) -> str:
    parts = []
    lines = (text or "").split("\n")
    for i, ln in enumerate(lines):
        t = escape(ln)
        br = "<w:br/>" if i < len(lines) - 1 else ""
        parts.append(f'<w:r><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="Consolas"/></w:rPr><w:t xml:space="preserve">{t}</w:t>{br}</w:r>')
    return f"<w:p><w:pPr><w:spacing w:before='120' w:after='120'/></w:pPr>{''.join(parts)}</w:p>"


def docx_bytes_from_markdown(md: str, title: str | None = None) -> bytes:
    blocks = _split_blocks(md or "")
    body = []
    if title:
        body.append(_p(str(title), style="Title"))
    for b in blocks:
        t = b.get("type")
        if t == "h":
            level = int(b.get("level") or 1)
            level = max(1, min(6, level))
            style = "Heading1" if level == 1 else "Heading2" if level == 2 else "Heading3"
            body.append(_p(str(b.get("text") or ""), style=style))
        elif t == "li":
            body.append(_p(f"• {str(b.get('text') or '')}"))
        elif t == "code":
            body.append(_code_block(str(b.get("text") or "")))
        else:
            body.append(_p(str(b.get("text") or "")))

    document_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        "<w:body>"
        + "".join(body)
        + "<w:sectPr/>"
        + "</w:body></w:document>"
    )

    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
        "</Types>"
    )

    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        "</Relationships>"
    )

    doc_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        "</Relationships>"
    )

    styles = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>'
        '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/></w:style>'
        '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/></w:style>'
        '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/></w:style>'
        '<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/></w:style>'
        "</w:styles>"
    )

    bio = io.BytesIO()
    with zipfile.ZipFile(bio, mode="w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document_xml)
        z.writestr("word/_rels/document.xml.rels", doc_rels)
        z.writestr("word/styles.xml", styles)
    return bio.getvalue()

