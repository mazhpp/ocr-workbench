import os


def delete_files_in_dir(dir_path: str) -> int:
    if not dir_path or not os.path.exists(dir_path):
        return 0
    removed = 0
    for name in os.listdir(dir_path):
        fp = os.path.join(dir_path, name)
        if os.path.isfile(fp):
            try:
                os.remove(fp)
                removed += 1
            except Exception:
                pass
    return removed

