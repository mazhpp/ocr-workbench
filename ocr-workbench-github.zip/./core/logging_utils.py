import logging
import os


_CONFIGURED = False


def get_logger(name: str) -> logging.Logger:
    global _CONFIGURED
    if not _CONFIGURED:
        os.makedirs("logs", exist_ok=True)
        root = logging.getLogger()
        root.setLevel(logging.INFO)

        fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")

        file_handler = logging.FileHandler(os.path.join("logs", "app.log"), encoding="utf-8")
        file_handler.setFormatter(fmt)
        root.addHandler(file_handler)

        _CONFIGURED = True

    return logging.getLogger(name)

