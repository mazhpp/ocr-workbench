import time


def quality_metrics(text: str) -> dict:
    s = text or ""
    s = s.strip()
    char_count = len(s)
    line_count = 0 if not s else s.count("\n") + 1
    digits = sum(1 for c in s if c.isdigit())
    letters = sum(1 for c in s if ("a" <= c.lower() <= "z"))
    cjk = sum(1 for c in s if "\u4e00" <= c <= "\u9fff")
    spaces = sum(1 for c in s if c.isspace())
    symbols = max(0, char_count - digits - letters - cjk - spaces)

    score = 0
    if char_count >= 20:
        score += 35
    elif char_count >= 10:
        score += 20
    elif char_count >= 1:
        score += 10

    if line_count >= 2:
        score += 15
    if (letters + cjk) >= 10:
        score += 20
    if symbols <= max(5, char_count * 0.25):
        score += 20
    if "�" not in s:
        score += 10

    score = max(0, min(100, int(score)))
    if score >= 80:
        level = "高"
    elif score >= 50:
        level = "中"
    else:
        level = "低"

    issues = []
    if char_count == 0:
        issues.append("结果为空")
    if char_count > 0 and char_count < 10:
        issues.append("内容较短")
    if "Unexpected endpoint" in s or "endpoint or method" in s:
        issues.append("服务端点错误提示")
    if "error" in s.lower() and "{" in s and "}" in s:
        issues.append("疑似错误信息")

    return {
        "score": score,
        "level": level,
        "char_count": char_count,
        "line_count": line_count,
        "timestamp": time.time(),
        "issues": issues,
    }

