def ensure_selected_file(
    batch_run_id: str,
    selected_run_id: str,
    selected_file_id: str,
    file_ids_in_order: list[str],
) -> tuple[str, str]:
    run_id = batch_run_id or ""
    if not file_ids_in_order:
        return run_id, ""

    if selected_run_id != run_id:
        return run_id, file_ids_in_order[0]

    if selected_file_id in file_ids_in_order:
        return selected_run_id, selected_file_id

    return selected_run_id, file_ids_in_order[0]

