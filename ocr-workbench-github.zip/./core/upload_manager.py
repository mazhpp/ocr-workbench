import datetime
import re


def safe_filename(name: str) -> str:
    s = "" if name is None else str(name)
    s = re.sub(r"[^\w ._-]+", "_", s, flags=re.UNICODE).strip()
    return s or "file"


def record_signature(name: str, size: int) -> str:
    return f"{str(name or '')}\0{int(size or 0)}"


def is_duplicate_name_size(active_records: dict, removed_records: dict, name: str, size: int) -> bool:
    sig = record_signature(name, size)
    for r in (active_records or {}).values():
        if record_signature(r.get("name", ""), int(r.get("size", 0) or 0)) == sig:
            return True
    for r in (removed_records or {}).values():
        if record_signature(r.get("name", ""), int(r.get("size", 0) or 0)) == sig:
            return True
    return False


def photo_basename(now: datetime.datetime | None = None) -> str:
    t = now or datetime.datetime.now()
    return t.strftime("photo_%Y%m%d_%H%M%S")

