import os
import json
import datetime
import logging

HISTORY_DIR = "history"
LOG_DIR = "logs"
MAX_HISTORY_RECORDS = 500

class HistoryManager:
    def __init__(self):
        if not os.path.exists(HISTORY_DIR):
            os.makedirs(HISTORY_DIR)
        if not os.path.exists(LOG_DIR):
            os.makedirs(LOG_DIR)
        self._logger = logging.getLogger("history")
        if not self._logger.handlers:
            handler = logging.FileHandler(os.path.join(LOG_DIR, "app.log"), encoding="utf-8")
            formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s")
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)
            self._logger.setLevel(logging.INFO)

    def _summarize(self, content, max_len=80):
        if not content:
            return ""
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        text = lines[0] if lines else ""
        if len(text) > max_len:
            return text[: max_len - 1] + "…"
        return text

    def _cleanup_old_records(self):
        try:
            files = [f for f in os.listdir(HISTORY_DIR) if f.endswith(".json")]
            if len(files) <= MAX_HISTORY_RECORDS:
                return
            files.sort(reverse=True)
            to_delete = files[MAX_HISTORY_RECORDS:]
            for filename in to_delete:
                file_path = os.path.join(HISTORY_DIR, filename)
                try:
                    os.remove(file_path)
                except Exception as e:
                    self._logger.warning(f"delete history failed: {filename} - {e}")
        except Exception as e:
            self._logger.warning(f"cleanup history failed: {e}")

    def save_history(self, file_name, content):
        """
        Save OCR result to a JSON file.
        """
        now = datetime.datetime.now()
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        # Ensure file_name is safe
        safe_name = "".join([c for c in file_name if c.isalnum() or c in "._- "])
        history_id = f"{timestamp}_{safe_name}"
        
        record = {
            "id": history_id,
            "file_name": file_name,
            "timestamp": timestamp,
            "created_at": now.isoformat(timespec="seconds"),
            "content": content,
            "display_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "summary": self._summarize(content),
        }
        
        file_path = os.path.join(HISTORY_DIR, f"{history_id}.json")
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(record, f, ensure_ascii=False, indent=2)
            self._cleanup_old_records()
        except Exception as e:
            self._logger.error(f"save history failed: {history_id} - {e}")
            raise
            
        return record

    def get_history_list(self):
        """
        Get all history records sorted by timestamp (newest first).
        """
        records = []
        if not os.path.exists(HISTORY_DIR):
            return []
            
        for filename in os.listdir(HISTORY_DIR):
            if filename.endswith(".json"):
                file_path = os.path.join(HISTORY_DIR, filename)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        record = json.load(f)
                        if "summary" not in record:
                            record["summary"] = self._summarize(record.get("content", ""))
                        records.append(record)
                except Exception as e:
                    self._logger.warning(f"read history failed: {filename} - {e}")
                    continue
        
        # Sort by timestamp descending
        records.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        return records

    def delete_history(self, history_id):
        """
        Delete a specific history record.
        """
        file_path = os.path.join(HISTORY_DIR, f"{history_id}.json")
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        return False

    def delete_all_history(self):
        """
        Delete all history records.
        """
        if not os.path.exists(HISTORY_DIR):
            return 0
        deleted = 0
        for filename in list(os.listdir(HISTORY_DIR)):
            if not filename.endswith(".json"):
                continue
            file_path = os.path.join(HISTORY_DIR, filename)
            try:
                os.remove(file_path)
                deleted += 1
            except Exception as e:
                self._logger.warning(f"delete history failed: {filename} - {e}")
        return deleted
