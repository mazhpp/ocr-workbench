from core.logging_utils import get_logger
from core.model_adapters import AdapterRegistry, ModelDiagnostics, normalize_base_url


log = get_logger(__name__)


class LLMClient:
    def __init__(self, base_url: str, api_key: str, service_type: str = "auto"):
        self.base_url_input = base_url or ""
        self.base_url = normalize_base_url(base_url)
        self.service_type = service_type or "auto"
        self.adapter = AdapterRegistry.create(self.base_url, api_key, service_type=self.service_type)

    def get_service_type(self) -> str:
        return getattr(self.adapter, "service_type", "unknown")

    def list_models_with_diagnostics(self, timeout_s: float = 15.0) -> tuple[list[str], ModelDiagnostics]:
        models, diag = self.adapter.list_models(timeout_s=timeout_s)
        if diag.last_error:
            log.warning(
                "list_models failed service=%s base=%s error=%s detail=%s",
                diag.service_type,
                diag.base_url_normalized,
                diag.last_error,
                (diag.last_error_detail or "")[:300],
            )
        return models, diag

    def list_models(self, timeout_s: float = 15.0) -> list[str]:
        models, _ = self.list_models_with_diagnostics(timeout_s=timeout_s)
        return models

    def ocr_request(self, prompt: str, image_base64: str, model: str, temperature: float = 0.1) -> str:
        try:
            return self.adapter.ocr(prompt=prompt, image_base64=image_base64, model=model, temperature=temperature)
        except Exception as e:
            log.error("ocr_request failed service=%s base=%s err=%s", self.get_service_type(), self.base_url, str(e))
            raise
