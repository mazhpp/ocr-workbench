import os

from core.file_store import begin_delete_op, finalize_delete, get_files, rollback_delete


def _safe_remove(p: str, allowed_roots: list[str]) -> bool:
    if not p:
        return False
    ap = os.path.abspath(p)
    for root in allowed_roots:
        base = os.path.abspath(root) + os.sep
        if ap.startswith(base):
            if os.path.exists(ap):
                os.remove(ap)
            return True
    return False


def hard_delete(
    ids: list[str],
    allowed_roots: list[str] | None = None,
    db_path: str | None = None,
    cancel_task=None,
    clear_tasks=None,
) -> tuple[bool, str]:
    ids = [str(x) for x in (ids or []) if str(x)]
    if not ids:
        return True, ""
    allowed = allowed_roots or ["uploads", "cache"]
    op_id = begin_delete_op(ids, db_path)
    try:
        rows = get_files(ids, db_path) or []
        if callable(cancel_task):
            for r in rows:
                rid = str(r.get("id") or "")
                if rid:
                    cancel_task(rid)
        if callable(clear_tasks):
            clear_tasks(ids)
        for r in rows:
            _safe_remove(str(r.get("path") or ""), allowed)
        finalize_delete(op_id, db_path)
        return True, ""
    except Exception as e:
        rollback_delete(op_id, db_path)
        return False, str(e)

