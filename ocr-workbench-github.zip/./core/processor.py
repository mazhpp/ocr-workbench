import fitz  # PyMuPDF
from PIL import Image
import io
import base64
import re

class FileProcessor:
    @staticmethod
    def pdf_page_count(file_bytes):
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        n = len(doc)
        doc.close()
        return n

    @staticmethod
    def pdf_page_to_image(file_bytes, page_num, zoom=2.0):
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            n = len(doc)
            idx = int(page_num or 0)
            if n <= 0:
                return None
            if idx < 0:
                idx = 0
            if idx >= n:
                idx = n - 1
            page = doc.load_page(idx)
            mat = fitz.Matrix(float(zoom or 2.0), float(zoom or 2.0))
            pix = page.get_pixmap(matrix=mat)
            return Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        finally:
            doc.close()

    @staticmethod
    def process_pdf(file_bytes):
        """
        Convert PDF pages to images.
        Returns a list of PIL Images.
        """
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        images = []
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            # Zoom to improve OCR accuracy
            zoom = 2.0 
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            images.append(img)
        return images

    @staticmethod
    def process_image(file_bytes):
        """
        Process a single image file.
        Returns a list containing one PIL Image.
        """
        image = Image.open(io.BytesIO(file_bytes))
        # Ensure image is in RGB mode
        if image.mode != "RGB":
            image = image.convert("RGB")
        return [image]

    @staticmethod
    def image_to_base64(image):
        """
        Convert PIL Image to Base64 string.
        """
        buffered = io.BytesIO()
        image.save(buffered, format="JPEG")
        return base64.b64encode(buffered.getvalue()).decode("utf-8")

    @staticmethod
    def clean_text(text):
        """
        Post-process OCR text to ensure CommonMark compliance.
        """
        if not text:
            return ""

        text = text.replace("\r\n", "\n").replace("\r", "\n")

        fence = re.match(r"^\s*```(markdown|md|text|plaintext)\s*\n([\s\S]*?)\n```\s*$", text, flags=re.IGNORECASE)
        if fence:
            text = fence.group(2)

        def looks_structured(s: str) -> bool:
            if re.search(r"(^|\n)\s*```", s):
                return True
            if re.search(r"(^|\n)\s{0,3}#{1,6}\s+\S", s):
                return True
            if re.search(r"(^|\n)\s*>+\s*\S", s):
                return True
            if re.search(r"(^|\n)\s*([-*+])\s+\S", s):
                return True
            if re.search(r"(^|\n)\s*\d+\.\s+\S", s):
                return True
            if re.search(r"(^|\n)\s*\|.+\|\s*$", s):
                return True
            return False

        if looks_structured(text):
            return text

        lines = text.split("\n")
        merged = []
        i = 0
        end_punct = set("。！？!?；;：:。.）)】]」》”\"'")
        while i < len(lines):
            line = lines[i]
            if line == "":
                merged.append(line)
                i += 1
                continue
            if i + 1 >= len(lines):
                merged.append(line)
                break
            nxt = lines[i + 1]
            if nxt == "":
                merged.append(line)
                i += 1
                continue
            if re.match(r"^\s{4,}|\t", line) or re.match(r"^\s{4,}|\t", nxt):
                merged.append(line)
                i += 1
                continue
            if re.match(r"^\s*(#{1,6}\s+|[-*+]\s+|\d+\.\s+|>+\s+|\|)", line) or re.match(
                r"^\s*(#{1,6}\s+|[-*+]\s+|\d+\.\s+|>+\s+|\|)", nxt
            ):
                merged.append(line)
                i += 1
                continue
            last = line[-1]
            if last in end_punct:
                merged.append(line)
                i += 1
                continue
            if line.endswith("-") and not line.endswith("--"):
                merged.append(line[:-1] + (nxt.lstrip()))
                i += 2
                continue
            merged.append(line + " " + nxt.lstrip())
            i += 2

        return "\n".join(merged)
