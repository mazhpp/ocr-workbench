import re


MODEL_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,127}$")

ALLOWED_MODEL_CHARS_RE = re.compile(r"[^a-zA-Z0-9._:/-]+")


def sanitize_model_name(raw: str, max_len: int = 128) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    s = ALLOWED_MODEL_CHARS_RE.sub("", s)
    if not s:
        return ""
    while s and not s[0].isalnum():
        s = s[1:]
    if max_len and len(s) > max_len:
        s = s[:max_len]
    return s


def validate_model_name(name: str) -> tuple[bool, str]:
    s = (name or "").strip()
    if not s:
        return False, "模型名称为空"
    if len(s) > 128:
        return False, "模型名称过长"
    if not MODEL_NAME_RE.match(s):
        return False, "模型名称格式不正确（仅允许字母数字及 . _ : / -）"
    return True, ""


def build_diagnostic_report(
    *,
    service_type: str,
    api_base: str,
    model_name: str,
    model_list: list[str] | None,
    last_diag: dict | None,
) -> dict:
    model_list = model_list or []
    last_diag = last_diag or {}
    ok_model, model_err = validate_model_name(model_name) if (model_name or "").strip() else (False, "模型名称为空")

    last_error = (last_diag.get("last_error") or "").strip()
    last_detail = (last_diag.get("last_error_detail") or "").strip()
    base_norm = (last_diag.get("base_url_normalized") or api_base or "").strip()

    can_connect = bool(model_list) and not last_error
    model_in_list = (model_name or "").strip() in set(model_list)

    status = "ok"
    if not can_connect:
        status = "connect_error"
    if not ok_model:
        status = "model_invalid"
    if can_connect and ok_model and (model_list and not model_in_list):
        status = "model_not_found"

    suggestions = []
    if status in {"connect_error"}:
        if service_type == "lmstudio" and "/v1" not in (api_base or ""):
            suggestions.append("LM Studio 通常需要以 /v1 结尾的 API 地址（例如 http://localhost:1234/v1）")
        suggestions.append("确认服务已启动且 API 地址可访问")
        suggestions.append("点击“一键重试”重新测试连接并拉取模型列表")
    if status == "model_invalid":
        suggestions.append("在“手动输入模型名”中填写正确模型名称")
        suggestions.append("或从上方模型列表选择一个模型")
    if status == "model_not_found":
        suggestions.append("当前模型不在服务端返回的模型列表中，请重新选择或手动输入正确名称")
        suggestions.append("点击“一键重试”刷新模型列表后再尝试")

    if status == "ok":
        suggestions.append("模型状态正常，可开始 OCR")

    report = {
        "model_load_status": "成功" if can_connect else "失败",
        "connect_test": {
            "ok": can_connect,
            "service_type": service_type,
            "api_base": base_norm or api_base,
            "models_count": len(model_list),
        },
        "model_name": {
            "value": (model_name or "").strip(),
            "valid": ok_model,
            "in_list": model_in_list if model_list else None,
            "error": model_err if not ok_model else "",
        },
        "error_detail": {"code": last_error, "detail": last_detail},
        "suggestions": suggestions,
        "ready_for_ocr": bool(can_connect and ok_model and (not model_list or model_in_list)),
        "status": status,
    }
    return report
