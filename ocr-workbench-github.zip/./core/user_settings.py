import json
import os
from typing import Any


def _settings_path() -> str:
    os.makedirs("data", exist_ok=True)
    return os.path.join("data", "user_settings.json")


def load_user_settings() -> dict[str, Any]:
    path = _settings_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def save_user_settings(settings: dict[str, Any]):
    path = _settings_path()
    tmp = f"{path}.tmp"
    payload = settings if isinstance(settings, dict) else {}
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _str_map(obj: Any) -> dict[str, str]:
    if not isinstance(obj, dict):
        return {}
    out: dict[str, str] = {}
    for k, v in obj.items():
        kk = str(k).strip()
        vv = str(v).strip()
        if kk and vv:
            out[kk] = vv
    return out


def normalize_user_settings(obj: Any) -> dict[str, Any]:
    if not isinstance(obj, dict):
        return {}
    out: dict[str, Any] = {}
    stype = str(obj.get("service_type", "") or "").strip().lower()
    if stype:
        out["service_type"] = stype
    out["api_url_map"] = _str_map(obj.get("api_url_map"))
    out["model_map"] = _str_map(obj.get("model_map"))
    try:
        temp = float(obj.get("temperature", 0.1))
        if temp < 0.0:
            temp = 0.0
        if temp > 1.0:
            temp = 1.0
        out["temperature"] = temp
    except Exception:
        pass
    task_type = str(obj.get("task_type", "") or "").strip()
    if task_type:
        out["task_type"] = task_type
    prompt = str(obj.get("prompt", "") or "")
    if prompt:
        out["prompt"] = prompt
    return out

