import os
import time
from dataclasses import dataclass, field
from typing import Any

from openai import OpenAI

from core.http_json import request_json
from core.logging_utils import get_logger


log = get_logger(__name__)


@dataclass
class ModelDiagnostics:
    service_type: str
    base_url_input: str
    base_url_normalized: str
    probes: list[dict[str, Any]] = field(default_factory=list)
    last_error: str = ""
    last_error_detail: str = ""


def normalize_base_url(url: str) -> str:
    u = (url or "").strip()
    while u.endswith("/"):
        u = u[:-1]
    return u


def ensure_v1_base(url: str) -> str:
    u = normalize_base_url(url)
    lower = u.lower()
    if lower.endswith("/v1") or "/v1/" in lower:
        return u
    return _join(u, "/v1")


def _join(base: str, path: str) -> str:
    b = base.rstrip("/")
    p = path if path.startswith("/") else "/" + path
    return b + p


def _mask_url(u: str) -> str:
    return u


def _sleep_backoff(attempt: int):
    time.sleep(min(4.0, 0.4 * (2**attempt)))


class BaseAdapter:
    service_type = "base"

    def __init__(self, base_url: str, api_key: str | None):
        self.base_url_input = base_url or ""
        self.base_url = normalize_base_url(base_url)
        self.api_key = api_key or ""

    @classmethod
    def detect(cls, base_url: str) -> bool:
        return False

    def list_models(self, timeout_s: float = 15.0) -> tuple[list[str], ModelDiagnostics]:
        raise NotImplementedError

    def ocr(self, prompt: str, image_base64: str, model: str, temperature: float) -> str:
        raise NotImplementedError


class OllamaAdapter(BaseAdapter):
    service_type = "ollama"

    @classmethod
    def detect(cls, base_url: str) -> bool:
        u = normalize_base_url(base_url).lower()
        if ":11434" in u or u.endswith(":11434"):
            return True
        if "/api" in u:
            return True
        return False

    def _base_no_api(self) -> str:
        u = self.base_url
        if u.lower().endswith("/api"):
            return u[:-4]
        return u

    def list_models(self, timeout_s: float = 15.0) -> tuple[list[str], ModelDiagnostics]:
        diag = ModelDiagnostics(
            service_type=self.service_type,
            base_url_input=self.base_url_input,
            base_url_normalized=self.base_url,
        )
        url = _join(self._base_no_api(), "/api/tags")
        try:
            delay_ms = int(os.getenv("OCRWB_MODEL_PROBE_DELAY_MS", "0") or "0")
        except Exception:
            delay_ms = 0
        if delay_ms > 0:
            time.sleep(min(3.0, max(0.0, delay_ms / 1000.0)))
        r = request_json("GET", url, timeout_s=float(timeout_s or 15.0))
        diag.probes.append({"method": "GET", "url": _mask_url(url), "ok": r.ok, "status": r.status, "error": r.error})
        if not r.ok:
            diag.last_error = "ollama_list_models_failed"
            diag.last_error_detail = (r.text or r.error or "")[:800]
            return [], diag
        models = []
        try:
            for m in (r.data or {}).get("models", []):
                name = m.get("name")
                if name:
                    models.append(name)
        except Exception as e:
            diag.last_error = "ollama_list_models_parse_failed"
            diag.last_error_detail = str(e)
            return [], diag
        return models, diag

    def ocr(self, prompt: str, image_base64: str, model: str, temperature: float) -> str:
        url = _join(self._base_no_api(), "/api/chat")
        payload = {
            "model": model,
            "stream": False,
            "options": {"temperature": float(temperature)},
            "messages": [
                {"role": "user", "content": prompt, "images": [image_base64] if image_base64 else []}
            ],
        }
        r = request_json("POST", url, body=payload, timeout_s=120)
        if not r.ok:
            raise RuntimeError(f"Ollama 调用失败: {r.status or ''} {(r.text or r.error or '').strip()}")
        msg = (r.data or {}).get("message") or {}
        content = msg.get("content")
        if isinstance(content, str):
            return content
        return str(content or "")


class OpenAICompatibleAdapter(BaseAdapter):
    service_type = "openai_compat"

    @classmethod
    def detect(cls, base_url: str) -> bool:
        u = normalize_base_url(base_url).lower()
        if "openai.com" in u:
            return True
        if u.endswith("/v1") or "/v1/" in u:
            return True
        return False

    def __init__(self, base_url: str, api_key: str | None):
        super().__init__(base_url, api_key)
        self._client_by_base: dict[str, OpenAI] = {}

    def _client_for(self, base: str) -> OpenAI:
        b = normalize_base_url(base)
        c = self._client_by_base.get(b)
        if c is None:
            c = OpenAI(base_url=b, api_key=self.api_key)
            self._client_by_base[b] = c
        return c

    def _headers(self) -> dict[str, str]:
        hdrs = {}
        if self.api_key:
            hdrs["Authorization"] = f"Bearer {self.api_key}"
        return hdrs

    def _candidate_bases(self) -> list[str]:
        bases = [self.base_url]
        lower = self.base_url.lower()
        if getattr(self, "service_type", "") == "lmstudio":
            if not (lower.endswith("/v1") or "/v1/" in lower):
                bases.append(_join(self.base_url, "/v1"))
        else:
            if lower.endswith("/v1"):
                bases.append(self.base_url[:-3].rstrip("/"))
            else:
                bases.append(_join(self.base_url, "/v1"))
        out = []
        for b in bases:
            bb = normalize_base_url(b)
            if bb and bb not in out:
                out.append(bb)
        return out

    def _try_models_endpoint(self, base: str, timeout_s: float) -> tuple[list[str], str, str]:
        url = _join(base, "/models")
        r = None
        tries = 1 if float(timeout_s or 0) <= 8 else 2
        for attempt in range(tries):
            r = request_json("GET", url, headers=self._headers(), timeout_s=float(timeout_s or 15.0))
            if r.ok:
                break
            if tries > 1:
                _sleep_backoff(attempt)
        if not r.ok:
            return [], "openai_models_http_failed", (r.text or r.error or "")[:800]
        data = r.data or {}
        items = data.get("data", [])
        models = []
        for it in items:
            mid = it.get("id")
            if mid:
                models.append(mid)
        return models, "", ""

    def list_models(self, timeout_s: float = 15.0) -> tuple[list[str], ModelDiagnostics]:
        diag = ModelDiagnostics(
            service_type=self.service_type,
            base_url_input=self.base_url_input,
            base_url_normalized=self.base_url,
        )
        try:
            delay_ms = int(os.getenv("OCRWB_MODEL_PROBE_DELAY_MS", "0") or "0")
        except Exception:
            delay_ms = 0
        if delay_ms > 0:
            time.sleep(min(3.0, max(0.0, delay_ms / 1000.0)))
        base_probe_timeout = min(6.0, float(timeout_s or 15.0))
        base_probe = request_json("GET", self.base_url, headers=self._headers(), timeout_s=base_probe_timeout)
        diag.probes.append(
            {"method": "GET", "url": _mask_url(self.base_url), "ok": base_probe.ok, "status": base_probe.status, "error": base_probe.error}
        )

        sdk_err = None
        if float(timeout_s or 0) > 8:
            for b in self._candidate_bases():
                for attempt in range(2):
                    try:
                        alt_client = self._client_for(b)
                        models = alt_client.models.list()
                        ids = [m.id for m in models.data]
                        diag.probes.append({"method": "SDK", "op": "models.list", "base": b, "ok": True, "count": len(ids)})
                        return ids, diag
                    except Exception as e:
                        sdk_err = e
                        diag.probes.append({"method": "SDK", "op": "models.list", "base": b, "ok": False, "error": str(e)[:300]})
                        _sleep_backoff(attempt)

        for b in self._candidate_bases():
            models, err, detail = self._try_models_endpoint(b, timeout_s=float(timeout_s or 15.0))
            diag.probes.append({"method": "GET", "url": _mask_url(_join(b, "/models")), "ok": bool(models), "error": err})
            if models:
                return models, diag
            if err:
                diag.last_error = err
                diag.last_error_detail = detail
        if not diag.last_error and sdk_err is not None:
            diag.last_error = "openai_models_sdk_failed"
            diag.last_error_detail = str(sdk_err)[:800]
        return [], diag

    def ocr(self, prompt: str, image_base64: str, model: str, temperature: float) -> str:
        content = [{"type": "text", "text": prompt}]
        if image_base64:
            content.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}})
        messages = [{"role": "user", "content": content}]

        last_err = None
        for attempt in range(3):
            try:
                resp = self._client_for(self.base_url).chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=float(temperature),
                    timeout=120.0,
                )
                return resp.choices[0].message.content
            except Exception as e:
                last_err = e
                log.warning(
                    "openai_compat sdk ocr failed service=%s base=%s attempt=%s err=%s",
                    getattr(self, "service_type", self.service_type),
                    self.base_url,
                    attempt + 1,
                    str(e)[:300],
                )
                _sleep_backoff(attempt)

        payload = {"model": model, "messages": messages, "temperature": float(temperature)}
        last_http = ""
        for b in self._candidate_bases():
            url = _join(b, "/chat/completions")
            r = request_json("POST", url, headers=self._headers(), body=payload, timeout_s=120)
            log.info(
                "openai_compat http ocr probe service=%s url=%s ok=%s status=%s",
                getattr(self, "service_type", self.service_type),
                _mask_url(url),
                r.ok,
                r.status,
            )
            if r.ok:
                try:
                    return r.data["choices"][0]["message"]["content"]
                except Exception:
                    return str(r.data)
            last_http = (r.text or r.error or "")[:400]

        msg = str(last_err) if last_err else ""
        raise RuntimeError(f"模型调用失败: {msg} {last_http}".strip())


class AdapterRegistry:
    _adapters = [OllamaAdapter, OpenAICompatibleAdapter]

    @classmethod
    def create(cls, base_url: str, api_key: str | None, service_type: str = "auto") -> BaseAdapter:
        stype = (service_type or "auto").strip().lower()
        if stype in {"lmstudio", "openai"}:
            b = ensure_v1_base(base_url) if stype == "lmstudio" else normalize_base_url(base_url)
            adapter = OpenAICompatibleAdapter(b, api_key)
            adapter.service_type = stype
            return adapter
        if stype != "auto":
            for a in cls._adapters:
                if a.service_type == stype:
                    return a(base_url, api_key)
            return OpenAICompatibleAdapter(base_url, api_key)

        u = normalize_base_url(base_url).lower()
        try:
            r = request_json("GET", _join(u, "/api/tags"), timeout_s=3)
            if r.ok and isinstance(r.data, dict) and "models" in r.data:
                return OllamaAdapter(base_url, api_key)
        except Exception:
            pass

        for a in cls._adapters:
            if a.detect(base_url):
                return a(base_url, api_key)
        return OpenAICompatibleAdapter(base_url, api_key)
