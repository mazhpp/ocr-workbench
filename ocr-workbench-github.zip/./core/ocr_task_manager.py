import hashlib
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any

from core.llm_client import LLMClient
from core.processor import FileProcessor
from core.logging_utils import get_logger


log = get_logger(__name__)


@dataclass
class OcrTaskState:
    file_id: str
    file_name: str
    status: str
    progress: float = 0.0
    page_index: int = 0
    page_total: int = 0
    error: str = ""
    result: str = ""
    started_at: float = 0.0
    finished_at: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)


_lock = threading.Lock()
_tasks: dict[str, OcrTaskState] = {}
_cancel: dict[str, threading.Event] = {}
_queue: list[tuple[str, dict[str, Any], dict[str, Any]]] = []
_worker_started = False
_worker_wakeup = threading.Event()
_batch_expected_seq: dict[str, int] = {}
_batch_files: dict[str, set[str]] = {}


def set_max_concurrency(n: int):
    return


def _cache_key(file_bytes: bytes, config: dict[str, Any]) -> str:
    h = hashlib.sha256()
    h.update(file_bytes)
    for k in ["api_base", "service_type", "model", "temperature", "prompt"]:
        h.update(str(config.get(k, "")).encode("utf-8", errors="ignore"))
        h.update(b"\0")
    return h.hexdigest()


def _cache_path(key: str) -> str:
    os.makedirs("cache", exist_ok=True)
    return os.path.join("cache", f"{key}.md")


def try_load_cache(file_bytes: bytes, config: dict[str, Any]) -> str | None:
    key = _cache_key(file_bytes, config)
    path = _cache_path(key)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return None
    return None


def save_cache(file_bytes: bytes, config: dict[str, Any], result: str):
    key = _cache_key(file_bytes, config)
    path = _cache_path(key)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(result or "")
    except Exception:
        pass


def _skip_cache(config: dict[str, Any]) -> bool:
    return bool(config.get("skip_cache") or config.get("force_recognize"))


def _int_or_default(v: Any, default: int) -> int:
    try:
        if v is None:
            return default
        return int(v)
    except Exception:
        return default


def get_task(file_id: str) -> OcrTaskState | None:
    with _lock:
        return _tasks.get(file_id)


def clear_tasks(file_ids: list[str] | None = None):
    with _lock:
        targets = set(file_ids) if file_ids is not None else set(_tasks.keys())
        for fid in targets:
            ev = _cancel.get(fid)
            if ev:
                ev.set()

        _queue[:] = [it for it in _queue if it[0] not in targets]
        for fid in targets:
            _tasks.pop(fid, None)
            _cancel.pop(fid, None)

        if not _queue:
            _worker_wakeup.clear()


def cancel_task(file_id: str):
    with _lock:
        ev = _cancel.get(file_id)
        state = _tasks.get(file_id)
    if ev:
        ev.set()
    if state and state.status == "排队中":
        with _lock:
            state = _tasks.get(file_id)
            if state and state.status == "排队中":
                state.status = "已取消"
                state.error = "已取消"
                state.finished_at = time.time()


def _abort_batch_locked(run_id: str, message: str):
    if not run_id:
        return
    fids = set(_batch_files.get(run_id) or set())
    if not fids:
        return
    now = time.time()
    for fid in fids:
        ev = _cancel.get(fid)
        if ev:
            ev.set()
        st = _tasks.get(fid)
        if st and st.status in {"排队中", "识别中"}:
            st.status = "已取消"
            st.error = message
            st.finished_at = now
    _queue[:] = [it for it in _queue if it[0] not in fids]
    _worker_wakeup.set()


def start_task(file_id: str, record: dict[str, Any], config: dict[str, Any]):
    global _worker_started
    with _lock:
        existing = _tasks.get(file_id)
        if existing and existing.status in {"识别中", "排队中"}:
            return
        run_id = str(config.get("batch_run_id") or "")
        if run_id and bool(config.get("batch_reset")):
            _batch_expected_seq[run_id] = 0
            _batch_files[run_id] = set()
        if run_id:
            _batch_files.setdefault(run_id, set()).add(file_id)
        _cancel[file_id] = threading.Event()
        _tasks[file_id] = OcrTaskState(
            file_id=file_id,
            file_name=record.get("name", ""),
            status="排队中",
            progress=0.0,
            page_index=0,
            page_total=0,
            started_at=time.time(),
            meta={
                "service_type": config.get("service_type", "auto"),
                "attempt": 0,
                "batch_run_id": run_id,
                "batch_seq": _int_or_default(config.get("batch_seq", -1), -1),
            },
        )
        _queue.append((file_id, record, config))
        _worker_wakeup.set()
        if not _worker_started:
            threading.Thread(target=_worker_loop, daemon=True).start()
            _worker_started = True

def _worker_loop():
    while True:
        _worker_wakeup.wait()
        item = None
        with _lock:
            while _queue:
                file_id, record, config = _queue.pop(0)
                state = _tasks.get(file_id)
                cancel_ev = _cancel.get(file_id)
                if not state:
                    continue
                if cancel_ev and cancel_ev.is_set():
                    state.status = "已取消"
                    state.error = "已取消"
                    state.finished_at = time.time()
                    continue
                if state.status != "排队中":
                    continue
                item = (file_id, record, config)
                break
            if not _queue:
                _worker_wakeup.clear()

        if not item:
            continue

        file_id, record, config = item
        _run_single(file_id, record, config)


def _run_single(file_id: str, record: dict[str, Any], config: dict[str, Any]):
    with _lock:
        state = _tasks.get(file_id)
        if not state:
            return
        state.status = "识别中"

        run_id = str(config.get("batch_run_id") or "")
        seq = _int_or_default(config.get("batch_seq", -1), -1)
        if run_id and seq >= 0:
            expected = int(_batch_expected_seq.get(run_id, 0))
            if seq != expected:
                msg = f"排序异常：期望处理第 {expected + 1} 个文件，但开始了第 {seq + 1} 个文件。请确认页面排序后重试。"
                _abort_batch_locked(run_id, msg)
                state = _tasks.get(file_id)
                if state:
                    state.status = "失败"
                    state.error = msg
                    state.finished_at = time.time()
                return

    path = record.get("path", "")
    mime_type = record.get("mime", "")
    file_name = record.get("name", "")
    with _lock:
        cancel_ev = _cancel.get(file_id)

    try:
        if not path or not os.path.exists(path):
            raise RuntimeError("文件不存在或未成功保存，请重新上传")

        with open(path, "rb") as f:
            file_bytes = f.read()

        if not _skip_cache(config):
            cached = try_load_cache(file_bytes, config)
            if cached:
                with _lock:
                    state = _tasks.get(file_id)
                    if state:
                        state.status = "已完成（缓存）"
                        state.progress = 1.0
                        state.result = cached
                        state.finished_at = time.time()
                        run_id = str(config.get("batch_run_id") or "")
                        seq = _int_or_default(config.get("batch_seq", -1), -1)
                        if run_id and seq >= 0 and int(_batch_expected_seq.get(run_id, 0)) == seq:
                            _batch_expected_seq[run_id] = seq + 1
                return

        client = LLMClient(
            base_url=config.get("api_base", ""),
            api_key=config.get("api_key", ""),
            service_type=config.get("service_type", "auto"),
        )

        if file_name.lower().endswith(".pdf") or mime_type == "application/pdf":
            images = FileProcessor.process_pdf(file_bytes)
        else:
            images = FileProcessor.process_image(file_bytes)

        total_pages = len(images)
        with _lock:
            state = _tasks.get(file_id)
            if state:
                state.page_total = total_pages

        file_result = f"## {file_name}\n\n"
        page_retries = int(config.get("page_retries", 1) or 1)
        for page_idx, img in enumerate(images, start=1):
            if cancel_ev and cancel_ev.is_set():
                raise RuntimeError("已取消")

            with _lock:
                state = _tasks.get(file_id)
                if state:
                    state.page_index = page_idx
                    state.progress = (page_idx - 1) / max(1, total_pages)

            img_base64 = FileProcessor.image_to_base64(img)
            last_page_err: Exception | None = None
            for attempt in range(page_retries + 1):
                try:
                    ocr_text = client.ocr_request(
                        prompt=config.get("prompt", ""),
                        image_base64=img_base64,
                        model=config.get("model", ""),
                        temperature=config.get("temperature", 0.1),
                    )
                    last_page_err = None
                    break
                except Exception as e:
                    last_page_err = e
                    log.warning(
                        "ocr page failed file_id=%s file=%s page=%s/%s attempt=%s service=%s base=%s model=%s err=%s",
                        file_id,
                        file_name,
                        page_idx,
                        total_pages,
                        attempt + 1,
                        config.get("service_type", "auto"),
                        config.get("api_base", ""),
                        config.get("model", ""),
                        str(e)[:300],
                    )
                    time.sleep(min(3.0, 0.4 * (2**attempt)))
            if last_page_err is not None:
                raise last_page_err
            ocr_text = FileProcessor.clean_text(ocr_text)
            file_result += f"{ocr_text}\n\n"

            with _lock:
                state = _tasks.get(file_id)
                if state:
                    state.progress = page_idx / max(1, total_pages)

        with _lock:
            state = _tasks.get(file_id)
            if state:
                state.status = "已完成"
                state.progress = 1.0
                state.result = file_result
                state.finished_at = time.time()
                run_id = str(config.get("batch_run_id") or "")
                seq = _int_or_default(config.get("batch_seq", -1), -1)
                if run_id and seq >= 0 and int(_batch_expected_seq.get(run_id, 0)) == seq:
                    _batch_expected_seq[run_id] = seq + 1

        if not _skip_cache(config):
            save_cache(file_bytes, config, file_result)
    except Exception as e:
        msg = str(e)

        def is_retryable_error(message: str) -> bool:
            m = (message or "").lower()
            keys = [
                "timeout",
                "timed out",
                "connection",
                "temporary",
                "temporarily",
                "502",
                "503",
                "504",
                "429",
                "rate limit",
                "server error",
            ]
            return any(k in m for k in keys)

        with _lock:
            state = _tasks.get(file_id)
            if state and msg != "已取消":
                state.meta["attempt"] = int(state.meta.get("attempt", 0) or 0) + 1
                attempt_no = int(state.meta.get("attempt", 0) or 0)
                max_file_retries = int(config.get("file_retries", 1) or 1)
                if attempt_no <= max_file_retries and is_retryable_error(msg):
                    state.status = "排队中"
                    state.error = f"将重试（第 {attempt_no}/{max_file_retries} 次）：{msg}"
                    _queue.insert(0, (file_id, record, config))
                    _worker_wakeup.set()
                    log.warning(
                        "ocr task scheduled retry file_id=%s file=%s attempt=%s/%s err=%s",
                        file_id,
                        file_name,
                        attempt_no,
                        max_file_retries,
                        msg[:300],
                    )
                    return

            if state:
                state.status = "失败" if msg != "已取消" else "已取消"
                state.error = msg
                state.finished_at = time.time()
                run_id = str(config.get("batch_run_id") or "")
                seq = _int_or_default(config.get("batch_seq", -1), -1)
                if run_id and seq >= 0 and int(_batch_expected_seq.get(run_id, 0)) == seq:
                    _batch_expected_seq[run_id] = seq + 1

        log.exception(
            "ocr task failed file_id=%s file=%s service=%s base=%s model=%s err=%s",
            file_id,
            file_name,
            config.get("service_type", "auto"),
            config.get("api_base", ""),
            config.get("model", ""),
            msg,
        )
