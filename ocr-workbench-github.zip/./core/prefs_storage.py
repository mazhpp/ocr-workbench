import json
from urllib.parse import urlparse


def is_valid_url(url: str) -> bool:
    if not url:
        return False
    try:
        p = urlparse(url)
        return p.scheme in {"http", "https"} and bool(p.netloc)
    except Exception:
        return False


def parse_map(raw: str, default_key: str = "lmstudio") -> dict[str, str]:
    s = (raw or "").strip()
    if not s:
        return {}
    if s.startswith("{") and s.endswith("}"):
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                out = {}
                for k, v in obj.items():
                    kk = str(k).strip()
                    vv = str(v).strip()
                    if kk and vv:
                        out[kk] = vv
                return out
        except Exception:
            return {}
    return {default_key: s}


def dump_map(m: dict[str, str]) -> str:
    clean = {str(k): str(v) for k, v in (m or {}).items() if str(k).strip() and str(v).strip()}
    return json.dumps(clean, ensure_ascii=False)

