import json
import socket
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass
class HttpResult:
    ok: bool
    status: int | None
    data: Any | None
    text: str | None
    error: str | None
    url: str


def _read_text(resp) -> str:
    raw = resp.read()
    try:
        return raw.decode("utf-8")
    except Exception:
        return raw.decode("utf-8", errors="ignore")


def request_json(
    method: str,
    url: str,
    headers: Mapping[str, str] | None = None,
    body: Any | None = None,
    timeout_s: float = 20.0,
) -> HttpResult:
    hdrs = {"Accept": "application/json"}
    if headers:
        hdrs.update({k: v for k, v in headers.items() if v is not None})

    data_bytes = None
    if body is not None:
        data_bytes = json.dumps(body, ensure_ascii=False).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json; charset=utf-8")

    req = urllib.request.Request(url=url, method=method.upper(), headers=hdrs, data=data_bytes)
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            status = getattr(resp, "status", None) or 200
            text = _read_text(resp)
            if not text:
                return HttpResult(ok=True, status=status, data=None, text="", error=None, url=url)
            try:
                return HttpResult(ok=True, status=status, data=json.loads(text), text=text, error=None, url=url)
            except Exception:
                return HttpResult(ok=False, status=status, data=None, text=text, error="invalid_json", url=url)
    except urllib.error.HTTPError as e:
        try:
            text = e.read().decode("utf-8", errors="ignore")
        except Exception:
            text = ""
        return HttpResult(ok=False, status=e.code, data=None, text=text, error=f"http_{e.code}", url=url)
    except (urllib.error.URLError, socket.timeout) as e:
        return HttpResult(ok=False, status=None, data=None, text=None, error=str(e), url=url)

