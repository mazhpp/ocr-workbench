import datetime
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager


def db_path() -> str:
    os.makedirs("data", exist_ok=True)
    return os.path.join("data", "uploads.db")


def _connect(path: str | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


@contextmanager
def _conn(path: str | None = None):
    conn = _connect(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path: str | None = None):
    with _conn(path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS files (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                size INTEGER NOT NULL,
                mime TEXT NOT NULL,
                path TEXT NOT NULL,
                status TEXT NOT NULL,
                supported INTEGER NOT NULL DEFAULT 0,
                selected INTEGER NOT NULL DEFAULT 0,
                order_num INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                removed_at TEXT NOT NULL DEFAULT '',
                error TEXT NOT NULL DEFAULT '',
                delete_op_id TEXT NOT NULL DEFAULT ''
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS delete_ops (
                op_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                payload_json TEXT NOT NULL
            )
            """
        )


def now_ts() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def list_files(status: str | None = None, path: str | None = None) -> list[dict]:
    init_db(path)
    with _conn(path) as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM files WHERE status=? ORDER BY order_num ASC, created_at ASC",
                (status,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM files ORDER BY order_num ASC, created_at ASC",
            ).fetchall()
        return [dict(r) for r in rows]


def get_files(ids: list[str], path: str | None = None) -> list[dict]:
    if not ids:
        return []
    init_db(path)
    with _conn(path) as conn:
        q = ",".join(["?"] * len(ids))
        rows = conn.execute(f"SELECT * FROM files WHERE id IN ({q})", tuple(ids)).fetchall()
        return [dict(r) for r in rows]


def upsert_file(record: dict, path: str | None = None):
    init_db(path)
    rid = str(record.get("id") or uuid.uuid4().hex)
    rec = dict(record)
    rec["id"] = rid
    rec.setdefault("status", "active")
    rec.setdefault("mime", "")
    rec.setdefault("path", "")
    rec.setdefault("size", 0)
    rec.setdefault("supported", 0)
    rec.setdefault("selected", 0)
    rec.setdefault("order_num", 0)
    rec.setdefault("created_at", now_ts())
    rec.setdefault("removed_at", "")
    rec.setdefault("error", "")
    rec.setdefault("delete_op_id", "")
    with _conn(path) as conn:
        conn.execute(
            """
            INSERT INTO files (id,name,size,mime,path,status,supported,selected,order_num,created_at,removed_at,error,delete_op_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              name=excluded.name,
              size=excluded.size,
              mime=excluded.mime,
              path=excluded.path,
              status=excluded.status,
              supported=excluded.supported,
              selected=excluded.selected,
              order_num=excluded.order_num,
              created_at=excluded.created_at,
              removed_at=excluded.removed_at,
              error=excluded.error,
              delete_op_id=excluded.delete_op_id
            """,
            (
                rec["id"],
                str(rec["name"] or ""),
                int(rec["size"] or 0),
                str(rec["mime"] or ""),
                str(rec["path"] or ""),
                str(rec["status"] or "active"),
                1 if rec.get("supported") else 0,
                1 if rec.get("selected") else 0,
                int(rec.get("order_num") or 0),
                str(rec.get("created_at") or now_ts()),
                str(rec.get("removed_at") or ""),
                str(rec.get("error") or ""),
                str(rec.get("delete_op_id") or ""),
            ),
        )


def exists_name_size(name: str, size: int, path: str | None = None) -> bool:
    init_db(path)
    with _conn(path) as conn:
        row = conn.execute(
            "SELECT 1 FROM files WHERE name=? AND size=? AND status IN ('active','removed') LIMIT 1",
            (str(name or ""), int(size or 0)),
        ).fetchone()
        return bool(row)


def find_file_by_name_size(name: str, size: int, path: str | None = None) -> dict | None:
    init_db(path)
    with _conn(path) as conn:
        row = conn.execute(
            "SELECT * FROM files WHERE name=? AND size=? AND status IN ('active','removed') ORDER BY created_at DESC LIMIT 1",
            (str(name or ""), int(size or 0)),
        ).fetchone()
        return dict(row) if row else None


def move_files(ids: list[str], to_status: str, path: str | None = None):
    if not ids:
        return
    init_db(path)
    ts = now_ts() if to_status == "removed" else ""
    with _conn(path) as conn:
        q = ",".join(["?"] * len(ids))
        conn.execute(
            f"UPDATE files SET status=?, removed_at=?, delete_op_id='' WHERE id IN ({q})",
            tuple([to_status, ts] + ids),
        )


def update_selected(ids: list[str], selected: bool, path: str | None = None):
    if not ids:
        return
    init_db(path)
    with _conn(path) as conn:
        q = ",".join(["?"] * len(ids))
        conn.execute(
            f"UPDATE files SET selected=? WHERE id IN ({q})",
            tuple([1 if selected else 0] + ids),
        )


def update_order(id_to_order: dict[str, int], path: str | None = None):
    if not id_to_order:
        return
    init_db(path)
    with _conn(path) as conn:
        for rid, o in id_to_order.items():
            conn.execute("UPDATE files SET order_num=? WHERE id=?", (int(o or 0), str(rid)))


def begin_delete_op(ids: list[str], path: str | None = None) -> str:
    init_db(path)
    op_id = uuid.uuid4().hex
    cur = get_files(ids, path)
    payload = [{"id": r["id"], "prev_status": r.get("status", "")} for r in cur]
    with _conn(path) as conn:
        conn.execute(
            "INSERT INTO delete_ops (op_id, created_at, payload_json) VALUES (?,?,?)",
            (op_id, now_ts(), json.dumps(payload, ensure_ascii=False)),
        )
        q = ",".join(["?"] * len(ids))
        conn.execute(
            f"UPDATE files SET status='deleting', delete_op_id=? WHERE id IN ({q})",
            tuple([op_id] + ids),
        )
    return op_id


def finalize_delete(op_id: str, path: str | None = None):
    init_db(path)
    with _conn(path) as conn:
        rows = conn.execute("SELECT id FROM files WHERE delete_op_id=?", (op_id,)).fetchall()
        ids = [str(r["id"]) for r in rows]
        if ids:
            q = ",".join(["?"] * len(ids))
            conn.execute(f"DELETE FROM files WHERE id IN ({q})", tuple(ids))
        conn.execute("DELETE FROM delete_ops WHERE op_id=?", (op_id,))


def rollback_delete(op_id: str, path: str | None = None):
    init_db(path)
    with _conn(path) as conn:
        row = conn.execute("SELECT payload_json FROM delete_ops WHERE op_id=?", (op_id,)).fetchone()
        if not row:
            return
        payload = json.loads(row["payload_json"] or "[]") or []
        for it in payload:
            rid = str(it.get("id") or "")
            prev = str(it.get("prev_status") or "removed")
            if not rid:
                continue
            conn.execute(
                "UPDATE files SET status=?, delete_op_id='' WHERE id=?",
                (prev, rid),
            )
        conn.execute("DELETE FROM delete_ops WHERE op_id=?", (op_id,))

