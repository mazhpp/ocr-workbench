import os
import tempfile
import unittest

from core.delete_service import hard_delete
from core.file_store import init_db, list_files, move_files, update_order, update_selected, upsert_file


class TestBatchOps(unittest.TestCase):
    def test_batch_move_and_order(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a", "size": 1, "mime": "", "path": "p1", "status": "active", "order_num": 1}, db)
            upsert_file({"id": "2", "name": "b", "size": 1, "mime": "", "path": "p2", "status": "active", "order_num": 2}, db)
            move_files(["1", "2"], "removed", db)
            self.assertEqual(len(list_files("removed", db)), 2)
            move_files(["1"], "active", db)
            update_order({"1": 9}, db)
            rows = list_files("active", db)
            self.assertEqual(rows[0]["order_num"], 9)

    def test_batch_selected(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a", "size": 1, "mime": "", "path": "p1", "status": "active", "selected": 0}, db)
            update_selected(["1"], True, db)
            rows = list_files("active", db)
            self.assertEqual(rows[0]["selected"], 1)

    def test_clear_all_hard_delete(self):
        with tempfile.TemporaryDirectory() as td:
            upload_dir = os.path.join(td, "uploads")
            os.makedirs(upload_dir, exist_ok=True)
            db = os.path.join(td, "t.db")
            init_db(db)
            p1 = os.path.join(upload_dir, "1_a.txt")
            p2 = os.path.join(upload_dir, "2_b.txt")
            with open(p1, "wb") as f:
                f.write(b"a")
            with open(p2, "wb") as f:
                f.write(b"b")
            upsert_file({"id": "1", "name": "a.txt", "size": 1, "mime": "text/plain", "path": p1, "status": "active"}, db)
            upsert_file({"id": "2", "name": "b.txt", "size": 1, "mime": "text/plain", "path": p2, "status": "removed"}, db)
            ok, err = hard_delete(["1", "2"], allowed_roots=[upload_dir], db_path=db)
            self.assertTrue(ok, err)
            self.assertEqual(list_files(None, db), [])
            self.assertFalse(os.path.exists(p1))
            self.assertFalse(os.path.exists(p2))


if __name__ == "__main__":
    unittest.main()

