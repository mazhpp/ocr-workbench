import unittest

from core.diagnostics import build_diagnostic_report, sanitize_model_name, validate_model_name


class TestDiagnostics(unittest.TestCase):
    def test_validate_model_name(self):
        ok, err = validate_model_name("gpt-4o-mini")
        self.assertTrue(ok)
        self.assertEqual(err, "")

        ok, err = validate_model_name("")
        self.assertFalse(ok)

        ok, err = validate_model_name("bad name")
        self.assertFalse(ok)

    def test_sanitize_model_name(self):
        self.assertEqual(sanitize_model_name("  gpt-4o-mini  "), "gpt-4o-mini")
        self.assertEqual(sanitize_model_name("gpt 4o\nmini"), "gpt4omini")
        self.assertEqual(sanitize_model_name("___bad"), "bad")
        self.assertEqual(sanitize_model_name(""), "")

    def test_report_connect_error(self):
        report = build_diagnostic_report(
            service_type="lmstudio",
            api_base="http://localhost:1234",
            model_name="gpt-4o-mini",
            model_list=[],
            last_diag={"last_error": "openai_models_http_failed", "last_error_detail": "timeout"},
        )
        self.assertFalse(report["ready_for_ocr"])
        self.assertEqual(report["model_load_status"], "失败")
        self.assertIn("suggestions", report)

    def test_report_ok(self):
        report = build_diagnostic_report(
            service_type="lmstudio",
            api_base="http://localhost:1234/v1",
            model_name="gpt-4o-mini",
            model_list=["gpt-4o-mini"],
            last_diag={"last_error": "", "last_error_detail": ""},
        )
        self.assertTrue(report["ready_for_ocr"])
        self.assertEqual(report["status"], "ok")


if __name__ == "__main__":
    unittest.main()
