import os
import tempfile
import unittest

import core.history_manager as hm


class TestHistoryManager(unittest.TestCase):
    def test_delete_all_history(self):
        with tempfile.TemporaryDirectory() as td:
            hist = os.path.join(td, "history")
            logs = os.path.join(td, "logs")
            os.makedirs(hist, exist_ok=True)
            os.makedirs(logs, exist_ok=True)
            old_hist_dir = hm.HISTORY_DIR
            old_log_dir = hm.LOG_DIR
            try:
                hm.HISTORY_DIR = hist
                hm.LOG_DIR = logs
                mgr = hm.HistoryManager()
                mgr.save_history("a.txt", "hello")
                mgr.save_history("b.txt", "world")
                self.assertEqual(len(mgr.get_history_list()), 2)
                deleted = mgr.delete_all_history()
                self.assertEqual(deleted, 2)
                self.assertEqual(mgr.get_history_list(), [])
            finally:
                try:
                    for h in list(getattr(mgr, "_logger", None).handlers or []):
                        try:
                            h.close()
                        except Exception:
                            pass
                        try:
                            getattr(mgr, "_logger", None).removeHandler(h)
                        except Exception:
                            pass
                except Exception:
                    pass
                hm.HISTORY_DIR = old_hist_dir
                hm.LOG_DIR = old_log_dir


if __name__ == "__main__":
    unittest.main()
