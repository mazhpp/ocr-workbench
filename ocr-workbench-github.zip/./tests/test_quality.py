import unittest

from core.quality import quality_metrics


class TestQuality(unittest.TestCase):
    def test_empty(self):
        q = quality_metrics("")
        self.assertEqual(q["level"], "低")
        self.assertIn("结果为空", q["issues"])

    def test_longer_text(self):
        q = quality_metrics("这是一个测试文本，用于评估质量指标。\n第二行内容。")
        self.assertIn(q["level"], {"中", "高"})
        self.assertGreaterEqual(q["score"], 40)


if __name__ == "__main__":
    unittest.main()

