import unittest

from core.processor import FileProcessor


class TestCodeFenceUnwrap(unittest.TestCase):
    def test_unwrap_markdown_fence_single_line(self):
        raw = "```markdown\n广州印章连锁公司 天河分公司\n```"
        out = FileProcessor.clean_text(raw)
        self.assertEqual(out, "广州印章连锁公司 天河分公司")
        self.assertNotIn("```", out)

    def test_unwrap_markdown_fence_multi_line(self):
        raw = "```markdown\n第一行\n\n第二行\n```"
        out = FileProcessor.clean_text(raw)
        self.assertIn("第一行", out)
        self.assertIn("第二行", out)
        self.assertNotIn("```markdown", out)

    def test_keep_non_markdown_fence(self):
        raw = "```python\nprint('hi')\n```"
        out = FileProcessor.clean_text(raw)
        self.assertIn("```python", out)
        self.assertIn("```", out)


if __name__ == "__main__":
    unittest.main()

