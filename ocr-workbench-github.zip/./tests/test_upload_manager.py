import unittest
import datetime

from core.upload_manager import is_duplicate_name_size, photo_basename, safe_filename


class TestUploadManager(unittest.TestCase):
    def test_safe_filename(self):
        self.assertEqual(safe_filename("a/b:c?.txt"), "a_b_c_.txt")
        self.assertEqual(safe_filename(""), "file")

    def test_duplicate_name_size(self):
        active = {"1": {"name": "a.pdf", "size": 10}}
        removed = {"2": {"name": "b.pdf", "size": 20}}
        self.assertTrue(is_duplicate_name_size(active, removed, "a.pdf", 10))
        self.assertTrue(is_duplicate_name_size(active, removed, "b.pdf", 20))
        self.assertFalse(is_duplicate_name_size(active, removed, "a.pdf", 11))

    def test_photo_basename(self):
        dt = datetime.datetime(2026, 1, 18, 12, 34, 56)
        self.assertEqual(photo_basename(dt), "photo_20260118_123456")


if __name__ == "__main__":
    unittest.main()

