import io

import fitz

from core.processor import FileProcessor


def _make_pdf_bytes(pages: int) -> bytes:
    doc = fitz.open()
    try:
        for i in range(int(pages)):
            page = doc.new_page()
            page.insert_text((72, 72), f"Page {i + 1}")
        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()
    finally:
        doc.close()


def test_pdf_preview_helpers():
    b = _make_pdf_bytes(3)
    assert FileProcessor.pdf_page_count(b) == 3
    img0 = FileProcessor.pdf_page_to_image(b, 0)
    img2 = FileProcessor.pdf_page_to_image(b, 2)
    assert img0 is not None
    assert img2 is not None
    assert img0.size[0] > 0 and img0.size[1] > 0
    assert img2.size[0] > 0 and img2.size[1] > 0

