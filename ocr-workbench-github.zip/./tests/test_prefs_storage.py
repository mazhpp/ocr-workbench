import unittest

from core.prefs_storage import dump_map, is_valid_url, parse_map


class TestPrefsStorage(unittest.TestCase):
    def test_is_valid_url(self):
        self.assertTrue(is_valid_url("http://localhost:1234/v1"))
        self.assertTrue(is_valid_url("https://example.com/v1"))
        self.assertFalse(is_valid_url("localhost:1234/v1"))
        self.assertFalse(is_valid_url("ftp://example.com"))
        self.assertFalse(is_valid_url(""))

    def test_parse_map_json(self):
        m = parse_map('{"lmstudio":"http://localhost:1234/v1","ollama":"http://localhost:11434"}')
        self.assertEqual(m["lmstudio"], "http://localhost:1234/v1")
        self.assertEqual(m["ollama"], "http://localhost:11434")

    def test_parse_map_plain_string(self):
        m = parse_map("http://localhost:12345/v1", default_key="lmstudio")
        self.assertEqual(m, {"lmstudio": "http://localhost:12345/v1"})

    def test_dump_map_roundtrip(self):
        raw = dump_map({"lmstudio": "http://localhost:1234/v1"})
        m = parse_map(raw)
        self.assertEqual(m["lmstudio"], "http://localhost:1234/v1")


if __name__ == "__main__":
    unittest.main()

