import unittest
from unittest.mock import patch

from core.model_adapters import AdapterRegistry


class _R:
    def __init__(self, ok, status=None, data=None, text=None, error=None, url=""):
        self.ok = ok
        self.status = status
        self.data = data
        self.text = text
        self.error = error
        self.url = url


class TestModelAutoload(unittest.TestCase):
    def test_openai_adapter_fast_list_models_no_sdk(self):
        def fake_request_json(method, url, headers=None, body=None, timeout_s=20.0):
            if url.endswith("/models"):
                return _R(True, status=200, data={"data": [{"id": "m1"}, {"id": "m2"}]}, text="", error=None, url=url)
            return _R(True, status=200, data={}, text="", error=None, url=url)

        with patch("core.model_adapters.request_json", new=fake_request_json):
            with patch("core.model_adapters.OpenAI", side_effect=RuntimeError("sdk_called")):
                ad = AdapterRegistry.create("http://localhost:1234/v1", api_key="x", service_type="lmstudio")
                models, diag = ad.list_models(timeout_s=3.0)
                self.assertEqual(models, ["m1", "m2"])
                self.assertEqual(diag.last_error, "")

    def test_ollama_list_models_respects_timeout(self):
        seen = {"timeout": None}

        def fake_request_json(method, url, headers=None, body=None, timeout_s=20.0):
            seen["timeout"] = timeout_s
            return _R(True, status=200, data={"models": [{"name": "llama3"}]}, text="", error=None, url=url)

        with patch("core.model_adapters.request_json", new=fake_request_json):
            ad = AdapterRegistry.create("http://localhost:11434", api_key="", service_type="ollama")
            models, _ = ad.list_models(timeout_s=2.5)
            self.assertEqual(models, ["llama3"])
            self.assertAlmostEqual(float(seen["timeout"]), 2.5, delta=0.01)


if __name__ == "__main__":
    unittest.main()

