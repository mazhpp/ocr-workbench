import os
import tempfile
import unittest

from core.file_store import begin_delete_op, exists_name_size, finalize_delete, get_files, init_db, list_files, move_files, rollback_delete, upsert_file


class TestFileStore(unittest.TestCase):
    def test_upsert_and_list(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a.pdf", "size": 10, "mime": "application/pdf", "path": "uploads/x", "status": "active"}, db)
            rows = list_files("active", db)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["id"], "1")

    def test_exists_name_size(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a.pdf", "size": 10, "mime": "", "path": "p", "status": "active"}, db)
            self.assertTrue(exists_name_size("a.pdf", 10, db))
            self.assertFalse(exists_name_size("a.pdf", 11, db))

    def test_move_files(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a.pdf", "size": 10, "mime": "", "path": "p", "status": "active"}, db)
            move_files(["1"], "removed", db)
            rows = list_files("removed", db)
            self.assertEqual(len(rows), 1)

    def test_delete_rollback(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a.pdf", "size": 10, "mime": "", "path": "p", "status": "active"}, db)
            op_id = begin_delete_op(["1"], db)
            rows = get_files(["1"], db)
            self.assertEqual(rows[0]["status"], "deleting")
            rollback_delete(op_id, db)
            rows = get_files(["1"], db)
            self.assertEqual(rows[0]["status"], "active")

    def test_delete_finalize(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "t.db")
            init_db(db)
            upsert_file({"id": "1", "name": "a.pdf", "size": 10, "mime": "", "path": "p", "status": "active"}, db)
            op_id = begin_delete_op(["1"], db)
            finalize_delete(op_id, db)
            rows = list_files(None, db)
            self.assertEqual(rows, [])


if __name__ == "__main__":
    unittest.main()

