import os
import tempfile
import unittest

from core.delete_service import hard_delete
from core.file_store import get_files, init_db, upsert_file


class TestDeleteService(unittest.TestCase):
    def test_hard_delete_success(self):
        with tempfile.TemporaryDirectory() as td:
            upload_dir = os.path.join(td, "uploads")
            os.makedirs(upload_dir, exist_ok=True)
            db = os.path.join(td, "t.db")
            init_db(db)
            p = os.path.join(upload_dir, "1_a.txt")
            with open(p, "wb") as f:
                f.write(b"hi")
            upsert_file({"id": "1", "name": "a.txt", "size": 2, "mime": "text/plain", "path": p, "status": "active"}, db)
            ok, err = hard_delete(["1"], allowed_roots=[upload_dir], db_path=db)
            self.assertTrue(ok, err)
            self.assertFalse(os.path.exists(p))
            self.assertEqual(get_files(["1"], db), [])

    def test_hard_delete_rollback_on_locked_file(self):
        with tempfile.TemporaryDirectory() as td:
            upload_dir = os.path.join(td, "uploads")
            os.makedirs(upload_dir, exist_ok=True)
            db = os.path.join(td, "t.db")
            init_db(db)
            p = os.path.join(upload_dir, "1_a.txt")
            with open(p, "wb") as f:
                f.write(b"hi")
            upsert_file({"id": "1", "name": "a.txt", "size": 2, "mime": "text/plain", "path": p, "status": "active"}, db)
            h = open(p, "rb")
            try:
                ok, _ = hard_delete(["1"], allowed_roots=[upload_dir], db_path=db)
                self.assertFalse(ok)
                rows = get_files(["1"], db)
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["status"], "active")
                self.assertTrue(os.path.exists(p))
            finally:
                h.close()


if __name__ == "__main__":
    unittest.main()

