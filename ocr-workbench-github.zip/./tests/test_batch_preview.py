import unittest

from core.batch_preview import ensure_selected_file


class TestBatchPreview(unittest.TestCase):
    def test_new_run_selects_first(self):
        run_id, fid = ensure_selected_file("r2", "r1", "x", ["a", "b"])
        self.assertEqual(run_id, "r2")
        self.assertEqual(fid, "a")

    def test_keeps_selected_when_valid(self):
        run_id, fid = ensure_selected_file("r1", "r1", "b", ["a", "b"])
        self.assertEqual(run_id, "r1")
        self.assertEqual(fid, "b")

    def test_fallback_when_missing(self):
        run_id, fid = ensure_selected_file("r1", "r1", "x", ["a", "b"])
        self.assertEqual(fid, "a")

    def test_empty_list(self):
        run_id, fid = ensure_selected_file("r1", "r1", "x", [])
        self.assertEqual(fid, "")


if __name__ == "__main__":
    unittest.main()

