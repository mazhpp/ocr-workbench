import os
import tempfile
import unittest

from core.cleanup import delete_files_in_dir


class TestCleanup(unittest.TestCase):
    def test_delete_files_in_dir(self):
        with tempfile.TemporaryDirectory() as td:
            p1 = os.path.join(td, "a.txt")
            p2 = os.path.join(td, "b.bin")
            with open(p1, "wb") as f:
                f.write(b"1")
            with open(p2, "wb") as f:
                f.write(b"2")

            removed = delete_files_in_dir(td)
            self.assertEqual(removed, 2)
            self.assertFalse(os.path.exists(p1))
            self.assertFalse(os.path.exists(p2))


if __name__ == "__main__":
    unittest.main()

