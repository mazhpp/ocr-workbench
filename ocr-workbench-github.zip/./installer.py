import os
import sys
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
import ctypes

def _base_dir():
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))

def _payload_dir():
    base = _base_dir()
    p = os.path.join(base, "payload")
    return p if os.path.exists(p) else base

def _run_elevated():
    try:
        if os.name == "nt":
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            return True
    except Exception:
        pass
    return False

def _create_shortcut(path_exe: str, lnk_path: str, icon_path: str = ""):
    try:
        ps = """
        param($TargetPath,$ShortcutPath,$IconPath)
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($ShortcutPath)
        $sc.TargetPath = $TargetPath
        if ($IconPath) { $sc.IconLocation = $IconPath }
        $sc.Save()
        """
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps, "-TargetPath", path_exe, "-ShortcutPath", lnk_path, "-IconPath", icon_path],
            check=False,
        )
    except Exception:
        pass

class InstallerUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OCR 工作台 安装向导")
        self.target_var = tk.StringVar(value=self._default_path())
        self.desktop_var = tk.BooleanVar(value=True)
        self.startmenu_var = tk.BooleanVar(value=True)
        self.autorun_var = tk.BooleanVar(value=True)
        self._build_ui()

    def _default_path(self):
        if os.name == "nt":
            p = os.path.join(os.environ.get("ProgramFiles", "C:\\Program Files"), "OCRWorkbench")
        else:
            p = os.path.join(os.path.expanduser("~"), "OCRWorkbench")
        return p

    def _build_ui(self):
        frm = ttk.Frame(self.root, padding=12)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="选择安装路径：").pack(anchor="w")
        row = ttk.Frame(frm)
        row.pack(fill="x", pady=4)
        ttk.Entry(row, textvariable=self.target_var).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="浏览…", command=self._browse).pack(side="left", padx=6)
        ttk.Checkbutton(frm, text="创建桌面快捷方式", variable=self.desktop_var).pack(anchor="w")
        ttk.Checkbutton(frm, text="创建开始菜单项", variable=self.startmenu_var).pack(anchor="w")
        ttk.Checkbutton(frm, text="安装完成后自动运行", variable=self.autorun_var).pack(anchor="w")
        ttk.Button(frm, text="安装", command=self._install).pack(pady=10)

    def _browse(self):
        d = filedialog.askdirectory(title="选择安装目录")
        if d:
            self.target_var.set(d)

    def _copy_tree(self, src: str, dst: str):
        os.makedirs(dst, exist_ok=True)
        for root, dirs, files in os.walk(src):
            rel = os.path.relpath(root, src)
            out = os.path.join(dst, rel) if rel != "." else dst
            os.makedirs(out, exist_ok=True)
            for f in files:
                sp = os.path.join(root, f)
                dp = os.path.join(out, f)
                shutil.copy2(sp, dp)

    def _install(self):
        target = self.target_var.get().strip()
        if not target:
            messagebox.showerror("错误", "安装路径不能为空")
            return
        try:
            self.root.config(cursor="wait")
            self.root.update()
            payload = _payload_dir()
            self._copy_tree(payload, target)
            exe_candidates = [
                os.path.join(target, "本地OCR工作台.exe"),
                os.path.join(target, "OCRWorkbench.exe"),
            ]
            manager_candidates = [
                os.path.join(target, "OCRWorkbenchManager.exe"),
                os.path.join(target, "manager_gui.exe"),
            ]
            exe_path = ""
            for p in exe_candidates:
                if os.path.exists(p):
                    exe_path = p
                    break
            manager_path = ""
            for p in manager_candidates:
                if os.path.exists(p):
                    manager_path = p
                    break
            icon = os.path.join(target, "assets", "logo", "app.ico")
            if self.desktop_var.get():
                desk = os.path.join(os.path.expanduser("~"), "Desktop")
                if exe_path:
                    self._make_shortcut(exe_path, os.path.join(desk, "本地OCR工作台.lnk"), icon)
                if manager_path:
                    self._make_shortcut(manager_path, os.path.join(desk, "OCR工作台管理器.lnk"), icon)
            if self.startmenu_var.get():
                sm = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "OCRWorkbench")
                try:
                    os.makedirs(sm, exist_ok=True)
                except Exception:
                    pass
                if exe_path:
                    self._make_shortcut(exe_path, os.path.join(sm, "本地OCR工作台.lnk"), icon)
                if manager_path:
                    self._make_shortcut(manager_path, os.path.join(sm, "OCR工作台管理器.lnk"), icon)
            if self.autorun_var.get() and (manager_path or exe_path):
                try:
                    target_run = manager_path or exe_path
                    subprocess.Popen([target_run], cwd=target)
                except Exception:
                    pass
            messagebox.showinfo("完成", "安装已完成")
        except Exception as e:
            messagebox.showerror("安装失败", str(e))
        finally:
            self.root.config(cursor="")

    def _make_shortcut(self, target_exe: str, shortcut_path: str, icon_path: str):
        _create_shortcut(target_exe, shortcut_path, icon_path)

def main():
    if os.name == "nt":
        try:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        except Exception:
            is_admin = False
        if not is_admin:
            ok = _run_elevated()
            if ok:
                return
    root = tk.Tk()
    ui = InstallerUI(root)
    root.geometry("560x240")
    root.mainloop()

if __name__ == "__main__":
    main()
