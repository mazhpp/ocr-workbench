from pathlib import Path
from typing import Any

import streamlit.components.v1 as components


_component = None

def file_dnd(
    active: list[dict],
    removed: list[dict],
    disabled: bool = False,
    key: str | None = None,
) -> Any:
    global _component
    if _component is None:
        _component = components.declare_component(
            "file_dnd",
            path=str(Path(__file__).parent / "frontend"),
        )
    return _component(active=active, removed=removed, disabled=disabled, default=None, key=key)

