from pathlib import Path
from typing import Any

import streamlit.components.v1 as components


_component = None

def camera_auto(disabled: bool = False, ack_seq: int = 0, key: str | None = None, height: int = 680) -> Any:
    global _component
    if _component is None:
        _component = components.declare_component(
            "camera_auto",
            path=str(Path(__file__).parent / "frontend"),
        )
    h = int(height or 680)
    h = max(260, min(1400, h))
    return _component(disabled=disabled, ack_seq=int(ack_seq or 0), default=None, key=key, height=h)
