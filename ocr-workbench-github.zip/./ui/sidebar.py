import streamlit as st
import streamlit.components.v1 as components

import hashlib
import time

from config import (
    DEFAULT_API_BASE_LMSTUDIO,
    DEFAULT_API_BASE_OLLAMA,
    DEFAULT_API_BASE_OPENAI,
    DEFAULT_API_KEY,
    PROMPTS,
    SUPPORTED_MODELS,
)
from core.llm_client import LLMClient
from core.prefs_storage import dump_map, is_valid_url, parse_map
from core.diagnostics import build_diagnostic_report, sanitize_model_name, validate_model_name
from core.logging_utils import get_logger
from core.user_settings import load_user_settings, normalize_user_settings, save_user_settings


def render_sidebar():
    log = get_logger(__name__)
    with st.sidebar:
        st.header("⚙️ 全局配置")
        st.subheader("模型服务设置")

        SERVICE_LABEL_TO_KEY = {"LM Studio": "lmstudio", "Ollama": "ollama", "OpenAI": "openai"}
        SERVICE_KEY_TO_LABEL = {v: k for k, v in SERVICE_LABEL_TO_KEY.items()}
        DEFAULT_BASE_BY_SERVICE = {
            "lmstudio": DEFAULT_API_BASE_LMSTUDIO,
            "ollama": DEFAULT_API_BASE_OLLAMA,
            "openai": DEFAULT_API_BASE_OPENAI,
        }

        KEY_SERVICE_TYPE = "serviceType"
        KEY_CUSTOM_API_URL = "customApiUrl"
        KEY_SELECTED_MODEL = "selectedModel"

        if "diagnostic_report" not in st.session_state:
            st.session_state.diagnostic_report = {}
        if "model_ready" not in st.session_state:
            st.session_state.model_ready = False

        def persist_set(key: str, value: str):
            v = (value or "").strip()
            components.html(
                f"""
                <script>
                  try {{
                    const mem = window.__ocrwb_memstore || (window.__ocrwb_memstore = {{}});
                    function test(s) {{ try {{ const k="__t_"+Math.random(); s.setItem(k,"1"); s.removeItem(k); return true; }} catch(e){{ return false; }} }}
                    const hasLS = test(window.localStorage);
                    const hasSS = test(window.sessionStorage);
                    const store = hasLS ? window.localStorage : (hasSS ? window.sessionStorage : null);
                    const k = {key!r};
                    const val = {v!r};
                    if (store) store.setItem(k, val); else mem[k] = val;
                  }} catch (e) {{}}
                </script>
                """,
                height=0,
            )

        def persist_remove(key: str):
            components.html(
                f"""
                <script>
                  try {{
                    const mem = window.__ocrwb_memstore || (window.__ocrwb_memstore = {{}});
                    function test(s) {{ try {{ const k="__t_"+Math.random(); s.setItem(k,"1"); s.removeItem(k); return true; }} catch(e){{ return false; }} }}
                    const hasLS = test(window.localStorage);
                    const hasSS = test(window.sessionStorage);
                    const store = hasLS ? window.localStorage : (hasSS ? window.sessionStorage : null);
                    const k = {key!r};
                    if (store) store.removeItem(k); else delete mem[k];
                  }} catch (e) {{}}
                </script>
                """,
                height=0,
            )

        components.html(
            """
            <script>
              try {
                const mem = window.__ocrwb_memstore || (window.__ocrwb_memstore = {});
                function test(s) { try { const k="__t_"+Math.random(); s.setItem(k,"1"); s.removeItem(k); return true; } catch(e){ return false; } }
                const hasLS = test(window.localStorage);
                const hasSS = test(window.sessionStorage);
                const store = hasLS ? window.localStorage : (hasSS ? window.sessionStorage : null);
                function get(k) { try { if (store) return store.getItem(k) || ""; return mem[k] || ""; } catch(e){ return mem[k] || ""; } }

                if (!sessionStorage.getItem("ocrwb_bootstrap_v5")) {
                  sessionStorage.setItem("ocrwb_bootstrap_v5", "1");
                  const url = new URL(window.parent.location.href);
                  const stype = get("serviceType");
                  const api = get("customApiUrl");
                  const model = get("selectedModel");
                  if (stype) url.searchParams.set("ls_serviceType", stype);
                  if (api) url.searchParams.set("ls_customApiUrl", api);
                  if (model) url.searchParams.set("ls_selectedModel", model);
                  window.parent.location.href = url.toString();
                }
              } catch (e) {}
            </script>
            """,
            height=0,
        )

        def apply_bootstrap_once():
            if st.session_state.get("ls_applied", False):
                return
            qp = {}
            try:
                qp = st.query_params or {}
            except Exception:
                qp = {}

            stype = qp.get("ls_serviceType", "")
            if isinstance(stype, list):
                stype = stype[0] if stype else ""
            stype = str(stype).strip().lower()

            api_raw = qp.get("ls_customApiUrl", "")
            if isinstance(api_raw, list):
                api_raw = api_raw[0] if api_raw else ""
            api_raw = str(api_raw).strip()

            model_raw = qp.get("ls_selectedModel", "")
            if isinstance(model_raw, list):
                model_raw = model_raw[0] if model_raw else ""
            model_raw = str(model_raw).strip()

            if stype in DEFAULT_BASE_BY_SERVICE:
                st.session_state.service_type = stype
            else:
                st.session_state.service_type = "lmstudio"

            st.session_state.api_url_map = parse_map(api_raw)
            st.session_state.model_map = parse_map(model_raw)
            st.session_state.ls_applied = True

        if "ls_applied" not in st.session_state:
            st.session_state.ls_applied = False
        if "service_type" not in st.session_state:
            st.session_state.service_type = "lmstudio"
        if "api_url_map" not in st.session_state:
            st.session_state.api_url_map = {}
        if "model_map" not in st.session_state:
            st.session_state.model_map = {}
        if "model_list" not in st.session_state:
            st.session_state.model_list = []
        if "last_model_diag" not in st.session_state:
            st.session_state.last_model_diag = {}
        if "model_autoload_done" not in st.session_state:
            st.session_state.model_autoload_done = False
        if "model_autoload_events" not in st.session_state:
            st.session_state.model_autoload_events = []
        if "model_loading" not in st.session_state:
            st.session_state.model_loading = False
        if "model_cache_key" not in st.session_state:
            st.session_state.model_cache_key = ""
        if "model_cache_ts" not in st.session_state:
            st.session_state.model_cache_ts = 0.0

        if not st.session_state.get("fs_applied", False):
            fs = normalize_user_settings(load_user_settings())
            if fs.get("service_type"):
                st.session_state.service_type = fs.get("service_type")
            if fs.get("api_url_map"):
                st.session_state.api_url_map = dict(fs.get("api_url_map") or {})
            if fs.get("model_map"):
                st.session_state.model_map = dict(fs.get("model_map") or {})
            if "temperature" in fs and "temperature_value" not in st.session_state:
                st.session_state.temperature_value = fs.get("temperature")
            if fs.get("task_type") and "task_type_value" not in st.session_state:
                st.session_state.task_type_value = fs.get("task_type")
            if fs.get("prompt") and "prompt_value" not in st.session_state:
                st.session_state.prompt_value = fs.get("prompt")
            st.session_state.fs_applied = True

        apply_bootstrap_once()

        if st.session_state.service_type not in DEFAULT_BASE_BY_SERVICE:
            st.session_state.service_type = "lmstudio"

        def current_default_api() -> str:
            return DEFAULT_BASE_BY_SERVICE.get(st.session_state.service_type, DEFAULT_API_BASE_LMSTUDIO)

        def current_api() -> str:
            return st.session_state.api_url_map.get(st.session_state.service_type) or current_default_api()

        def _probe_cache_key(api_base: str, api_key: str, service_key: str) -> str:
            h = hashlib.sha256()
            h.update((service_key or "").encode("utf-8", errors="ignore"))
            h.update(b"\0")
            h.update((api_base or "").encode("utf-8", errors="ignore"))
            h.update(b"\0")
            h.update((api_key or "").encode("utf-8", errors="ignore"))
            return h.hexdigest()

        def refresh_models(timeout_s: float = 15.0, show_spinner: bool = True, force: bool = False):
            api_base = (st.session_state.get("api_base_input") or "").strip().rstrip("/")
            api_key = st.session_state.get("api_key_input", DEFAULT_API_KEY)
            service_key = st.session_state.get("service_type", "lmstudio")
            cache_key = _probe_cache_key(api_base, api_key, service_key)
            now = time.time()
            cache_ttl_s = 12.0
            if (
                (not force)
                and cache_key
                and cache_key == st.session_state.get("model_cache_key", "")
                and (now - float(st.session_state.get("model_cache_ts") or 0)) < cache_ttl_s
                and st.session_state.get("model_list")
            ):
                return st.session_state.get("model_list") or []

            def run():
                client = LLMClient(base_url=api_base, api_key=api_key, service_type=service_key)
                models, diag = client.list_models_with_diagnostics(timeout_s=float(timeout_s or 15.0))
                st.session_state.last_model_diag = {
                    "service_type": diag.service_type,
                    "base_url_input": diag.base_url_input,
                    "base_url_normalized": diag.base_url_normalized,
                    "probes": diag.probes,
                    "last_error": diag.last_error,
                    "last_error_detail": diag.last_error_detail,
                }
                if models:
                    st.session_state.model_list = models
                    st.session_state.model_cache_key = cache_key
                    st.session_state.model_cache_ts = now
                return models, diag

            t0 = time.perf_counter()
            if show_spinner:
                with st.spinner("正在连接模型服务并获取模型列表..."):
                    models, diag = run()
            else:
                models, diag = run()
            dt_ms = int((time.perf_counter() - t0) * 1000)
            st.session_state.model_autoload_events.append(
                {
                    "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "timeout_s": float(timeout_s or 0),
                    "elapsed_ms": dt_ms,
                    "service_type": service_key,
                    "api_base": api_base,
                    "models_count": len(models or []),
                    "error": getattr(diag, "last_error", "") if diag else "",
                }
            )
            st.session_state.model_autoload_events = st.session_state.model_autoload_events[-60:]
            if diag and getattr(diag, "last_error", ""):
                log.warning("model_probe failed timeout=%ss elapsed=%sms err=%s", timeout_s, dt_ms, diag.last_error)
            else:
                log.info("model_probe ok timeout=%ss elapsed=%sms models=%s", timeout_s, dt_ms, len(models or []))
            return models

        def on_service_change():
            label = st.session_state.get("service_type_label", "LM Studio")
            stype = SERVICE_LABEL_TO_KEY.get(label, "lmstudio")
            st.session_state.service_type = stype
            persist_set(KEY_SERVICE_TYPE, stype)
            st.session_state.api_base_input = current_api()

            preferred = (st.session_state.model_map.get(stype) or "").strip()
            st.session_state.manual_model_name = ""
            if preferred and st.session_state.model_list:
                st.session_state.model_select = preferred
            refresh_models(timeout_s=15.0, show_spinner=True, force=True)

        def on_api_change():
            raw = (st.session_state.get("api_base_input") or "").strip().rstrip("/")
            if not raw:
                st.session_state.api_base_input = current_api()
                st.toast("⚠️ 地址不能为空", icon="⚠️")
                return
            if not is_valid_url(raw):
                st.session_state.api_base_input = current_api()
                st.toast("❌ API 地址格式不正确（需包含 http/https）", icon="❌")
                return
            st.session_state.api_url_map[st.session_state.service_type] = raw
            persist_set(KEY_CUSTOM_API_URL, dump_map(st.session_state.api_url_map))
            refresh_models(timeout_s=15.0, show_spinner=True, force=True)

        if "api_base_input" not in st.session_state:
            st.session_state.api_base_input = current_api()

        service_label = st.selectbox(
            "服务类型",
            options=list(SERVICE_LABEL_TO_KEY.keys()),
            index=list(SERVICE_LABEL_TO_KEY.keys()).index(SERVICE_KEY_TO_LABEL.get(st.session_state.service_type, "LM Studio")),
            key="service_type_label",
            on_change=on_service_change,
        )
        st.session_state.service_type = SERVICE_LABEL_TO_KEY[service_label]

        default_base = current_default_api()
        current_base = (st.session_state.get("api_base_input") or "").strip()
        source = "默认地址" if current_base.rstrip("/") == default_base.rstrip("/") else "用户自定义"
        tooltip = f"当前地址来源：{source}"
        st.markdown(f'<div title="{tooltip}" style="font-size:12px;opacity:0.8;">地址来源：<b>{source}</b></div>', unsafe_allow_html=True)

        api_col, reset_col = st.columns([5, 1])
        with api_col:
            api_base = st.text_input("API 地址", key="api_base_input", on_change=on_api_change, help=f"默认：{default_base}")
        with reset_col:
            if st.button("恢复默认", help="仅此时清除存储并恢复默认地址"):
                st.session_state.api_url_map.pop(st.session_state.service_type, None)
                if st.session_state.api_url_map:
                    persist_set(KEY_CUSTOM_API_URL, dump_map(st.session_state.api_url_map))
                else:
                    persist_remove(KEY_CUSTOM_API_URL)
                st.session_state.api_base_input = current_default_api()
                st.session_state.model_loading = True
                refresh_models(timeout_s=15.0, show_spinner=True, force=True)
                st.session_state.model_loading = False
                st.rerun()

        api_key = st.text_input("API 密钥 (Key)", value=DEFAULT_API_KEY, type="password", key="api_key_input")

        st.subheader("模型设置")

        def persist_model(value: str):
            v = (value or "").strip()
            if not v:
                return
            st.session_state.model_map[st.session_state.service_type] = v
            persist_set(KEY_SELECTED_MODEL, dump_map(st.session_state.model_map))

        def on_model_select_change():
            persist_model(st.session_state.get("model_select", ""))

        def on_manual_model_change():
            raw = st.session_state.get("manual_model_name", "")
            cleaned = sanitize_model_name(raw, max_len=128)
            trimmed = cleaned.strip()
            if trimmed != (raw or ""):
                st.session_state.manual_model_name = trimmed
            if trimmed:
                persist_model(trimmed)

        st.session_state.manual_model_name = (st.session_state.get("manual_model_name") or "")

        col1, col2 = st.columns([3, 1])
        with col2:
            if st.button("🔄", help="手动强制刷新"):
                st.session_state.model_loading = True
                refresh_models(timeout_s=15.0, show_spinner=True, force=True)
                st.session_state.model_loading = False
                st.rerun()

        with col1:
            if st.session_state.model_list:
                if "model_select" not in st.session_state and st.session_state.model_list:
                    preferred = (st.session_state.model_map.get(st.session_state.service_type) or "").strip()
                    if preferred and preferred in st.session_state.model_list:
                        st.session_state.model_select = preferred
                    else:
                        st.session_state.model_select = st.session_state.model_list[0]
                if st.session_state.get("model_select") not in st.session_state.model_list:
                    st.session_state.model_select = st.session_state.model_list[0]
                model_name = st.selectbox(
                    "选择模型（列表模式）",
                    st.session_state.model_list,
                    index=0,
                    key="model_select",
                    on_change=on_model_select_change,
                    help="列表来自服务端 /models 或 Ollama /api/tags；若加载失败可在下方手动输入模型名",
                )
            else:
                st.selectbox(
                    "选择模型（列表模式）",
                    ["（正在加载…）"] if st.session_state.get("model_loading") else ["（暂无模型列表）"],
                    index=0,
                    key="model_select_placeholder",
                    help="列表来自服务端 /models 或 Ollama /api/tags；若加载失败可在下方手动输入模型名",
                )
                model_name = ""

        manual_model = st.text_input(
            "手动输入模型名（可覆盖上方选择）",
            value="",
            key="manual_model_name",
            on_change=on_manual_model_change,
            placeholder="请输入模型名称",
        )
        if manual_model.strip():
            model_name = manual_model.strip()
        if (manual_model or "").strip():
            ok_typing, err_typing = validate_model_name(model_name)
            if not ok_typing:
                st.caption(err_typing)

        if (not (model_name or "").strip()) and st.session_state.get("model_list"):
            picked = (st.session_state.get("model_select") or "").strip()
            model_name = picked if picked in (st.session_state.get("model_list") or []) else (st.session_state.model_list[0] if st.session_state.model_list else "")

        ok_model, model_err = validate_model_name(model_name) if (model_name or "").strip() else (False, "模型名称为空")
        if not ok_model and (model_name or "").strip():
            st.toast(model_err, icon="⚠️")

        if (not st.session_state.get("model_list")) and (not st.session_state.model_autoload_done):
            st.session_state.model_loading = True
            status = st.empty()
            bar = st.progress(0)
            t_start = time.perf_counter()
            ok = False
            last_err = ""
            for attempt in range(5):
                elapsed = time.perf_counter() - t_start
                remaining = 3.0 - elapsed
                if remaining <= 0:
                    break
                timeout_s = max(0.8, min(2.0, remaining))
                status.caption(f"正在自动加载模型（第 {attempt + 1} 次）…")
                bar.progress(min(0.95, (elapsed / 3.0)))
                refresh_models(timeout_s=timeout_s, show_spinner=False, force=False)
                if st.session_state.get("model_list"):
                    if not (st.session_state.get("manual_model_name") or "").strip():
                        preferred = (st.session_state.model_map.get(st.session_state.service_type) or "").strip()
                        if preferred and preferred in st.session_state.model_list:
                            st.session_state.model_select = preferred
                        elif st.session_state.get("model_select") not in st.session_state.model_list:
                            st.session_state.model_select = st.session_state.model_list[0]
                    ok = True
                    break
                last_err = str((st.session_state.get("last_model_diag") or {}).get("last_error", "") or "")[:200]
                if last_err:
                    break
                time.sleep(0.25)
            bar.progress(1.0)
            status.empty()
            st.session_state.model_autoload_done = True
            st.session_state.model_loading = False
            if not ok:
                log.warning("model_autoload_failed err=%s", last_err)
            elif st.session_state.get("model_list"):
                st.rerun()

        report = build_diagnostic_report(
            service_type=st.session_state.get("service_type", "lmstudio"),
            api_base=api_base,
            model_name=model_name,
            model_list=st.session_state.get("model_list") or [],
            last_diag=st.session_state.get("last_model_diag") or {},
        )
        st.session_state.diagnostic_report = report
        st.session_state.model_ready = bool(report.get("ready_for_ocr", False))

        if st.session_state.get("model_loading"):
            light = "🟡"
        else:
            light = "🟢" if st.session_state.model_ready else "🔴"
        st.markdown(f"### {light} 模型状态")
        st.caption("实时检测模型加载与连通性；异常时会阻止 OCR 启动。")
        if (not st.session_state.model_ready) and (not st.session_state.get("model_loading")):
            st.error("模型加载失败，无法启动OCR工作")
        elif st.session_state.get("model_loading"):
            st.info("模型正在加载中…", icon="⏳")
        connect_ok = bool((report.get("connect_test") or {}).get("ok", False))
        if not connect_ok:
            st.warning("模型连接异常")

        st.markdown(
            f"- 服务类型：{report.get('connect_test',{}).get('service_type','')}\n"
            f"- API：{report.get('connect_test',{}).get('api_base','')}\n"
            f"- 模型数：{report.get('connect_test',{}).get('models_count','')}\n"
            f"- 当前模型：{report.get('model_name',{}).get('value','') or '—'}"
        )

        if st.button("一键重试", use_container_width=True):
            st.session_state.model_loading = True
            refresh_models(timeout_s=15.0, show_spinner=True, force=True)
            st.session_state.model_loading = False
            st.rerun()

        with st.expander("诊断报告", expanded=not st.session_state.model_ready):
            st.json(report)

        with st.expander("连接诊断信息", expanded=False):
            diag = st.session_state.get("last_model_diag", {})
            if diag:
                st.json(diag)
            else:
                st.caption("暂无诊断信息。修改地址后按回车或点击刷新按钮。")

        with st.expander("加载日志", expanded=False):
            evs = st.session_state.get("model_autoload_events") or []
            if evs:
                st.json(evs)
            else:
                st.caption("暂无加载日志。")

        if "temperature_value" not in st.session_state:
            st.session_state.temperature_value = 0.1
        temperature = st.slider("随机性 (Temperature)", 0.0, 1.0, float(st.session_state.temperature_value or 0.1), key="temperature_value")

        st.subheader("OCR 任务类型")
        if "task_type_value" not in st.session_state:
            st.session_state.task_type_value = list(PROMPTS.keys())[0] if PROMPTS else ""
        if PROMPTS and (st.session_state.get("task_type_value") not in set(PROMPTS.keys())):
            st.session_state.task_type_value = list(PROMPTS.keys())[0]

        def _on_task_type_change():
            prev = str(st.session_state.get("task_type_prev") or "")
            cur = str(st.session_state.get("task_type_value") or "")
            cur_prompt = str(st.session_state.get("prompt_value") or "")
            if not cur:
                return
            if (not cur_prompt) or (prev and cur_prompt == str(PROMPTS.get(prev, "") or "")):
                st.session_state.prompt_value = str(PROMPTS.get(cur, "") or "")
            st.session_state.task_type_prev = cur

        task_type = st.selectbox("选择任务模式", list(PROMPTS.keys()), key="task_type_value", on_change=_on_task_type_change)
        if "task_type_prev" not in st.session_state:
            st.session_state.task_type_prev = task_type
        if "prompt_value" not in st.session_state:
            st.session_state.prompt_value = str(PROMPTS.get(task_type, "") or "")
        custom_prompt = st.text_area("系统提示词 (System Prompt)", value=str(st.session_state.prompt_value or ""), height=150, key="prompt_value")

        settings = {
            "service_type": st.session_state.get("service_type", "lmstudio"),
            "api_url_map": dict(st.session_state.get("api_url_map") or {}),
            "model_map": dict(st.session_state.get("model_map") or {}),
            "temperature": float(st.session_state.get("temperature_value") or 0.1),
            "task_type": str(st.session_state.get("task_type_value") or ""),
            "prompt": str(st.session_state.get("prompt_value") or ""),
        }
        settings_norm = normalize_user_settings(settings)
        last_saved = st.session_state.get("fs_last_saved") or {}
        if not isinstance(last_saved, dict):
            last_saved = {}
        if settings_norm != last_saved:
            try:
                save_user_settings(settings_norm)
                st.session_state.fs_last_saved = settings_norm
            except Exception:
                pass

        return {
            "api_base": api_base,
            "api_key": api_key,
            "service_type": st.session_state.get("service_type", "lmstudio"),
            "model": model_name,
            "temperature": temperature,
            "prompt": custom_prompt,
        }
