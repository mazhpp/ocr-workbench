import os
import sys
import time
import traceback


APP_PORT = int(os.environ.get("OCRWB_PORT", "8501") or "8501")
APP_HOST = os.environ.get("OCRWB_HOST", "127.0.0.1") or "127.0.0.1"


def _base_dir() -> str:
    if getattr(sys, "frozen", False):
        if hasattr(sys, "_MEIPASS"):
            return sys._MEIPASS
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _work_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.environ.get("OCRWB_DATA_DIR", "") or os.getcwd()
    return os.path.dirname(os.path.abspath(__file__))


def _ensure_runtime_files():
    base = _base_dir()
    wd = _work_dir()
    os.makedirs(os.path.join(wd, ".streamlit"), exist_ok=True)
    src_cfg = os.path.join(base, ".streamlit", "config.toml")
    dst_cfg = os.path.join(wd, ".streamlit", "config.toml")
    if os.path.exists(src_cfg) and not os.path.exists(dst_cfg):
        try:
            with open(src_cfg, "rb") as rf, open(dst_cfg, "wb") as wf:
                wf.write(rf.read())
        except Exception:
            pass


def _write_log(message: str):
    log_dir = os.environ.get("OCRWB_LOG_DIR", "") or ""
    try:
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
            log_path = os.path.join(log_dir, "ocr-workbench.log")
        else:
            log_path = os.path.join(_work_dir(), "ocr-workbench.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(message.rstrip() + "\n")
    except Exception:
        pass


def main():
    os.environ.setdefault("STREAMLIT_GLOBAL_DEVELOPMENT_MODE", "false")
    os.environ.setdefault("STREAMLIT_SERVER_HEADLESS", "true")
    os.environ.setdefault("STREAMLIT_BROWSER_GATHER_USAGE_STATS", "false")
    os.environ.setdefault("STREAMLIT_SERVER_ADDRESS", APP_HOST)
    os.environ.setdefault("STREAMLIT_SERVER_PORT", str(APP_PORT))

    _ensure_runtime_files()
    os.chdir(_work_dir())

    try:
        from streamlit.web import cli as stcli
    except Exception:
        _write_log("import streamlit failed")
        _write_log(traceback.format_exc())
        raise

    sys.argv = [
        "streamlit",
        "run",
        os.path.join(_base_dir(), "app.py"),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--server.address",
        APP_HOST,
        "--server.port",
        str(APP_PORT),
    ]
    _write_log(f"launch streamlit host={APP_HOST} port={APP_PORT}")
    t0 = time.time()
    try:
        stcli.main()
    finally:
        _write_log(f"exit elapsed_s={time.time()-t0:.1f}")


if __name__ == "__main__":
    main()

