import os
import sys
import time
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from urllib.request import urlopen
from urllib.error import URLError

def _base_dir():
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))

def _work_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _find_app_exe():
    wd = _work_dir()
    candidates = [
        os.path.join(wd, "本地OCR工作台.exe"),
        os.path.join(wd, "OCRWorkbench.exe"),
        os.path.join(wd, "dist", "本地OCR工作台.exe"),
        os.path.join(wd, "dist", "OCRWorkbench.exe"),
        os.path.join(wd, "dist", "本地OCR工作台", "本地OCR工作台.exe"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return ""

class ManagerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OCR 工作台 管理器")
        self.proc = None
        self.status_var = tk.StringVar(value="未运行")
        self.port_var = tk.StringVar(value="8501")
        self.log_text = tk.Text(self.root, height=16, wrap="word", state="disabled")
        self._build_ui()
        self._start_monitor()

    def _build_ui(self):
        frm = ttk.Frame(self.root, padding=10)
        frm.pack(fill="both", expand=True)

        top = ttk.Frame(frm)
        top.pack(fill="x")
        ttk.Label(top, text="服务状态：").pack(side="left")
        ttk.Label(top, textvariable=self.status_var, foreground="#0a84ff").pack(side="left")
        ttk.Label(top, text="端口：").pack(side="left", padx=(12, 2))
        port_entry = ttk.Entry(top, textvariable=self.port_var, width=8)
        port_entry.pack(side="left")
        ttk.Button(top, text="打开界面", command=self._open_ui).pack(side="right")

        btns = ttk.Frame(frm)
        btns.pack(fill="x", pady=8)
        ttk.Button(btns, text="启动", command=self.start_service).pack(side="left")
        ttk.Button(btns, text="停止", command=self.stop_service).pack(side="left", padx=6)
        ttk.Button(btns, text="重启", command=self.restart_service).pack(side="left")
        ttk.Button(btns, text="查看日志文件", command=self._open_log_folder).pack(side="right")

        ttk.Label(frm, text="实时日志：").pack(anchor="w")
        self.log_text.pack(fill="both", expand=True)

        bottom = ttk.Frame(frm)
        bottom.pack(fill="x", pady=(8, 0))
        ttk.Button(bottom, text="选择工作台可执行文件", command=self._pick_exe).pack(side="left")

    def _pick_exe(self):
        path = filedialog.askopenfilename(title="选择 本地OCR工作台.exe", filetypes=[("EXE", "*.exe")])
        if path:
            os.environ["OCRWB_EXE_OVERRIDE"] = path

    def _open_ui(self):
        port = self._port_int()
        url = f"http://localhost:{port}/"
        try:
            os.startfile(url)
        except Exception:
            messagebox.showinfo("提示", f"无法打开浏览器，请手动访问：{url}")

    def _open_log_folder(self):
        p = os.path.join(_work_dir(), "logs")
        if not os.path.exists(p):
            p = _work_dir()
        try:
            os.startfile(p)
        except Exception:
            messagebox.showinfo("提示", f"日志目录：{p}")

    def _port_int(self):
        try:
            v = int(self.port_var.get() or "8501")
        except Exception:
            v = 8501
        return max(1, min(65535, v))

    def start_service(self):
        if self.proc and self.proc.poll() is None:
            return
        app_exe = os.environ.get("OCRWB_EXE_OVERRIDE") or _find_app_exe()
        env = os.environ.copy()
        env["STREAMLIT_SERVER_PORT"] = str(self._port_int())
        if app_exe and os.path.exists(app_exe):
            try:
                self.proc = subprocess.Popen([app_exe], cwd=_work_dir(), env=env)
            except Exception:
                self.proc = None
        else:
            py = sys.executable
            target = os.path.join(_base_dir(), "run_exe.py")
            if not os.path.exists(target):
                target = os.path.join(_work_dir(), "run_exe.py")
            try:
                self.proc = subprocess.Popen([py, target], cwd=_work_dir(), env=env)
            except Exception:
                self.proc = None

    def stop_service(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        self.proc = None

    def restart_service(self):
        self.stop_service()
        time.sleep(0.2)
        self.start_service()

    def _monitor_once(self):
        port = self._port_int()
        url = f"http://localhost:{port}/"
        try:
            urlopen(url, timeout=0.6)
            self.status_var.set("运行中")
        except URLError:
            self.status_var.set("未运行")
        except Exception:
            self.status_var.set("未运行")
        self._tail_logs()

    def _tail_logs(self):
        paths = [
            os.path.join(_work_dir(), "exe.log"),
            os.path.join(_work_dir(), "logs", "app.log"),
        ]
        buf = []
        for p in paths:
            try:
                if os.path.exists(p):
                    with open(p, "r", encoding="utf-8", errors="ignore") as f:
                        lines = f.readlines()[-300:]
                        buf.extend(lines)
            except Exception:
                pass
        text = "".join(buf[-800:])
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.insert("end", text)
        self.log_text.config(state="disabled")

    def _start_monitor(self):
        def loop():
            while True:
                try:
                    self._monitor_once()
                except Exception:
                    pass
                time.sleep(1.0)
        t = threading.Thread(target=loop, daemon=True)
        t.start()

def main():
    root = tk.Tk()
    app = ManagerApp(root)
    root.geometry("780x520")
    root.mainloop()

if __name__ == "__main__":
    main()
