# 打包为 EXE（Windows）

本项目基于 Streamlit，打包后的 EXE 会在本机启动一个本地 Web 服务，并自动打开浏览器访问界面。

## 1) 构建环境要求

- Windows 10/11
- Python 3.11（建议与开发环境一致）
- 已安装项目依赖：`pip install -r requirements.txt`

## 2) 一键构建

任选其一：

- PowerShell：双击运行 [build_exe.ps1](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/build_exe.ps1)
- CMD：双击运行 [build_exe.bat](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/build_exe.bat)
- 单文件 EXE（推荐）：双击运行 [build_exe_onefile.ps1](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/build_exe_onefile.ps1) 或 [build_exe_onefile.bat](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/build_exe_onefile.bat)

输出目录：

- `dist/本地OCR工作台/本地OCR工作台.exe`
- `dist/本地OCR工作台.exe`

## 2.1 构建管理器与安装向导

- 构建管理器：[build_manager.ps1](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/build_manager.ps1)
- 构建安装程序：[build_installer.ps1](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/build_installer.ps1)

输出目录：

- 管理器：`dist/OCRWorkbenchManager.exe`
- 安装程序：`dist/OCRWorkbenchSetup.exe`

## 3) 运行 EXE

双击 `dist/本地OCR工作台.exe`（单文件）或 `dist/本地OCR工作台/本地OCR工作台.exe`（目录版）。

- 默认使用端口 `8501`
- 程序会尝试自动打开浏览器访问 `http://localhost:8501`（如端口被占用，Streamlit 可能自动切换端口）

## 4) 常见问题

### 4.1 无法打开页面/端口被占用

如果 `8501` 被占用，可能无法启动或浏览器打不开。

- 关闭占用 8501 的程序后重试
- 或修改 [run_exe.py](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/run_exe.py) 中的 `--server.port` 为其他端口

### 4.2 杀毒软件误报

PyInstaller 打包的 EXE 有时会被误报。

- 建议将 `dist/本地OCR工作台/` 加入白名单后再运行

### 4.3 体积较大

Streamlit + PyMuPDF + Pillow 打包后体积会较大，属于正常现象。

## 5) 图标与品牌资源

- 程序图标在 [assets/logo](file:///e:/mazhp/%E6%A1%8C%E9%9D%A2/OCR%E9%A1%B9%E7%9B%AE%E5%BC%80%E5%8F%91/assets/logo) 下维护
- 构建脚本会自动生成 ICO/PNG（如需自定义，可替换 `assets/logo/app.ico` 与 `assets/logo/favicon.png`）
