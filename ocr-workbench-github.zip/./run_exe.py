import os
import sys
import threading
import time
import webbrowser
import traceback


def _base_dir() -> str:
    if getattr(sys, "frozen", False):
        if hasattr(sys, "_MEIPASS"):
            return sys._MEIPASS
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _work_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _ensure_runtime_files():
    base = _base_dir()
    wd = _work_dir()
    os.makedirs(os.path.join(wd, ".streamlit"), exist_ok=True)
    src_cfg = os.path.join(base, ".streamlit", "config.toml")
    dst_cfg = os.path.join(wd, ".streamlit", "config.toml")
    if os.path.exists(src_cfg) and not os.path.exists(dst_cfg):
        try:
            with open(src_cfg, "rb") as rf, open(dst_cfg, "wb") as wf:
                wf.write(rf.read())
        except Exception:
            pass

def _write_log(message: str):
    try:
        log_path = os.path.join(_work_dir(), "exe.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(message.rstrip() + "\n")
    except Exception:
        pass


def _open_browser(url: str):
    time.sleep(1.2)
    try:
        webbrowser.open(url)
    except Exception:
        pass


def main():
    _write_log("start")
    _write_log(f"frozen={getattr(sys, 'frozen', False)}")
    _write_log(f"work_dir={_work_dir()}")
    _write_log(f"base_dir={_base_dir()}")

    os.environ.setdefault("STREAMLIT_GLOBAL_DEVELOPMENT_MODE", "false")
    os.environ.setdefault("STREAMLIT_SERVER_HEADLESS", "true")
    os.environ.setdefault("STREAMLIT_BROWSER_GATHER_USAGE_STATS", "false")
    os.environ.setdefault("STREAMLIT_SERVER_ADDRESS", "localhost")

    _ensure_runtime_files()
    os.chdir(_work_dir())

    try:
        from streamlit.web import cli as stcli
    except Exception:
        _write_log("import streamlit failed")
        _write_log(traceback.format_exc())
        raise

    url = "http://localhost:8501"
    threading.Thread(target=_open_browser, args=(url,), daemon=True).start()

    sys.argv = [
        "streamlit",
        "run",
        os.path.join(_base_dir(), "app.py"),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--server.address",
        "localhost",
        "--server.port",
        "8501",
    ]
    _write_log("launch streamlit")
    try:
        stcli.main()
    except SystemExit as e:
        _write_log(f"streamlit exited code={getattr(e, 'code', None)}")
        raise
    except BaseException:
        _write_log("streamlit crashed")
        _write_log(traceback.format_exc())
        raise
    else:
        _write_log("streamlit exited normally")


if __name__ == "__main__":
    main()
