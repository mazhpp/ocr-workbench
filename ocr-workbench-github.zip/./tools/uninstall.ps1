param(
  [string]$InstallDir = "",
  [string]$StartMenuDir = "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\OCRWorkbench"
)

$ErrorActionPreference = "Stop"

if ($InstallDir -and (Test-Path $InstallDir)) {
  Write-Host "Removing install dir: $InstallDir"
  try { Remove-Item -Path $InstallDir -Recurse -Force } catch {}
}

if (Test-Path $StartMenuDir) {
  Write-Host "Removing start menu dir: $StartMenuDir"
  try { Remove-Item -Path $StartMenuDir -Recurse -Force } catch {}
}

Write-Host "Uninstall complete."
