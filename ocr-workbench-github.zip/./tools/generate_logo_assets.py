import os
from pathlib import Path

from PIL import Image, ImageDraw


SIZES = [16, 32, 48, 64, 128, 256]


def _rounded_rect(draw: ImageDraw.ImageDraw, xy, r: int, fill):
    x0, y0, x1, y1 = xy
    draw.rounded_rectangle([x0, y0, x1, y1], radius=r, fill=fill)


def _draw_logo_rgba(size: int, scheme: str) -> Image.Image:
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)

    if scheme == "blue":
        bg = (33, 150, 243, 255)
        accent = (0, 229, 255, 255)
    elif scheme == "teal":
        bg = (0, 150, 136, 255)
        accent = (76, 255, 200, 255)
    else:
        bg = (64, 81, 181, 255)
        accent = (255, 193, 7, 255)

    pad = max(1, int(size * 0.05))
    r = max(2, int(size * 0.18))
    _rounded_rect(d, (pad, pad, size - pad, size - pad), r=r, fill=bg)

    doc_w = int(size * 0.54)
    doc_h = int(size * 0.64)
    doc_x = int(size * 0.26)
    doc_y = int(size * 0.18)
    doc_r = max(2, int(size * 0.08))
    _rounded_rect(d, (doc_x, doc_y, doc_x + doc_w, doc_y + doc_h), r=doc_r, fill=(255, 255, 255, 230))

    fold = int(size * 0.16)
    d.polygon(
        [
            (doc_x + doc_w - fold, doc_y),
            (doc_x + doc_w, doc_y),
            (doc_x + doc_w, doc_y + fold),
        ],
        fill=(255, 255, 255, 255),
    )
    d.line(
        [
            (doc_x + doc_w - fold, doc_y),
            (doc_x + doc_w - fold, doc_y + fold),
            (doc_x + doc_w, doc_y + fold),
        ],
        fill=(210, 220, 240, 255),
        width=max(1, int(size * 0.02)),
        joint="curve",
    )

    t = max(1, int(size * 0.06))
    corner = int(size * 0.14)
    x0, y0 = int(size * 0.14), int(size * 0.14)
    x1, y1 = int(size * 0.86), int(size * 0.86)
    d.line([(x0, y0 + corner), (x0, y0), (x0 + corner, y0)], fill=accent, width=t)
    d.line([(x1 - corner, y0), (x1, y0), (x1, y0 + corner)], fill=accent, width=t)
    d.line([(x0, y1 - corner), (x0, y1), (x0 + corner, y1)], fill=accent, width=t)
    d.line([(x1 - corner, y1), (x1, y1), (x1, y1 - corner)], fill=accent, width=t)

    def draw_O(x, y, w, h):
        d.rounded_rectangle([x, y, x + w, y + h], radius=max(1, int(w * 0.35)), outline=(20, 35, 60, 255), width=max(1, int(size * 0.04)))

    def draw_C(x, y, w, h):
        sw = max(1, int(size * 0.04))
        d.arc([x, y, x + w, y + h], start=45, end=315, fill=(20, 35, 60, 255), width=sw)

    def draw_R(x, y, w, h):
        sw = max(1, int(size * 0.04))
        d.line([(x, y), (x, y + h)], fill=(20, 35, 60, 255), width=sw)
        d.arc([x, y, x + w, y + int(h * 0.70)], start=270, end=90, fill=(20, 35, 60, 255), width=sw)
        d.line([(x + int(w * 0.45), y + int(h * 0.55)), (x + w, y + h)], fill=(20, 35, 60, 255), width=sw)

    word_y = doc_y + int(doc_h * 0.58)
    word_x = doc_x + int(doc_w * 0.12)
    letter_w = int(doc_w * 0.23)
    letter_h = int(doc_h * 0.27)
    gap = int(doc_w * 0.08)
    draw_O(word_x, word_y, letter_w, letter_h)
    draw_C(word_x + letter_w + gap, word_y, letter_w, letter_h)
    draw_R(word_x + (letter_w + gap) * 2, word_y, letter_w, letter_h)

    for i in range(3):
        y = doc_y + int(doc_h * (0.18 + i * 0.12))
        d.rounded_rectangle(
            [doc_x + int(doc_w * 0.14), y, doc_x + int(doc_w * 0.86), y + max(1, int(size * 0.03))],
            radius=max(1, int(size * 0.02)),
            fill=(210, 220, 240, 255),
        )

    return im


def _write_svg(out_dir: Path):
    svg = """<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
  <defs>
    <style><![CDATA[
      .bg { fill: #2196F3; }
      .accent { stroke: #00E5FF; stroke-width: 56; stroke-linecap: round; stroke-linejoin: round; fill: none; }
      .doc { fill: rgba(255,255,255,0.92); }
      .stroke { stroke: #14233C; stroke-width: 42; stroke-linecap: round; stroke-linejoin: round; fill: none; }
      .line { fill: #D2DCF0; }
    ]]></style>
  </defs>
  <rect x="52" y="52" width="920" height="920" rx="168" class="bg"/>
  <path class="accent" d="M164 308 V164 H308"/>
  <path class="accent" d="M716 164 H860 V308"/>
  <path class="accent" d="M164 716 V860 H308"/>
  <path class="accent" d="M716 860 H860 V716"/>
  <rect x="266" y="184" width="552" height="656" rx="80" class="doc"/>
  <path d="M726 184 H818 V276 Z" fill="#FFFFFF"/>
  <path d="M726 184 V276 H818" fill="none" stroke="#D2DCF0" stroke-width="18" stroke-linejoin="round"/>
  <rect x="342" y="284" width="400" height="32" rx="16" class="line"/>
  <rect x="342" y="360" width="400" height="32" rx="16" class="line"/>
  <rect x="342" y="436" width="400" height="32" rx="16" class="line"/>
  <path class="stroke" d="M352 700 a78 78 0 0 0 156 0 a78 78 0 0 0 -156 0 Z"/>
  <path class="stroke" d="M576 700 a78 78 0 0 0 156 0"/>
  <path class="stroke" d="M768 760 V640"/>
  <path class="stroke" d="M768 640 h70 a62 62 0 0 1 0 124 h-70"/>
  <path class="stroke" d="M818 708 l90 92"/>
</svg>
"""
    (out_dir / "logo_source.svg").write_text(svg, encoding="utf-8")
    (out_dir / "logo_source.ai").write_text(svg, encoding="utf-8")


def main():
    root = Path(__file__).resolve().parents[1]
    out_dir = root / "assets" / "logo"
    png_dir = out_dir / "png"
    out_dir.mkdir(parents=True, exist_ok=True)
    png_dir.mkdir(parents=True, exist_ok=True)

    _write_svg(out_dir)

    for scheme in ["blue", "teal"]:
        imgs = []
        for s in SIZES:
            im = _draw_logo_rgba(s, scheme=scheme)
            imgs.append(im)
            im.save(png_dir / f"app_{scheme}_{s}.png")
        ico_path = out_dir / f"app_{scheme}.ico"
        base = _draw_logo_rgba(256, scheme=scheme)
        base.save(ico_path, sizes=[(s, s) for s in SIZES])

    (out_dir / "app.ico").write_bytes((out_dir / "app_blue.ico").read_bytes())
    (out_dir / "favicon.png").write_bytes((png_dir / "app_blue_32.png").read_bytes())

    print(f"written: {out_dir}")


if __name__ == "__main__":
    main()
