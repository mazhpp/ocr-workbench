#!/usr/bin/env bash
set -euo pipefail

pkg="${1:-}"
key_id="${2:-}"
if [ -z "$pkg" ] || [ -z "$key_id" ]; then
  echo "usage: $0 <package.deb> <gpg-key-id>"
  exit 2
fi

command -v dpkg-sig >/dev/null 2>&1 || { echo "dpkg-sig not found"; exit 1; }
dpkg-sig --sign builder -k "$key_id" "$pkg"

