$ErrorActionPreference = "Stop"

$Version = $env:OCRWB_VERSION
if (-not $Version) { $Version = "1.0.0" }

$OutDir = Join-Path (Get-Location) "dist\linux"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

docker run --rm `
  -e OCRWB_VERSION=$Version `
  -v "${PWD}:/work" `
  -w /work `
  python:3.11-slim `
  bash -lc @'
set -euo pipefail
apt-get update
apt-get install -y --no-install-recommends build-essential curl ca-certificates patchelf upx-ucl
python -m pip install --upgrade pip
python -m pip install --no-cache-dir pyinstaller
python -m pip install --no-cache-dir -r requirements.txt
mkdir -p dist/linux
pyinstaller --noconfirm --clean ocr_workbench_linux_onefile.spec
cp -f dist/ocr-workbench dist/linux/ocr-workbench
chmod +x dist/linux/ocr-workbench
'@

docker run --rm `
  -e OCRWB_VERSION=$Version `
  -v "${PWD}:/work" `
  -w /work `
  goreleaser/nfpm:v2 `
  pkg --packager deb -f packaging/nfpm.yaml -t dist/linux

docker run --rm `
  -e OCRWB_VERSION=$Version `
  -v "${PWD}:/work" `
  -w /work `
  goreleaser/nfpm:v2 `
  pkg --packager rpm -f packaging/nfpm.yaml -t dist/linux

Write-Host "Build complete:"
Get-ChildItem dist\linux | Format-Table Name,Length,LastWriteTime
