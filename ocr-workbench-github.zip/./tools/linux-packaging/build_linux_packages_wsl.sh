#!/usr/bin/env bash
set -euo pipefail

VERSION="${OCRWB_VERSION:-1.0.0}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT_DIR="$ROOT_DIR/dist/linux"

mkdir -p "$OUT_DIR"

apt-get update
apt-get install -y --no-install-recommends \
  python3 python3-venv python3-pip \
  build-essential patchelf curl ca-certificates \
  rpm

python3 -m venv "$ROOT_DIR/.venv-linux"
source "$ROOT_DIR/.venv-linux/bin/activate"
python -m pip install --upgrade pip
python -m pip install --no-cache-dir pyinstaller
python -m pip install --no-cache-dir -r "$ROOT_DIR/requirements_linux.txt"

cd "$ROOT_DIR"
rm -rf dist/ocr-workbench build/ocr_workbench_linux_onefile || true
pyinstaller --noconfirm --clean ocr_workbench_linux_onefile.spec
mkdir -p dist/linux
cp -f dist/ocr-workbench dist/linux/ocr-workbench
chmod +x dist/linux/ocr-workbench

NFPM_BIN="$ROOT_DIR/.cache/nfpm"
mkdir -p "$(dirname "$NFPM_BIN")"
if [ ! -x "$NFPM_BIN" ]; then
  url="https://github.com/goreleaser/nfpm/releases/download/v2.41.3/nfpm_2.41.3_Linux_x86_64.tar.gz"
  curl -fsSL "$url" -o /tmp/nfpm.tgz
  tar -xzf /tmp/nfpm.tgz -C /tmp nfpm
  mv /tmp/nfpm "$NFPM_BIN"
  chmod +x "$NFPM_BIN"
fi

export OCRWB_VERSION="$VERSION"
"$NFPM_BIN" pkg --packager deb -f packaging/nfpm.yaml -t dist/linux
"$NFPM_BIN" pkg --packager rpm -f packaging/nfpm.yaml -t dist/linux

echo "Build complete: $OUT_DIR"
ls -lah "$OUT_DIR"
