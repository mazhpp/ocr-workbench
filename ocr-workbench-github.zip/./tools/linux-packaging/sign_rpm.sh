#!/usr/bin/env bash
set -euo pipefail

pkg="${1:-}"
if [ -z "$pkg" ]; then
  echo "usage: $0 <package.rpm>"
  exit 2
fi

command -v rpmsign >/dev/null 2>&1 || { echo "rpmsign not found"; exit 1; }
rpmsign --addsign "$pkg"

