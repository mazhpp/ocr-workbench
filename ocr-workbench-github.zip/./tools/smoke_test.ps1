$ErrorActionPreference = "Stop"

$manager = ".\dist\OCRWorkbenchManager.exe"
if (-Not (Test-Path $manager)) {
  Write-Error "Manager not found: $manager"
}

$p = Start-Process -FilePath $manager -PassThru
Start-Sleep -Seconds 3
if ($p.HasExited) {
  Write-Error "Manager exited unexpectedly."
} else {
  Write-Host "Manager running (PID=$($p.Id)). Killing..."
  try { $p.CloseMainWindow() | Out-Null } catch {}
  try { Stop-Process -Id $p.Id -Force } catch {}
  Write-Host "OK"
}
