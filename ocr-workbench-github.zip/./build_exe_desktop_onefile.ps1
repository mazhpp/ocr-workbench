$ErrorActionPreference = "Stop"

python -m pip install --upgrade pip
python -m pip install --upgrade pyinstaller
python -m pip install -r requirements.txt

python tools\generate_logo_assets.py

pyinstaller --noconfirm --clean ocr_workbench_desktop_onefile.spec

Write-Host ""
Write-Host "Build finished."
Write-Host "Output: .\dist\本地OCR工作台.exe"

