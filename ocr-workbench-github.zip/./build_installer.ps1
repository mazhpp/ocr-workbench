$ErrorActionPreference = "Stop"

python -m pip install --upgrade pip
python -m pip install --upgrade pyinstaller

if (-Not (Test-Path ".\dist\本地OCR工作台.exe") -and -Not (Test-Path ".\dist\本地OCR工作台\本地OCR工作台.exe")) {
  Write-Host "Building workbench (onefile) ..."
  pyinstaller --noconfirm --clean ocr_workbench_onefile.spec
}
if (-Not (Test-Path ".\dist\OCRWorkbenchManager.exe")) {
  Write-Host "Building manager ..."
  pyinstaller --noconfirm --clean manager_gui.spec
}

pyinstaller --noconfirm --clean installer.spec

Write-Host ""
Write-Host "Installer finished."
Write-Host "Output: .\dist\OCRWorkbenchSetup.exe"
