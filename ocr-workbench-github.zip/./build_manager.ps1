$ErrorActionPreference = "Stop"

python -m pip install --upgrade pip
python -m pip install --upgrade pyinstaller

pyinstaller --noconfirm --clean manager_gui.spec

Write-Host ""
Write-Host "Build finished."
Write-Host "Output: .\dist\OCRWorkbenchManager.exe"
