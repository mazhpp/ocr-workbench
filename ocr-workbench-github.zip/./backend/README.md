# OCR Batch System

## Services

- API: FastAPI + OpenAPI
- Queue: RabbitMQ (broker) + Celery worker
- Result backend: Redis

## Run (Docker)

1. Start dependencies:

   - RabbitMQ: http://localhost:15672 (guest/guest)
   - Redis: localhost:6379

2. Start API:

   - `uvicorn backend.app.main:app --reload --port 9000`

3. Start worker:

   - `celery -A backend.app.celery_app.celery_app worker -Q ocr -c 20 -l INFO`

