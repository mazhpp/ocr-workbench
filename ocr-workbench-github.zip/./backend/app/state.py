import json
import time
from dataclasses import dataclass, field

import redis

from backend.app.settings import settings


@dataclass
class Item:
    file_id: str
    filename: str
    path: str
    content_type: str
    priority: int
    status: str = "queued"
    error: str = ""
    percent: float = 0.0
    current_page: int = 0
    total_pages: int = 0
    queue_position: int | None = None
    created_at: float = field(default_factory=lambda: time.time())
    started_at: float | None = None
    finished_at: float | None = None
    celery_task_id: str = ""


_r: redis.Redis | None = None


def _redis() -> redis.Redis:
    global _r
    if _r is None:
        _r = redis.Redis.from_url(settings.result_backend, decode_responses=True)
    return _r


def _k_batch(batch_id: str) -> str:
    return f"batch:{batch_id}"


def _k_item(file_id: str) -> str:
    return f"item:{file_id}"


def _to_dict(it: Item) -> dict:
    return {
        "file_id": it.file_id,
        "filename": it.filename,
        "path": it.path,
        "content_type": it.content_type,
        "priority": int(it.priority),
        "status": it.status,
        "error": it.error,
        "percent": float(it.percent),
        "current_page": int(it.current_page),
        "total_pages": int(it.total_pages),
        "queue_position": it.queue_position,
        "created_at": float(it.created_at),
        "started_at": it.started_at,
        "finished_at": it.finished_at,
        "celery_task_id": it.celery_task_id,
    }


def _from_dict(d: dict) -> Item:
    return Item(
        file_id=str(d.get("file_id") or ""),
        filename=str(d.get("filename") or ""),
        path=str(d.get("path") or ""),
        content_type=str(d.get("content_type") or ""),
        priority=int(d.get("priority") or 0),
        status=str(d.get("status") or "queued"),
        error=str(d.get("error") or ""),
        percent=float(d.get("percent") or 0.0),
        current_page=int(d.get("current_page") or 0),
        total_pages=int(d.get("total_pages") or 0),
        queue_position=(int(d["queue_position"]) if d.get("queue_position") is not None else None),
        created_at=float(d.get("created_at") or time.time()),
        started_at=(float(d["started_at"]) if d.get("started_at") is not None else None),
        finished_at=(float(d["finished_at"]) if d.get("finished_at") is not None else None),
        celery_task_id=str(d.get("celery_task_id") or ""),
    )


def create_batch(batch_id: str, ordered_file_ids: list[str]):
    _redis().set(_k_batch(batch_id), json.dumps(list(ordered_file_ids), ensure_ascii=False))


def get_batch(batch_id: str) -> list[str]:
    raw = _redis().get(_k_batch(batch_id))
    if not raw:
        return []
    try:
        arr = json.loads(raw)
        return [str(x) for x in (arr or [])]
    except Exception:
        return []


def upsert_item(item: Item):
    _redis().set(_k_item(item.file_id), json.dumps(_to_dict(item), ensure_ascii=False))


def get_item(file_id: str) -> Item | None:
    raw = _redis().get(_k_item(file_id))
    if not raw:
        return None
    try:
        return _from_dict(json.loads(raw))
    except Exception:
        return None


def list_items(file_ids: list[str]) -> list[Item]:
    out = []
    for fid in file_ids:
        it = get_item(fid)
        if it:
            out.append(it)
    return out


def set_positions(batch_id: str):
    ids = get_batch(batch_id)
    waiting = []
    for fid in ids:
        it = get_item(fid)
        if not it:
            continue
        if it.status in {"queued"}:
            waiting.append(fid)
    for idx, fid in enumerate(waiting, start=1):
        it = get_item(fid)
        if it:
            it.queue_position = idx
            upsert_item(it)

