import os
import uuid

from backend.app.settings import settings


def ensure_dirs():
    os.makedirs(settings.storage_dir, exist_ok=True)
    os.makedirs(os.path.join(settings.storage_dir, "files"), exist_ok=True)
    os.makedirs(os.path.join(settings.storage_dir, "previews"), exist_ok=True)
    os.makedirs(os.path.join(settings.storage_dir, "results"), exist_ok=True)


def new_id() -> str:
    return uuid.uuid4().hex


def file_path(file_id: str, filename: str) -> str:
    safe_name = "".join([c for c in (filename or "") if c.isalnum() or c in "._- "]).strip() or "file"
    ensure_dirs()
    return os.path.join(settings.storage_dir, "files", f"{file_id}_{safe_name}")


def result_path(file_id: str) -> str:
    ensure_dirs()
    return os.path.join(settings.storage_dir, "results", f"{file_id}.md")


def preview_dir(file_id: str) -> str:
    ensure_dirs()
    d = os.path.join(settings.storage_dir, "previews", file_id)
    os.makedirs(d, exist_ok=True)
    return d

