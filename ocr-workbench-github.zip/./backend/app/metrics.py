import time

from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest


http_requests_total = Counter("ocr_http_requests_total", "HTTP requests", ["method", "path", "status"])
http_request_duration_s = Histogram("ocr_http_request_duration_s", "HTTP request duration (s)", ["path"])


def record(method: str, path: str, status: int, duration_s: float):
    http_requests_total.labels(method=method, path=path, status=str(status)).inc()
    http_request_duration_s.labels(path=path).observe(max(0.0, float(duration_s)))


def metrics_response():
    payload = generate_latest()
    return payload, CONTENT_TYPE_LATEST


class Timer:
    def __init__(self):
        self.t0 = time.time()

    def done(self) -> float:
        return time.time() - self.t0

