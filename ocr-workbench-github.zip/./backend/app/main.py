import os
from typing import Any

from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import Response

from backend.app import metrics
from backend.app.auth import authenticate, create_access_token, require_user
from backend.app.celery_app import celery_app
from backend.app.ratelimit import rate_limit
from backend.app.schemas import BatchStatus, FileEnqueueResponse, LoginRequest, LoginResponse, TaskProgress, TaskStatus
from backend.app.settings import settings
from backend.app.state import Item, create_batch, get_batch, get_item, list_items, set_positions, upsert_item
from backend.app.storage import file_path, new_id, preview_dir, result_path
from backend.app.tasks import process_file


app = FastAPI(title="OCR Batch API", version="0.1.0")


@app.middleware("http")
async def _metrics_mw(request: Request, call_next):
    t = metrics.Timer()
    try:
        resp = await call_next(request)
    except Exception:
        metrics.record(request.method, request.url.path, 500, t.done())
        raise
    metrics.record(request.method, request.url.path, resp.status_code, t.done())
    return resp


@app.get("/metrics")
def get_metrics():
    data, ctype = metrics.metrics_response()
    return Response(content=data, media_type=ctype)


@app.post("/v1/auth/login", response_model=LoginResponse, dependencies=[Depends(rate_limit)])
def login(req: LoginRequest):
    if not authenticate(req.username, req.password):
        raise HTTPException(status_code=401, detail="invalid_credentials")
    return LoginResponse(access_token=create_access_token(req.username))


def _validate_size(raw: bytes):
    max_mb = int(getattr(settings, "max_file_size_mb", 0) or 0)
    if max_mb <= 0:
        return
    max_bytes = max_mb * 1024 * 1024
    if len(raw) > max_bytes:
        raise HTTPException(status_code=413, detail="file_too_large")


def _priority(p: Any) -> int:
    try:
        v = int(p)
    except Exception:
        v = 5
    return max(0, min(9, v))


def _config_from_headers(request: Request) -> dict:
    return {
        "api_base": request.headers.get("x-ocr-api-base", ""),
        "api_key": request.headers.get("x-ocr-api-key", ""),
        "service_type": request.headers.get("x-ocr-service-type", "auto"),
        "model": request.headers.get("x-ocr-model", ""),
        "temperature": float(request.headers.get("x-ocr-temperature", "0.1") or 0.1),
        "prompt": request.headers.get("x-ocr-prompt", ""),
    }


@app.post("/v1/files:enqueue", response_model=FileEnqueueResponse, dependencies=[Depends(rate_limit), Depends(require_user)])
async def enqueue_files(
    request: Request,
    files: list[UploadFile] = File(...),
    priority: int = 5,
):
    batch_id = new_id()
    ordered: list[str] = []
    prio = _priority(priority)

    config = _config_from_headers(request)

    for f in files:
        raw = await f.read()
        _validate_size(raw)
        fid = new_id()
        path = file_path(fid, f.filename or "file")
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "wb") as out:
            out.write(raw)
        it = Item(
            file_id=fid,
            filename=f.filename or "file",
            path=path,
            content_type=f.content_type or "",
            priority=prio,
            status="queued",
        )
        upsert_item(it)
        ordered.append(fid)

    create_batch(batch_id, ordered)
    set_positions(batch_id)

    for idx, fid in enumerate(ordered):
        it = get_item(fid)
        if not it:
            continue
        res = celery_app.send_task(
            process_file.name,
            args=[fid, config],
            queue="ocr",
            priority=int(it.priority),
        )
        it.celery_task_id = res.id or ""
        upsert_item(it)

    return FileEnqueueResponse(batch_id=batch_id, file_ids=ordered)


def _to_status(it: Item) -> TaskStatus:
    prog = TaskProgress(
        percent=float(it.percent or 0.0),
        current_page=int(it.current_page or 0),
        total_pages=int(it.total_pages or 0),
        eta_seconds=None,
    )
    status_map = {
        "queued": "排队中",
        "running": "处理中",
        "success": "处理完成",
        "failed": "失败",
    }
    return TaskStatus(
        file_id=it.file_id,
        filename=it.filename,
        status=status_map.get(it.status, it.status),
        error=it.error or "",
        progress=prog,
        queue_position=it.queue_position,
        created_at=it.created_at,
        started_at=it.started_at,
        finished_at=it.finished_at,
    )


@app.get("/v1/batches/{batch_id}", response_model=BatchStatus, dependencies=[Depends(rate_limit), Depends(require_user)])
def get_batch_status(batch_id: str):
    ids = get_batch(batch_id)
    items = list_items(ids)
    set_positions(batch_id)
    out = [_to_status(it) for it in items]

    done_states = {"success", "failed"}
    done = sum(1 for it in items if it.status in done_states)
    success = sum(1 for it in items if it.status == "success")
    failed = sum(1 for it in items if it.status == "failed")
    running = next((it.file_id for it in items if it.status == "running"), None)
    waiting = sum(1 for it in items if it.status == "queued")
    failed_list = [_to_status(it) for it in items if it.status == "failed"]

    return BatchStatus(
        batch_id=batch_id,
        ordered_file_ids=ids,
        done_count=done,
        success_count=success,
        failed_count=failed,
        running_file_id=running,
        waiting_count=waiting,
        failed=failed_list,
        items=out,
    )


@app.get("/v1/files/{file_id}/result")
def download_result(file_id: str, _=Depends(require_user)):
    p = result_path(file_id)
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail="result_not_found")
    data = open(p, "rb").read()
    return Response(content=data, media_type="text/markdown; charset=utf-8")


@app.get("/v1/files/{file_id}", response_model=TaskStatus, dependencies=[Depends(rate_limit), Depends(require_user)])
def get_file_status(file_id: str):
    it = get_item(file_id)
    if not it:
        raise HTTPException(status_code=404, detail="not_found")
    return _to_status(it)


@app.post("/v1/files/{file_id}:retry", dependencies=[Depends(rate_limit), Depends(require_user)])
def retry_file(file_id: str, request: Request):
    it = get_item(file_id)
    if not it:
        raise HTTPException(status_code=404, detail="not_found")
    it.status = "queued"
    it.error = ""
    it.percent = 0.0
    it.current_page = 0
    it.total_pages = 0
    it.started_at = None
    it.finished_at = None
    upsert_item(it)
    res = celery_app.send_task(
        process_file.name,
        args=[file_id, _config_from_headers(request)],
        queue="ocr",
        priority=int(it.priority),
    )
    it.celery_task_id = res.id or ""
    upsert_item(it)
    return {"ok": True, "file_id": file_id}


@app.get("/v1/files/{file_id}/download", dependencies=[Depends(rate_limit), Depends(require_user)])
def download_original(file_id: str):
    it = get_item(file_id)
    if not it or not it.path or not os.path.exists(it.path):
        raise HTTPException(status_code=404, detail="not_found")
    data = open(it.path, "rb").read()
    ctype = it.content_type or "application/octet-stream"
    return Response(
        content=data,
        media_type=ctype,
        headers={"Content-Disposition": f'attachment; filename="{it.filename}"'},
    )


@app.get("/v1/files/{file_id}/preview/pages/{page_no}", dependencies=[Depends(rate_limit), Depends(require_user)])
def get_preview_page(file_id: str, page_no: int):
    it = get_item(file_id)
    if not it:
        raise HTTPException(status_code=404, detail="not_found")
    d = preview_dir(file_id)
    p = os.path.join(d, f"page_{int(page_no)}.jpg")
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail="preview_not_found")
    data = open(p, "rb").read()
    return Response(content=data, media_type="image/jpeg")

