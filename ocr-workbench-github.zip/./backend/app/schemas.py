from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str = Field(default="")
    password: str = Field(default="")


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class FileEnqueueResponse(BaseModel):
    batch_id: str
    file_ids: list[str]


class TaskProgress(BaseModel):
    percent: float = 0.0
    current_page: int = 0
    total_pages: int = 0
    eta_seconds: float | None = None


class TaskStatus(BaseModel):
    file_id: str
    filename: str
    status: str
    error: str = ""
    progress: TaskProgress = TaskProgress()
    queue_position: int | None = None
    created_at: float | None = None
    started_at: float | None = None
    finished_at: float | None = None


class BatchStatus(BaseModel):
    batch_id: str
    ordered_file_ids: list[str]
    done_count: int
    success_count: int
    failed_count: int
    running_file_id: str | None = None
    waiting_count: int
    failed: list[TaskStatus] = []
    items: list[TaskStatus] = []

