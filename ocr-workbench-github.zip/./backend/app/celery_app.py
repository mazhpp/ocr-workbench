from celery import Celery
from kombu import Queue

from backend.app.settings import settings


celery_app = Celery(
    "ocr_backend",
    broker=settings.broker_url,
    backend=settings.result_backend,
    include=["backend.app.tasks"],
)

celery_app.conf.update(
    task_default_queue="ocr",
    task_queues=(Queue("ocr", queue_arguments={"x-max-priority": 10}),),
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_time_limit=int(settings.task_timeout_s),
    task_soft_time_limit=max(1, int(settings.task_timeout_s) - 10),
    broker_transport_options={"visibility_timeout": int(settings.task_timeout_s) + 60},
)

