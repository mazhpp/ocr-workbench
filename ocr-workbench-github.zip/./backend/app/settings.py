from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="OCR_", env_file=".env", extra="ignore")

    jwt_secret: str = "change-me"
    jwt_issuer: str = "ocr-workbench"
    jwt_audience: str = "ocr-api"
    jwt_exp_minutes: int = 720

    admin_username: str = "admin"
    admin_password: str = "admin"

    max_file_size_mb: int = 0
    task_timeout_s: int = 300
    max_concurrency: int = 20

    storage_dir: str = "storage"

    broker_url: str = "amqp://guest:guest@localhost:5672//"
    result_backend: str = "redis://localhost:6379/0"

    rate_limit_rps: float = 5.0
    rate_limit_burst: int = 10


settings = Settings()

