import time
from dataclasses import dataclass

from fastapi import HTTPException, Request

from backend.app.settings import settings


@dataclass
class Bucket:
    tokens: float
    updated_at: float


_buckets: dict[str, Bucket] = {}


def _key(req: Request) -> str:
    xfwd = (req.headers.get("x-forwarded-for") or "").split(",")[0].strip()
    ip = xfwd or (req.client.host if req.client else "") or "unknown"
    return ip


def rate_limit(request: Request):
    rps = float(settings.rate_limit_rps)
    burst = int(settings.rate_limit_burst)
    k = _key(request)
    now = time.time()
    b = _buckets.get(k)
    if not b:
        b = Bucket(tokens=float(burst), updated_at=now)
        _buckets[k] = b
    dt = max(0.0, now - float(b.updated_at))
    b.updated_at = now
    b.tokens = min(float(burst), float(b.tokens) + dt * rps)
    if b.tokens < 1.0:
        raise HTTPException(status_code=429, detail="rate_limited")
    b.tokens -= 1.0

