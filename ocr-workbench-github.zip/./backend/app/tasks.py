import os
import time

import fitz
import docx
import openpyxl
from pptx import Presentation
from PIL import Image

from backend.app.celery_app import celery_app
from backend.app.settings import settings
from backend.app.state import get_item, upsert_item
from backend.app.storage import preview_dir, result_path
from core.llm_client import LLMClient
from core.processor import FileProcessor


def _ext(name: str) -> str:
    n = (name or "").lower()
    if "." not in n:
        return ""
    return n.rsplit(".", 1)[-1]


def _save_preview_pdf_pages(path: str, file_id: str, max_pages: int = 30):
    d = preview_dir(file_id)
    doc = fitz.open(path)
    total = len(doc)
    pages = min(total, int(max_pages))
    for i in range(pages):
        page = doc.load_page(i)
        pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5))
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        out = os.path.join(d, f"page_{i+1}.jpg")
        img.save(out, format="JPEG", quality=85)
    return total


def _ocr_pdf(path: str, filename: str, config: dict):
    with open(path, "rb") as f:
        b = f.read()
    images = FileProcessor.process_pdf(b)
    total = len(images)
    client = LLMClient(
        base_url=config.get("api_base", ""),
        api_key=config.get("api_key", ""),
        service_type=config.get("service_type", "auto"),
    )
    out = [f"## {filename}", ""]
    for idx, img in enumerate(images, start=1):
        img64 = FileProcessor.image_to_base64(img)
        txt = client.ocr_request(
            prompt=config.get("prompt", ""),
            image_base64=img64,
            model=config.get("model", ""),
            temperature=config.get("temperature", 0.1),
        )
        out.append(FileProcessor.clean_text(txt))
        out.append("")
        yield idx, total, "\n".join(out).strip() + "\n"


def _ocr_image(path: str, filename: str, config: dict):
    raw = open(path, "rb").read()
    images = FileProcessor.process_image(raw)
    total = len(images)
    client = LLMClient(
        base_url=config.get("api_base", ""),
        api_key=config.get("api_key", ""),
        service_type=config.get("service_type", "auto"),
    )
    out = [f"## {filename}", ""]
    for idx, img in enumerate(images, start=1):
        img64 = FileProcessor.image_to_base64(img)
        txt = client.ocr_request(
            prompt=config.get("prompt", ""),
            image_base64=img64,
            model=config.get("model", ""),
            temperature=config.get("temperature", 0.1),
        )
        out.append(FileProcessor.clean_text(txt))
        out.append("")
        yield idx, total, "\n".join(out).strip() + "\n"


def _docx_to_md(path: str, filename: str) -> str:
    d = docx.Document(path)
    out = [f"## {filename}", ""]
    for p in d.paragraphs:
        t = (p.text or "").rstrip()
        if t:
            out.append(t)
            out.append("")
    for ti, table in enumerate(d.tables, start=1):
        out.append(f"### Table {ti}")
        out.append("")
        rows = []
        for row in table.rows:
            rows.append([c.text.strip() for c in row.cells])
        if rows:
            header = rows[0]
            out.append("| " + " | ".join(header) + " |")
            out.append("| " + " | ".join(["---"] * len(header)) + " |")
            for r in rows[1:]:
                out.append("| " + " | ".join(r) + " |")
            out.append("")
    return "\n".join(out).strip() + "\n"


def _pptx_to_md(path: str, filename: str) -> str:
    pres = Presentation(path)
    out = [f"## {filename}", ""]
    for i, slide in enumerate(pres.slides, start=1):
        out.append(f"### Slide {i}")
        out.append("")
        for shape in slide.shapes:
            text = getattr(shape, "text", "") or ""
            text = text.strip()
            if text:
                out.append(text)
                out.append("")
    return "\n".join(out).strip() + "\n"


def _xlsx_to_md(path: str, filename: str) -> str:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    out = [f"## {filename}", ""]
    for sname in wb.sheetnames:
        ws = wb[sname]
        out.append(f"### Sheet: {sname}")
        out.append("")
        rows = []
        max_cols = 0
        for r in ws.iter_rows(values_only=True):
            row = [("" if v is None else str(v)) for v in r]
            max_cols = max(max_cols, len(row))
            rows.append(row)
            if len(rows) >= 50:
                break
        if not rows:
            out.append("(empty)")
            out.append("")
            continue
        for r in rows:
            if len(r) < max_cols:
                r.extend([""] * (max_cols - len(r)))
        header = rows[0]
        out.append("| " + " | ".join(header) + " |")
        out.append("| " + " | ".join(["---"] * len(header)) + " |")
        for r in rows[1:]:
            out.append("| " + " | ".join(r) + " |")
        out.append("")
    return "\n".join(out).strip() + "\n"


@celery_app.task(bind=True, max_retries=3, default_retry_delay=2)
def process_file(self, file_id: str, config: dict):
    it = get_item(file_id)
    if not it:
        return {"ok": False, "error": "not_found"}
    it.status = "running"
    it.started_at = time.time()
    upsert_item(it)

    try:
        ext = _ext(it.filename)
        if ext in {"pdf"}:
            it.total_pages = _save_preview_pdf_pages(it.path, it.file_id)
            upsert_item(it)
            last = ""
            for page_idx, total_pages, partial in _ocr_pdf(it.path, it.filename, config):
                it.current_page = page_idx
                it.total_pages = total_pages
                it.percent = float(page_idx) / max(1, int(total_pages))
                upsert_item(it)
                last = partial
            with open(result_path(it.file_id), "w", encoding="utf-8") as f:
                f.write(last)
        elif ext in {"png", "jpg", "jpeg", "bmp", "webp", "tif", "tiff"}:
            last = ""
            for page_idx, total_pages, partial in _ocr_image(it.path, it.filename, config):
                it.current_page = page_idx
                it.total_pages = total_pages
                it.percent = float(page_idx) / max(1, int(total_pages))
                upsert_item(it)
                last = partial
            with open(result_path(it.file_id), "w", encoding="utf-8") as f:
                f.write(last)
        elif ext in {"txt"}:
            raw = open(it.path, "rb").read()
            text = ""
            for enc in ["utf-8", "gbk", "gb18030"]:
                try:
                    text = raw.decode(enc)
                    break
                except Exception:
                    continue
            md = f"## {it.filename}\n\n{text}\n"
            with open(result_path(it.file_id), "w", encoding="utf-8") as f:
                f.write(md)
        elif ext in {"docx"}:
            md = _docx_to_md(it.path, it.filename)
            with open(result_path(it.file_id), "w", encoding="utf-8") as f:
                f.write(md)
        elif ext in {"pptx"}:
            md = _pptx_to_md(it.path, it.filename)
            with open(result_path(it.file_id), "w", encoding="utf-8") as f:
                f.write(md)
        elif ext in {"xlsx"}:
            md = _xlsx_to_md(it.path, it.filename)
            with open(result_path(it.file_id), "w", encoding="utf-8") as f:
                f.write(md)
        elif ext in {"doc", "ppt", "xls"}:
            it.status = "failed"
            it.error = f"unsupported_format:{ext}"
            it.finished_at = time.time()
            it.percent = 1.0
            upsert_item(it)
            return {"ok": False, "error": it.error}
        else:
            it.status = "failed"
            it.error = f"unsupported_format:{ext or 'unknown'}"
            it.finished_at = time.time()
            it.percent = 1.0
            upsert_item(it)
            return {"ok": False, "error": it.error}

        it.status = "success"
        it.finished_at = time.time()
        it.percent = 1.0
        upsert_item(it)
        return {"ok": True}
    except Exception as e:
        it.status = "failed"
        it.error = str(e)
        it.finished_at = time.time()
        upsert_item(it)
        raise self.retry(exc=e)

