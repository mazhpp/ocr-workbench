import datetime
from dataclasses import dataclass

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from passlib.context import CryptContext

from backend.app.settings import settings


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class User:
    username: str


def _now() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


def create_access_token(username: str) -> str:
    now = _now()
    exp = now + datetime.timedelta(minutes=int(settings.jwt_exp_minutes))
    payload = {
        "iss": settings.jwt_issuer,
        "aud": settings.jwt_audience,
        "sub": username,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return pwd_context.verify(plain or "", hashed or "")
    except Exception:
        return False


def hash_password(plain: str) -> str:
    return pwd_context.hash(plain or "")


def authenticate(username: str, password: str) -> bool:
    if not username:
        return False
    if username != settings.admin_username:
        return False
    return (password or "") == (settings.admin_password or "")


def require_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> User:
    if not creds or not creds.credentials:
        raise HTTPException(status_code=401, detail="missing_token")
    token = creds.credentials
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret,
            algorithms=["HS256"],
            issuer=settings.jwt_issuer,
            audience=settings.jwt_audience,
        )
        sub = str(payload.get("sub") or "")
        if not sub:
            raise HTTPException(status_code=401, detail="invalid_token")
        return User(username=sub)
    except HTTPException:
        raise
    except JWTError:
        raise HTTPException(status_code=401, detail="invalid_token")

