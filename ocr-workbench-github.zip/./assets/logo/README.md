# 本地 OCR 工作台 - LOGO 资源

- `app.ico`：默认程序图标（多尺寸，透明背景）
- `app_blue.ico` / `app_teal.ico`：不同配色方案
- `favicon.png`：用于网页/Streamlit 页签图标
- `logo_source.svg`：可编辑源文件（推荐）
- `logo_source.ai`：给设计工具使用的可编辑源文件（内容同 SVG）
- `png/`：导出的多尺寸 PNG

