import os

from core.llm_client import LLMClient


def main():
    base_url = os.environ.get("API_BASE", "http://localhost:1234/v1")
    api_key = os.environ.get("API_KEY", "lm-studio")
    model = os.environ.get("MODEL", "")
    service_type = os.environ.get("SERVICE_TYPE", "auto")

    client = LLMClient(base_url=base_url, api_key=api_key, service_type=service_type)
    models, diag = client.list_models_with_diagnostics()

    print("service_type:", client.get_service_type())
    print("base_url:", base_url)
    print("models_count:", len(models))
    if models:
        print("models_sample:", models[:10])
    print("diagnostics:", diag)

    if not model:
        model = models[0] if models else ""
    if not model:
        print("MODEL not provided and models list is empty; skip completion test.")
        return

    text = client.ocr_request(prompt="请回复：OK", image_base64="", model=model, temperature=0.0)
    print("completion:", (text or "").strip()[:200])


if __name__ == "__main__":
    main()

