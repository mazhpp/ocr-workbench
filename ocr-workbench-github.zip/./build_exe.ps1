$ErrorActionPreference = "Stop"

python -m pip install --upgrade pip
python -m pip install --upgrade pyinstaller

pyinstaller --noconfirm --clean ocr_workbench.spec

Write-Host ""
Write-Host "Build finished."
Write-Host "Output: .\dist\本地OCR工作台\本地OCR工作台.exe"
