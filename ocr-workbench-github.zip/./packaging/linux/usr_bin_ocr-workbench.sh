#!/usr/bin/env bash
set -euo pipefail

APP_BIN="/opt/ocr-workbench/ocr-workbench"
DATA_DIR="/var/lib/ocr-workbench"
LOG_DIR="/var/log/ocr-workbench"

mkdir -p "$DATA_DIR" "$LOG_DIR"

export OCRWB_HOST="${OCRWB_HOST:-127.0.0.1}"
export OCRWB_PORT="${OCRWB_PORT:-8501}"
export OCRWB_DATA_DIR="${OCRWB_DATA_DIR:-$DATA_DIR}"
export OCRWB_LOG_DIR="${OCRWB_LOG_DIR:-$LOG_DIR}"

exec "$APP_BIN"

