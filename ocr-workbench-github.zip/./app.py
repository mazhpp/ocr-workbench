import json
import html
import mimetypes
import os
import re
import uuid
import datetime
import time
import base64
import io
import hashlib
import sys
import cv2
import numpy as np
import streamlit as st
import streamlit.components.v1 as components
from PIL import Image
from ui.sidebar import render_sidebar
from core.llm_client import LLMClient
from core.processor import FileProcessor
from core.history_manager import HistoryManager
from core.ocr_task_manager import cancel_task, clear_tasks, get_task, start_task
from core.batch_preview import ensure_selected_file
from core.quality import quality_metrics
from core.cleanup import delete_files_in_dir
from core.exporter import docx_bytes_from_markdown, markdown_bytes, safe_basename
from core.upload_manager import is_duplicate_name_size, photo_basename, safe_filename
from core.file_store import exists_name_size, find_file_by_name_size, get_files, init_db, list_files, move_files, update_order, update_selected, upsert_file
from core.delete_service import hard_delete
from ui.file_dnd import file_dnd
from ui.camera_auto import camera_auto


def _base_dir() -> str:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def _page_icon():
    p = os.path.join(_base_dir(), "assets", "logo", "favicon.png")
    if os.path.exists(p):
        try:
            return Image.open(p)
        except Exception:
            return "📄"
    return "📄"

st.set_page_config(page_title="本地 OCR 工作台", page_icon=_page_icon(), layout="wide")

def set_current_result(content, filename):
    st.session_state.current_result = content
    st.session_state.current_filename = filename
    st.session_state.current_result_token = uuid.uuid4().hex


def _order_digest(ids: list[str]) -> str:
    h = hashlib.sha256()
    for fid in ids:
        h.update(str(fid).encode("utf-8", errors="ignore"))
        h.update(b"\0")
    return h.hexdigest()

def markdown_to_visible_text(md: str) -> str:
    if not md:
        return ""
    text = md.replace("\r\n", "\n").replace("\r", "\n")

    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</p\s*>", "\n\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)

    def _strip_fence_markers(s: str) -> str:
        lines = s.split("\n")
        out = []
        in_fence = False
        fence = ""
        for line in lines:
            m = re.match(r"^\s*(`{3,}|~{3,}).*$", line)
            if m:
                marker = m.group(1)
                if not in_fence:
                    in_fence = True
                    fence = marker[0]
                    continue
                if in_fence and marker[0] == fence:
                    in_fence = False
                    fence = ""
                    continue
            out.append(line)
        return "\n".join(out)

    text = _strip_fence_markers(text)

    text = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"^(\s{0,3})#{1,6}\s+", r"\1", text, flags=re.MULTILINE)
    text = re.sub(r"^(\s*>+\s?)", "", text, flags=re.MULTILINE)
    text = re.sub(r"^(\s*)([-+*])\s+", r"\1• ", text, flags=re.MULTILINE)
    text = re.sub(r"^(\s*)(\d+)\.\s+", r"\1\2. ", text, flags=re.MULTILINE)
    text = re.sub(r"(?<!`)`([^`]+)`(?!`)", r"\1", text)
    text = re.sub(r"(\*\*|__)(.*?)\1", r"\2", text)
    text = re.sub(r"(\*|_)(.*?)\1", r"\2", text)

    def _table_to_tsv(block: str) -> str:
        lines = [ln for ln in block.split("\n") if ln.strip()]
        if len(lines) < 2:
            return block
        if not all("|" in ln for ln in lines[:2]):
            return block
        align_re = re.compile(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$")
        if not align_re.match(lines[1]):
            return block

        def split_row(row: str):
            row = row.strip()
            if row.startswith("|"):
                row = row[1:]
            if row.endswith("|"):
                row = row[:-1]
            return [c.strip() for c in row.split("|")]

        rows = [split_row(lines[0])] + [split_row(ln) for ln in lines[2:]]
        return "\n".join("\t".join(r) for r in rows)

    blocks = text.split("\n\n")
    converted = []
    for b in blocks:
        if b.count("|") >= 2 and "\n" in b:
            converted.append(_table_to_tsv(b))
        else:
            converted.append(b)
    text = "\n\n".join(converted)

    text = re.sub(r"[ \t]+$", "", text, flags=re.MULTILINE)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _img_to_data_url(img: Image.Image, max_width: int = 520) -> str:
    im = img
    try:
        if max_width and im.width and im.width > max_width:
            h = int(im.height * (max_width / float(im.width)))
            im = im.resize((max_width, max(1, h)))
    except Exception:
        im = img
    buf = io.BytesIO()
    try:
        im.save(buf, format="PNG")
    except Exception:
        img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{b64}"


def _remove_camera_watermark(img: Image.Image) -> Image.Image:
    im = img
    if im.mode != "RGB":
        im = im.convert("RGB")
    arr = np.array(im)
    if arr.size == 0:
        return im
    bgr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    h, w = bgr.shape[:2]
    if h < 120 or w < 120:
        return im

    y0 = int(h * 0.55)
    x0 = int(w * 0.15)
    x1 = int(w * 0.85)
    roi = bgr[y0:h, x0:x1]
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    mask_g = cv2.inRange(gray, 210, 255)
    mask_h = cv2.inRange(hsv, (0, 0, 190), (180, 160, 255))
    mask = cv2.bitwise_and(mask_g, mask_h)

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    mask = cv2.dilate(mask, k, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)

    nz = cv2.findNonZero(mask)
    if nz is None:
        return im

    full_mask = np.zeros((h, w), dtype=np.uint8)
    x, y, cw, ch = cv2.boundingRect(nz)
    if cw < int(w * 0.05) or cw > int(w * 0.85):
        return im
    if ch < int(h * 0.01) or ch > int(h * 0.25):
        return im
    cx = x0 + x + cw / 2
    cy = y0 + y + ch / 2
    if cy < h * 0.65:
        return im
    if cx < w * 0.20 or cx > w * 0.80:
        return im
    pad_x = int(max(10, cw * 0.12))
    pad_y = int(max(6, ch * 0.18))
    xx0 = max(0, x0 + x - pad_x)
    yy0 = max(0, y0 + y - pad_y)
    xx1 = min(w, x0 + x + cw + pad_x)
    yy1 = min(h, y0 + y + ch + pad_y)
    full_mask[yy0:yy1, xx0:xx1] = 255

    if int(full_mask.sum()) == 0:
        return im

    repaired = cv2.inpaint(bgr, full_mask, 3, cv2.INPAINT_TELEA)
    rgb = cv2.cvtColor(repaired, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)


def render_fullscreen_batch_view():
    st.markdown(
        """
        <style>
          [data-testid="stSidebar"] { display: none; }
          header[data-testid="stHeader"] { display: none; }
          .block-container { padding: 0 !important; max-width: 100% !important; }
        </style>
        """,
        unsafe_allow_html=True,
    )

    top = st.container()
    with top:
        col1, col2, col3 = st.columns([2, 6, 2])
        with col1:
            if st.button("退出全屏", use_container_width=True):
                try:
                    st.query_params.pop("view", None)
                except Exception:
                    pass
                st.rerun()
        with col2:
            st.subheader("🖥️ 全屏批量识别")
        with col3:
            st.caption(f"批次：{st.session_state.get('batch_run_id','') or '—'}")

    ids = list(st.session_state.get("batch_file_ids") or [])
    if not ids:
        ids = [r.get("id") for r in st.session_state.get("upload_records", {}).values() if r.get("id")]

    items = []
    for fid in ids:
        rr = st.session_state.upload_records.get(fid, {})
        task = get_task(fid)
        status = (task.status if task else rr.get("status", "")) or "未开始"
        progress = float(task.progress) if task else 0.0
        page_index = int(task.page_index) if task else 0
        page_total = int(task.page_total) if task else 0
        name = rr.get("name", "") or fid
        mime_type = rr.get("mime", "") or ""
        path = rr.get("path", "") or ""

        preview_kind = "none"
        preview_data = ""
        preview_text = ""
        try:
            if path and os.path.exists(path):
                with open(path, "rb") as f:
                    b = f.read()
                if name.lower().endswith(".pdf") or mime_type == "application/pdf":
                    imgs = FileProcessor.process_pdf(b)
                    if imgs:
                        preview_kind = "image"
                        preview_data = _img_to_data_url(imgs[0])
                elif mime_type.startswith("image/") or name.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp")):
                    imgs = FileProcessor.process_image(b)
                    if imgs:
                        preview_kind = "image"
                        preview_data = _img_to_data_url(imgs[0])
                else:
                    preview_kind = "text"
                    preview_text = b[:6000].decode("utf-8", errors="ignore")
        except Exception:
            preview_kind = "none"

        if status in {"已完成", "已完成（缓存）"} and task and task.result:
            md = strip_file_name_headers(task.result)
        elif status in {"失败", "上传失败", "已取消", "不支持"}:
            reason = rr.get("error", "") or (task.error if task else "") or ""
            md = f"## {name}\n\n❌ {status}：{reason}\n"
        else:
            md = f"## {name}\n\n⏳ {status}\n"

        items.append(
            {
                "id": fid,
                "name": name,
                "mime": mime_type,
                "status": status,
                "progress": progress,
                "page_index": page_index,
                "page_total": page_total,
                "preview_kind": preview_kind,
                "preview_data": preview_data,
                "preview_text": preview_text,
                "md": md,
                "plain": markdown_to_visible_text(strip_file_name_headers(md)),
            }
        )

    payload = json.dumps({"items": items}, ensure_ascii=False)
    components.html(
        f"""
        <div id="fs-app"></div>
        <style>
          :root {{
            --bd: rgba(255,255,255,0.12);
            --bd2: rgba(255,255,255,0.18);
            --txt: rgba(255,255,255,0.92);
            --sub: rgba(255,255,255,0.72);
            --accent: rgba(80,160,255,0.9);
          }}
          #fs-wrap {{ height: calc(100vh - 120px); display: flex; gap: 10px; padding: 8px 10px 10px; }}
          #fs-left, #fs-right {{ flex: 1; border: 1px solid var(--bd); border-radius: 12px; overflow: auto; background: rgba(0,0,0,0.08); }}
          #fs-nav {{ position: sticky; top: 0; z-index: 5; background: rgba(15,17,22,0.92); border-bottom: 1px solid var(--bd); padding: 10px; }}
          #fs-nav .row {{ display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }}
          #fs-nav select {{ padding: 8px 10px; border-radius: 10px; background: rgba(0,0,0,0.18); color: var(--txt); border: 1px solid var(--bd); outline: none; }}
          #fs-nav button {{ padding: 8px 10px; border-radius: 10px; background: rgba(0,0,0,0.18); color: var(--txt); border: 1px solid var(--bd); cursor: pointer; }}
          #fs-nav button:hover {{ border-color: var(--bd2); filter: brightness(1.08); }}
          .card {{ border-bottom: 1px solid rgba(255,255,255,0.08); padding: 12px; }}
          .h {{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom: 8px; }}
          .title {{ font-weight: 800; color: var(--txt); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }}
          .meta {{ font-size: 12px; color: var(--sub); }}
          .status {{ display:flex; align-items:center; gap:10px; flex-wrap: wrap; }}
          .bar {{ height: 8px; width: 120px; background: rgba(255,255,255,0.10); border-radius: 999px; overflow:hidden; border: 1px solid rgba(255,255,255,0.10); }}
          .bar > div {{ height: 100%; background: var(--accent); width: 0%; }}
          .preview {{ border: 1px solid rgba(255,255,255,0.10); border-radius: 10px; background: rgba(255,255,255,0.02); overflow:hidden; }}
          .preview img {{ display:block; width: 100%; height: auto; }}
          .preview pre {{ margin:0; padding:10px; white-space: pre-wrap; color: var(--txt); font-size: 13px; line-height: 1.4; }}
          .result {{ border: 1px solid rgba(255,255,255,0.10); border-radius: 10px; background: rgba(255,255,255,0.02); padding: 10px; max-height: 360px; overflow:auto; }}
          .btns {{ display:flex; gap:8px; flex-wrap: wrap; }}
          .btns button {{ padding: 7px 10px; border-radius: 10px; background: rgba(0,0,0,0.18); color: var(--txt); border: 1px solid rgba(255,255,255,0.12); cursor:pointer; }}
          .btns button:hover {{ border-color: var(--bd2); filter: brightness(1.08); }}
          .toast {{ position: fixed; right: 14px; bottom: 14px; background: rgba(0,0,0,0.78); color: var(--txt); border: 1px solid rgba(255,255,255,0.16); padding: 10px 12px; border-radius: 12px; display:none; }}
          @media (max-width: 768px) {{
            #fs-wrap {{ flex-direction: column; height: auto; }}
            #fs-left, #fs-right {{ height: calc(50vh - 70px); }}
          }}
        </style>
        <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
        <script>
          const DATA = {payload};
          const root = document.getElementById("fs-app");
          const esc = (s) => (s||"").replace(/[&<>"']/g, c => ({{"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;","'":"&#39;"}}[c]));
          const showToast = (msg) => {{
            const t = document.getElementById("fs-toast");
            t.textContent = msg;
            t.style.display = "block";
            clearTimeout(window.__fs_toast_t);
            window.__fs_toast_t = setTimeout(() => t.style.display = "none", 1400);
          }};
          const copyText = async (txt) => {{
            try {{
              await navigator.clipboard.writeText(txt || "");
              showToast("✅ 已复制");
            }} catch (e) {{
              try {{
                const ta = document.createElement("textarea");
                ta.value = txt || "";
                document.body.appendChild(ta);
                ta.select();
                document.execCommand("copy");
                document.body.removeChild(ta);
                showToast("✅ 已复制");
              }} catch (e2) {{
                showToast("❌ 复制失败");
              }}
            }}
          }};
          const pct = (a) => a <= 0 ? 0 : (a >= 1 ? 100 : Math.round(a * 100));
          const cardLeft = (it) => {{
            let body = "";
            if (it.preview_kind === "image" && it.preview_data) {{
              body = `<div class="preview"><img src="${{it.preview_data}}" alt="preview"/></div>`;
            }} else if (it.preview_kind === "text") {{
              body = `<div class="preview"><pre>${{esc(it.preview_text || "")}}</pre></div>`;
            }} else {{
              body = `<div class="preview"><pre>暂无预览</pre></div>`;
            }}
            return `<div class="card" id="l-${{it.id}}">
              <div class="h">
                <div style="min-width:0;">
                  <div class="title">${{esc(it.name)}}</div>
                  <div class="meta">${{esc(it.mime || "")}}</div>
                </div>
              </div>
              ${{body}}
            </div>`;
          }};
          const cardRight = (it) => {{
            const md = it.md || "";
            const html = (window.marked ? marked.parse(md) : `<pre>${{esc(md)}}</pre>`);
            const bar = `<div class="bar"><div style="width:${{pct(it.progress || 0)}}%"></div></div>`;
            const page = (it.page_total && it.page_total > 0) ? `${{it.page_index}}/${{it.page_total}}` : "";
            return `<div class="card" id="r-${{it.id}}">
              <div class="h">
                <div style="min-width:0;">
                  <div class="title">${{esc(it.name)}}</div>
                  <div class="meta">${{esc(it.status || "")}} ${{page ? (" | " + page) : ""}}</div>
                </div>
                <div class="status">
                  ${{bar}}
                  <div class="meta">${{pct(it.progress || 0)}}%</div>
                </div>
              </div>
              <div class="btns">
                <button data-copy="plain" data-id="${{it.id}}">复制纯文本</button>
                <button data-copy="md" data-id="${{it.id}}">复制Markdown</button>
              </div>
              <div class="result">${{html}}</div>
            </div>`;
          }};

          const opts = DATA.items.map(it => `<option value="${{it.id}}">${{esc(it.name)}}</option>`).join("");
          root.innerHTML = `
            <div id="fs-wrap">
              <div id="fs-left">
                <div id="fs-nav">
                  <div class="row">
                    <select id="fs-jump"><option value="">快速定位文件…</option>${{opts}}</select>
                    <button id="fs-top">回到顶部</button>
                  </div>
                </div>
                ${{DATA.items.map(cardLeft).join("")}}
              </div>
              <div id="fs-right">
                <div id="fs-nav">
                  <div class="row">
                    <div class="meta">识别结果（Markdown 渲染）</div>
                  </div>
                </div>
                ${{DATA.items.map(cardRight).join("")}}
              </div>
            </div>
            <div class="toast" id="fs-toast"></div>
          `;

          const left = document.getElementById("fs-left");
          const right = document.getElementById("fs-right");
          let lock = false;
          const sync = (src, dst) => {{
            if (lock) return;
            lock = true;
            const sh = src.scrollHeight - src.clientHeight;
            const dh = dst.scrollHeight - dst.clientHeight;
            const p = sh > 0 ? (src.scrollTop / sh) : 0;
            dst.scrollTop = dh > 0 ? (p * dh) : 0;
            setTimeout(() => lock = false, 0);
          }};
          left.addEventListener("scroll", () => sync(left, right));
          right.addEventListener("scroll", () => sync(right, left));

          root.addEventListener("click", (e) => {{
            const t = e.target;
            if (!(t instanceof HTMLElement)) return;
            const kind = t.getAttribute("data-copy");
            const id = t.getAttribute("data-id");
            if (kind && id) {{
              const it = DATA.items.find(x => x.id === id);
              if (!it) return;
              copyText(kind === "md" ? (it.md || "") : (it.plain || ""));
            }}
          }});

          document.getElementById("fs-top").addEventListener("click", () => {{
            left.scrollTop = 0;
            right.scrollTop = 0;
          }});
          document.getElementById("fs-jump").addEventListener("change", (e) => {{
            const id = e.target.value;
            if (!id) return;
            const le = document.getElementById("l-" + id);
            const re = document.getElementById("r-" + id);
            if (le) left.scrollTop = Math.max(0, le.offsetTop - 50);
            if (re) right.scrollTop = Math.max(0, re.offsetTop - 50);
          }});
        </script>
        """,
        height=0,
        scrolling=False,
    )

def strip_file_name_headers(md: str) -> str:
    if not md:
        return ""
    s = md.replace("\r\n", "\n").replace("\r", "\n")
    file_exts = {
        "pdf",
        "png",
        "jpg",
        "jpeg",
        "bmp",
        "webp",
        "tif",
        "tiff",
        "gif",
        "heic",
    }
    out = []
    for line in s.split("\n"):
        m = re.match(r"^\s*#{1,6}\s+(.+?)\s*$", line)
        if m:
            title = m.group(1).strip()
            lower = title.lower()
            if "." in lower:
                ext = lower.rsplit(".", 1)[-1]
                if ext in file_exts:
                    continue
        out.append(line)
    cleaned = "\n".join(out)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()

def format_size(num_bytes: int) -> str:
    if num_bytes is None:
        return ""
    size = float(num_bytes)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0 or unit == "TB":
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.2f} {unit}"
        size /= 1024.0

def ensure_upload_state():
    if "upload_records" not in st.session_state:
        st.session_state.upload_records = {}
    if "removed_records" not in st.session_state:
        st.session_state.removed_records = {}
    if "upload_order_counter" not in st.session_state:
        st.session_state.upload_order_counter = 1
    if "upload_last_add_token" not in st.session_state:
        st.session_state.upload_last_add_token = ""
    if "upload_last_camera_token" not in st.session_state:
        st.session_state.upload_last_camera_token = ""
    if "upload_clear_confirming" not in st.session_state:
        st.session_state.upload_clear_confirming = False
    if "pending_delete_ids" not in st.session_state:
        st.session_state.pending_delete_ids = []
    if "pending_delete_confirming" not in st.session_state:
        st.session_state.pending_delete_confirming = False
    if "op_banner" not in st.session_state:
        st.session_state.op_banner = ""
    if "upload_max_files" not in st.session_state:
        st.session_state.upload_max_files = 0
    if "upload_max_file_size_mb" not in st.session_state:
        st.session_state.upload_max_file_size_mb = 0
    if "operation_history" not in st.session_state:
        st.session_state.operation_history = []
    if "last_order_param" not in st.session_state:
        st.session_state.last_order_param = ""
    if "batch_run_id" not in st.session_state:
        st.session_state.batch_run_id = ""
    if "batch_file_ids" not in st.session_state:
        st.session_state.batch_file_ids = []
    if "batch_started_at" not in st.session_state:
        st.session_state.batch_started_at = ""
    if "batch_preview_generated_for" not in st.session_state:
        st.session_state.batch_preview_generated_for = ""
    if "batch_selected_file_id" not in st.session_state:
        st.session_state.batch_selected_file_id = ""
    if "batch_selected_run_id" not in st.session_state:
        st.session_state.batch_selected_run_id = ""
    if "batch_preview_mode" not in st.session_state:
        st.session_state.batch_preview_mode = "single"
    if "batch_playlist_ids" not in st.session_state:
        st.session_state.batch_playlist_ids = []
    if "batch_playing" not in st.session_state:
        st.session_state.batch_playing = False
    if "batch_play_seconds" not in st.session_state:
        st.session_state.batch_play_seconds = 3.0
    if "batch_last_switch_ts" not in st.session_state:
        st.session_state.batch_last_switch_ts = 0.0
    if "ocr_feedback" not in st.session_state:
        st.session_state.ocr_feedback = {}
    if "dnd_last_handled" not in st.session_state:
        st.session_state.dnd_last_handled = ""
    os.makedirs("uploads", exist_ok=True)
    init_db()


def _sync_records_from_db():
    active = list_files("active")
    removed = list_files("removed")
    st.session_state.upload_records = {}
    st.session_state.removed_records = {}
    max_order = 0
    for r in active:
        max_order = max(max_order, int(r.get("order_num") or 0))
        st.session_state.upload_records[r["id"]] = {
            "id": r["id"],
            "name": r.get("name", ""),
            "size": int(r.get("size", 0) or 0),
            "uploaded_at": r.get("created_at", ""),
            "mime": r.get("mime", ""),
            "path": r.get("path", ""),
            "selected": bool(r.get("selected")),
            "order": int(r.get("order_num", 0) or 0),
            "status": "等待中" if bool(r.get("supported")) else "不支持",
            "error": r.get("error", "") or "",
            "supported": bool(r.get("supported")),
            "history_saved": False,
        }
    for r in removed:
        max_order = max(max_order, int(r.get("order_num") or 0))
        st.session_state.removed_records[r["id"]] = {
            "id": r["id"],
            "name": r.get("name", ""),
            "size": int(r.get("size", 0) or 0),
            "uploaded_at": r.get("created_at", ""),
            "mime": r.get("mime", ""),
            "path": r.get("path", ""),
            "selected": False,
            "order": int(r.get("order_num", 0) or 0),
            "status": "已移除",
            "error": r.get("error", "") or "",
            "supported": bool(r.get("supported")),
            "history_saved": False,
            "removed_at": r.get("removed_at", "") or "",
        }
    st.session_state.upload_order_counter = max(1, max_order + 1)
    return active, removed

def get_record_any(file_id: str) -> dict:
    fid = str(file_id or "")
    if not fid:
        return {}
    rr = (st.session_state.get("upload_records") or {}).get(fid)
    if rr:
        return dict(rr)
    rr = (st.session_state.get("removed_records") or {}).get(fid)
    if rr:
        return dict(rr)
    rows = get_files([fid]) or []
    if rows:
        r = rows[0]
        return {
            "id": r.get("id", fid),
            "name": r.get("name", ""),
            "size": int(r.get("size", 0) or 0),
            "uploaded_at": r.get("created_at", ""),
            "mime": r.get("mime", ""),
            "path": r.get("path", ""),
            "selected": bool(r.get("selected")),
            "order": int(r.get("order_num", 0) or 0),
            "status": r.get("status", ""),
            "error": r.get("error", "") or "",
            "supported": bool(r.get("supported")),
            "removed_at": r.get("removed_at", "") or "",
        }
    return {}

def is_ocr_supported(file_name: str, mime_type: str | None) -> bool:
    if (file_name or "").lower().endswith(".pdf"):
        return True
    if mime_type == "application/pdf":
        return True
    if mime_type and mime_type.startswith("image/"):
        return True
    return False

def add_operation(event_type: str, payload: dict):
    try:
        st.session_state.operation_history.append(
            {
                "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "event": event_type,
                "payload": payload,
            }
        )
        st.session_state.operation_history = st.session_state.operation_history[-200:]
    except Exception:
        pass

def upload_token(files) -> str:
    if not files:
        return ""
    parts = []
    for f in files:
        name = getattr(f, "name", "")
        size = getattr(f, "size", None)
        parts.append(f"{name}:{size}")
    return "|".join(parts)

def save_bytes_to_disk(data: bytes, file_id: str, file_name: str, mime_type: str) -> tuple[str, str, int]:
    safe_name = safe_filename(file_name)
    save_path = os.path.join("uploads", f"{file_id}_{safe_name}")
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    with open(save_path, "wb") as out:
        out.write(data)
    final_size = os.path.getsize(save_path) if os.path.exists(save_path) else len(data)
    return save_path, (mime_type or mimetypes.guess_type(file_name)[0] or ""), int(final_size)

def save_camera_bytes_to_disk(data: bytes, file_id: str, file_name: str, mime_type: str, subdir: str) -> tuple[str, str, int]:
    safe_name = safe_filename(file_name)
    save_path = os.path.join("uploads", subdir, f"{file_id}_{safe_name}")
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    with open(save_path, "wb") as out:
        mv = memoryview(data)
        chunk = 8 * 1024 * 1024
        for off in range(0, len(mv), chunk):
            out.write(mv[off : off + chunk])
    final_size = os.path.getsize(save_path) if os.path.exists(save_path) else len(data)
    return save_path, (mime_type or mimetypes.guess_type(file_name)[0] or ""), int(final_size)

def save_uploaded_file_to_disk(f, file_id: str) -> tuple[str, str, int]:
    file_name = f.name
    mime_type = getattr(f, "type", None) or mimetypes.guess_type(file_name)[0] or ""
    size = int(getattr(f, "size", None) or 0)

    safe_name = safe_filename(file_name)
    save_path = os.path.join("uploads", f"{file_id}_{safe_name}")

    f.seek(0)
    with open(save_path, "wb") as out:
        while True:
            chunk = f.read(8 * 1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
    return save_path, mime_type, size if size else os.path.getsize(save_path)

def render_copy_button(text, key, disabled=False, label="📋 复制", aria_label="复制到剪贴板"):
    # 修复说明：
    # 1) 之前使用 window.__copyToastTimer_{key} 作为 JS 变量名，key 含 '-' 会导致脚本语法错误，
    #    从而出现“按钮点击无响应”（事件绑定未生效）。
    # 2) 这里改为使用 window.__copyToastTimers 这个对象存储 timer，并用字符串 key 索引，避免语法风险。
    # 3) 同时将 DOM id 进行安全化处理，避免特殊字符影响选择器与绑定。
    safe_text = "" if text is None else str(text)
    payload = json.dumps(safe_text, ensure_ascii=False)
    safe_dom_key = re.sub(r"[^a-zA-Z0-9_-]", "_", str(key))
    button_id = f"copy-btn-{safe_dom_key}"
    toast_id = f"copy-toast-{safe_dom_key}"
    disabled_attr = "disabled" if disabled or safe_text == "" else ""
    safe_label = (label or "📋 复制").strip()
    safe_aria = (aria_label or "复制到剪贴板").strip()
    components.html(
        f"""
        <div>
          <button id="{button_id}" {disabled_attr} aria-label="{safe_aria}" type="button">
            {safe_label}
          </button>
          <div id="{toast_id}" role="status" aria-live="polite"></div>
        </div>
        <style>
          #{button_id} {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 12px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.16);
            background: rgba(255,255,255,0.06);
            color: rgba(255,255,255,0.92);
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 120ms ease;
          }}
          #{button_id}:hover {{
            background: rgba(255,255,255,0.10);
            border-color: rgba(255,255,255,0.26);
          }}
          #{button_id}:active {{
            transform: scale(0.98);
          }}
          #{button_id}:focus {{
            outline: 2px solid rgba(99, 179, 237, 0.9);
            outline-offset: 2px;
          }}
          #{button_id}[disabled] {{
            opacity: 0.5;
            cursor: not-allowed;
          }}
          #{toast_id} {{
            margin-top: 8px;
            font-size: 12px;
            color: rgba(255,255,255,0.75);
            min-height: 16px;
          }}
        </style>
        <script>
          // 复制逻辑：优先使用 Clipboard API，失败则降级到 execCommand('copy')。
          const text = {payload};
          const btn = document.getElementById("{button_id}");
          const toast = document.getElementById("{toast_id}");
          const copyKey = {json.dumps(str(key), ensure_ascii=False)};
          window.__copyToastTimers = window.__copyToastTimers || {{}};

          function show(msg) {{
            toast.textContent = msg;
            const prev = window.__copyToastTimers[copyKey];
            if (prev) clearTimeout(prev);
            window.__copyToastTimers[copyKey] = setTimeout(() => {{ toast.textContent = ""; }}, 1800);
          }}
          async function copy() {{
            try {{
              if (!text) {{
                show("无可复制内容");
                return;
              }}
              if (navigator.clipboard && navigator.clipboard.writeText) {{
                await navigator.clipboard.writeText(text);
                if (navigator.clipboard.readText) {{
                  try {{
                    const back = await navigator.clipboard.readText();
                    if (back !== text) {{
                      show("⚠️ 已复制，但检测到内容不一致，请检查是否出现多余格式标记");
                      return;
                    }}
                  }} catch (e) {{}}
                }}
                show("✅ 已复制到剪贴板");
                return;
              }}
              const ta = document.createElement("textarea");
              ta.value = text;
              ta.style.position = "fixed";
              ta.style.top = "-9999px";
              document.body.appendChild(ta);
              ta.focus();
              ta.select();
              const ok = document.execCommand("copy");
              document.body.removeChild(ta);
              show(ok ? "✅ 已复制到剪贴板" : "❌ 复制失败");
            }} catch (e) {{
              console.error("copy failed", e);
              show("❌ 复制失败");
            }}
          }}
          if (btn) {{
            btn.addEventListener("click", copy);
            btn.addEventListener("keydown", (e) => {{
              if (e.key === "Enter" || e.key === " ") {{ e.preventDefault(); copy(); }}
            }});
          }}
        </script>
        """,
        height=78,
    )

def _export_base_names(filename: str) -> tuple[str, str]:
    base = safe_basename(filename or "ocr_result")
    if "." in base:
        base = base.rsplit(".", 1)[0] or base
    md_name = f"{base}.md"
    docx_name = f"{base}.docx"
    return md_name, docx_name

def render_download_buttons(md: str, filename: str, key_prefix: str):
    md_name, docx_name = _export_base_names(filename)
    cache_key = hashlib.sha256((str(md or "") + "\0" + str(md_name) + "\0" + str(docx_name)).encode("utf-8", errors="ignore")).hexdigest()
    cache_slot = f"dl_cache_{key_prefix}"
    cached = st.session_state.get(cache_slot) or {}
    if not isinstance(cached, dict):
        cached = {}
    if cached.get("k") != cache_key:
        cached = {"k": cache_key, "docx": docx_bytes_from_markdown(md or "", title=md_name.rsplit(".", 1)[0])}
        st.session_state[cache_slot] = cached
    c1, c2 = st.columns(2)
    with c1:
        st.download_button(
            "下载 Markdown",
            data=(md or ""),
            file_name=md_name,
            mime="text/markdown",
            use_container_width=True,
            key=f"dl-md-{key_prefix}",
        )
    with c2:
        st.download_button(
            "下载 Word",
            data=(cached.get("docx") or b""),
            file_name=docx_name,
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            use_container_width=True,
            key=f"dl-docx-{key_prefix}",
        )

def render_compact_ui(history_manager: HistoryManager, config: dict):
    ensure_upload_state()
    _sync_records_from_db()
    if st.session_state.get("active_selected_ids") is None:
        st.session_state["active_selected_ids"] = []
    if "main_selected_kind" not in st.session_state:
        st.session_state.main_selected_kind = ""
    if "main_selected_id" not in st.session_state:
        st.session_state.main_selected_id = ""
    if "history_delete_confirming" not in st.session_state:
        st.session_state.history_delete_confirming = False
    if "history_delete_target" not in st.session_state:
        st.session_state.history_delete_target = ""
    if "history_clear_all_confirming" not in st.session_state:
        st.session_state.history_clear_all_confirming = False
    st.markdown("")
    st.markdown(
        """
        <style>
          .block-container { padding-top: 1.6rem; padding-bottom: 1.0rem; max-width: 100% !important; }
          div[role="dialog"] { z-index: 1000000 !important; }
          h1 { line-height: 1.25 !important; margin-top: 0.0rem !important; padding-top: 0.25rem !important; }
          div[data-testid="stMarkdownContainer"] h1 { overflow: visible !important; }
          header[data-testid="stHeader"] { overflow: visible !important; }
          section[data-testid="stFileUploaderDropzone"] div[data-testid="stFileUploaderDropzoneInstructions"] > * { display: none !important; }
          section[data-testid="stFileUploaderDropzone"] div[data-testid="stFileUploaderDropzoneInstructions"]::before { content: "拖拽文件到此处"; display: block; font-weight: 800; }
          section[data-testid="stFileUploaderDropzone"] div[data-testid="stFileUploaderDropzoneInstructions"]::after { content: "单个文件最大 100GB"; display: block; opacity: 0.75; font-size: 0.86rem; margin-top: 0.25rem; }
          section[data-testid="stFileUploaderDropzone"] button { font-size: 0 !important; }
          section[data-testid="stFileUploaderDropzone"] button::after { content: "选择文件"; font-size: 0.95rem; font-weight: 800; }
        </style>
        """,
        unsafe_allow_html=True,
    )
    left_col, right_col = st.columns([4, 8])
    with left_col:
        if "upload_expanded" not in st.session_state:
            st.session_state.upload_expanded = False
        with st.expander("文件上传", expanded=bool(st.session_state.upload_expanded)):
            st.caption("拖拽或选择文件上传；上传后加入待识别队列。")
            uploaded_files = st.file_uploader(
                "拖放文件到此处或点击上传（支持多选）",
                type=None,
                accept_multiple_files=True,
                key="upload_picker_main",
                label_visibility="visible",
            )
            if st.button("拍照上传", use_container_width=True):
                st.session_state.main_selected_kind = "camera"
                st.session_state.upload_expanded = False
                st.rerun()
            new_token = upload_token(uploaded_files)
            should_add = bool(uploaded_files) and (new_token and new_token != st.session_state.upload_last_add_token)
            if should_add and uploaded_files:
                st.session_state.upload_last_add_token = new_token or uuid.uuid4().hex
                overall = st.progress(0)
                status = st.empty()
                last_file_id = ""
                for idx, f in enumerate(uploaded_files):
                    file_id = uuid.uuid4().hex
                    file_name = f.name
                    mime_type = getattr(f, "type", None) or mimetypes.guess_type(file_name)[0] or ""
                    size = int(getattr(f, "size", None) or 0)
                    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    if exists_name_size(file_name, size):
                        hit = find_file_by_name_size(file_name, size)
                        if hit and hit.get("id"):
                            hid = str(hit.get("id"))
                            if str(hit.get("status") or "") == "removed":
                                move_files([hid], "active")
                                update_selected([hid], True)
                                update_order({hid: st.session_state.upload_order_counter})
                                st.session_state.upload_order_counter += 1
                                st.info("该文件已存在（已从归档区恢复到待识别）")
                            else:
                                st.info("该文件已存在（已定位到待识别列表）")
                            last_file_id = hid
                        else:
                            st.warning("该文件已存在")
                        continue
                    if not is_ocr_supported(file_name, mime_type):
                        st.warning(f"不支持：{file_name}")
                        continue
                    status.text(f"正在保存: {file_name}")
                    try:
                        save_path, mime_type, final_size = save_uploaded_file_to_disk(f, file_id=file_id)
                    except Exception as e:
                        upsert_file(
                            {
                                "id": file_id,
                                "name": file_name,
                                "size": size,
                                "mime": mime_type,
                                "path": "",
                                "status": "active",
                                "supported": False,
                                "selected": False,
                                "order_num": st.session_state.upload_order_counter,
                                "created_at": now,
                                "error": str(e),
                            }
                        )
                        st.session_state.upload_order_counter += 1
                        continue
                    if exists_name_size(file_name, final_size):
                        try:
                            if save_path and os.path.exists(save_path):
                                os.remove(save_path)
                        except Exception:
                            pass
                        st.warning("该文件已存在")
                        continue
                    supported = is_ocr_supported(file_name, mime_type)
                    upsert_file(
                        {
                            "id": file_id,
                            "name": file_name,
                            "size": final_size,
                            "mime": mime_type,
                            "path": save_path,
                            "status": "active",
                            "supported": supported,
                            "selected": supported,
                            "order_num": st.session_state.upload_order_counter,
                            "created_at": now,
                            "error": "",
                        }
                    )
                    st.session_state.upload_order_counter += 1
                    add_operation("file_added", {"id": file_id, "name": file_name, "mime": mime_type, "size": final_size})
                    last_file_id = file_id
                    overall.progress((idx + 1) / max(1, len(uploaded_files)))
                status.empty()
                overall.empty()
                if last_file_id:
                    st.session_state.main_selected_kind = "file"
                    st.session_state.main_selected_id = last_file_id
                st.session_state.upload_expanded = False
                st.rerun()
        active_rows, removed_rows = _sync_records_from_db()
        ordered = sorted(st.session_state.upload_records.values(), key=lambda x: (int(x.get("order", 0)), x.get("uploaded_at", "")))
        if "history_saved_file_ids" not in st.session_state:
            st.session_state.history_saved_file_ids = []
        saved_ids = set(st.session_state.history_saved_file_ids or [])
        repaired_histories = 0
        for r in list((st.session_state.get("removed_records") or {}).values()):
            fid = str(r.get("id") or "")
            if not fid or fid in saved_ids:
                continue
            t = get_task(fid)
            if t and t.status in {"已完成", "已完成（缓存）"} and t.result:
                try:
                    history_manager.save_history(r.get("name", "file"), t.result)
                    saved_ids.add(fid)
                    st.session_state.history_saved_file_ids = list(saved_ids)
                    add_operation("history_saved", {"id": fid, "name": r.get("name", "")})
                    repaired_histories += 1
                except Exception:
                    pass
        auto_archive_ids = []
        for r in ordered:
            t = get_task(r["id"])
            if t and t.status in {"已完成", "已完成（缓存）"} and t.result:
                fid = str(r.get("id") or "")
                if fid and fid not in saved_ids:
                    try:
                        history_manager.save_history(r.get("name", "file"), t.result)
                        saved_ids.add(fid)
                        st.session_state.history_saved_file_ids = list(saved_ids)
                        add_operation("history_saved", {"id": fid, "name": r.get("name", "")})
                    except Exception as e:
                        st.error(f"历史记录保存失败：{e}")
                        continue
                if fid:
                    auto_archive_ids.append(fid)
        if repaired_histories and not auto_archive_ids:
            st.session_state.op_banner = f"已补写历史记录 {repaired_histories} 条"
            st.rerun()
        if auto_archive_ids:
            move_files(auto_archive_ids, "removed")
            update_selected(auto_archive_ids, False)
            st.session_state.active_selected_ids = [x for x in (st.session_state.get("active_selected_ids") or []) if x not in set(auto_archive_ids)]
            st.session_state.op_banner = f"已自动归档 {len(auto_archive_ids)} 个已识别文件"
            st.rerun()
        if "force_recognize_ids" not in st.session_state:
            st.session_state.force_recognize_ids = []
        force_ids = set(st.session_state.force_recognize_ids or [])
        for fid in list(force_ids):
            t = get_task(fid)
            if t and t.status not in {"排队中", "识别中"}:
                force_ids.discard(fid)
        st.session_state.force_recognize_ids = list(force_ids)
        st.subheader("待识别")
        op_bar_col1, op_bar_col2 = st.columns([2, 2])
        with op_bar_col1:
            start_all = st.button("开始识别", type="primary", use_container_width=True)
        with op_bar_col2:
            st.caption("点击文件名在右侧预览")
        if start_all:
            to_run_ids = list(st.session_state.active_selected_ids or [])
            if not to_run_ids:
                to_run = [r for r in ordered if r.get("supported")]
            else:
                sup = {r["id"] for r in ordered if r.get("supported")}
                to_run = [r for r in ordered if r["id"] in set(to_run_ids) and r["id"] in sup]
            if to_run:
                for r in to_run:
                    rid = r["id"]
                    one_cfg = dict(config)
                    one_cfg["skip_cache"] = bool(str(rid) in force_ids)
                    start_task(rid, dict(r), one_cfg)
                st.session_state.main_selected_kind = "file"
                st.session_state.main_selected_id = to_run[0]["id"]
                st.session_state.upload_expanded = False
                st.rerun()
        act_bar1, act_bar3 = st.columns([1, 2])
        with act_bar1:
            if st.button("全选", use_container_width=True):
                sup_ids = [r["id"] for r in ordered if r.get("supported")]
                cur = set(st.session_state.active_selected_ids or [])
                if sup_ids and cur == set(sup_ids):
                    st.session_state.active_selected_ids = []
                    for r in ordered:
                        st.session_state[f"act_sel_{r['id']}"] = False
                else:
                    st.session_state.active_selected_ids = list(sup_ids)
                    for r in ordered:
                        st.session_state[f"act_sel_{r['id']}"] = bool(r.get("supported"))
                st.session_state.upload_expanded = False
                st.rerun()
        with act_bar3:
            if st.button("× 删除", use_container_width=True, disabled=not bool(st.session_state.active_selected_ids)):
                ids = list(st.session_state.active_selected_ids)
                ok, err = hard_delete(ids, cancel_task=cancel_task, clear_tasks=clear_tasks)
                if ok:
                    st.session_state.active_selected_ids = []
                    st.success(f"已删除 {len(ids)} 个文件")
                    st.session_state.upload_expanded = False
                    st.rerun()
                else:
                    st.error(f"删除失败：{err}")
        box1 = st.container(height=310)
        with box1:
            for r in ordered:
                rid = r["id"]
                cols = st.columns([0.7, 4, 2])
                with cols[0]:
                    key = f"act_sel_{rid}"
                    if key not in st.session_state:
                        st.session_state[key] = False
                    prev_sel = bool(st.session_state.get(key, False))
                    new_sel = st.checkbox("✓", key=key, label_visibility="collapsed", disabled=not bool(r.get("supported")))
                    sel_ids = set(st.session_state.active_selected_ids or [])
                    if new_sel:
                        sel_ids.add(rid)
                    else:
                        sel_ids.discard(rid)
                    st.session_state.active_selected_ids = list(sel_ids)
                    if new_sel and (new_sel != prev_sel):
                        st.session_state.main_selected_kind = "file"
                        st.session_state.main_selected_id = rid
                        st.session_state.upload_expanded = False
                        st.rerun()
                with cols[1]:
                    if st.button(r.get("name", "文件"), key=f"name-{rid}", use_container_width=True):
                        st.session_state.main_selected_kind = "file"
                        st.session_state.main_selected_id = rid
                        st.session_state.upload_expanded = False
                        st.rerun()
                    st.caption(f"{format_size(int(r.get('size', 0)))} | {r.get('mime','')}")
                with cols[2]:
                    t = get_task(rid)
                    stt = (t.status if t else r.get("status", "")) or ""
                    st.caption(stt)
        st.subheader("已识别")
        if "done_selected_ids" not in st.session_state:
            st.session_state.done_selected_ids = []
        if "done_delete_confirming" not in st.session_state:
            st.session_state.done_delete_confirming = False
        if "done_delete_target_ids" not in st.session_state:
            st.session_state.done_delete_target_ids = []
        done_list = list(removed_rows or [])
        box_done = st.container(height=220)
        with box_done:
            if done_list:
                bar1, bar2 = st.columns([1, 2])
                with bar1:
                    if st.button("☑", use_container_width=True):
                        ids_all = [r["id"] for r in done_list]
                        cur = set(st.session_state.done_selected_ids or [])
                        if ids_all and cur == set(ids_all):
                            st.session_state.done_selected_ids = []
                            for r in done_list:
                                st.session_state[f"done_sel_{r['id']}"] = False
                        else:
                            st.session_state.done_selected_ids = ids_all
                            for r in done_list:
                                st.session_state[f"done_sel_{r['id']}"] = True
                        st.rerun()
                with bar2:
                    b21, b22 = st.columns(2)
                    with b21:
                        if st.button("↩ 退回待识别", use_container_width=True, disabled=not bool(st.session_state.done_selected_ids)):
                            ids = list(st.session_state.done_selected_ids or [])
                            for fid in ids:
                                cancel_task(fid)
                                clear_tasks([fid])
                            move_files(ids, "active")
                            update_selected(ids, True)
                            for fid in ids:
                                update_order({fid: st.session_state.upload_order_counter})
                                st.session_state.upload_order_counter += 1
                            force_ids = set(st.session_state.get("force_recognize_ids") or [])
                            for fid in ids:
                                if fid:
                                    force_ids.add(str(fid))
                            st.session_state.force_recognize_ids = list(force_ids)
                            for fid in ids:
                                st.session_state[f"done_sel_{fid}"] = False
                            st.session_state.done_selected_ids = []
                            st.success(f"已退回 {len(ids)} 个文件到待识别")
                            st.rerun()
                    with b22:
                        if st.button("🗑 删除所选", use_container_width=True, disabled=not bool(st.session_state.done_selected_ids)):
                            st.session_state.done_delete_confirming = True
                            st.session_state.done_delete_target_ids = list(st.session_state.done_selected_ids or [])
                            st.rerun()

                @st.dialog("删除所选文件")
                def _dlg_delete_done_files():
                    ids = list(st.session_state.get("done_delete_target_ids") or [])
                    st.write(f"确认删除 {len(ids)} 个文件吗？")
                    st.caption("此操作会从本地磁盘删除文件，且不可恢复。")
                    c1, c2 = st.columns(2)
                    with c1:
                        if st.button("确认", type="primary", use_container_width=True, key="done_delete_ok"):
                            ok, err = hard_delete(ids, cancel_task=cancel_task, clear_tasks=clear_tasks)
                            st.session_state.done_delete_confirming = False
                            st.session_state.done_delete_target_ids = []
                            if ok:
                                for fid in ids:
                                    st.session_state[f"done_sel_{fid}"] = False
                                st.session_state.done_selected_ids = []
                                if str(st.session_state.get("main_selected_id") or "") in set(ids):
                                    st.session_state.main_selected_id = ""
                                st.success(f"已删除 {len(ids)} 个文件")
                                st.rerun()
                            else:
                                st.error(f"删除失败：{err}")
                    with c2:
                        if st.button("取消", use_container_width=True, key="done_delete_cancel"):
                            st.session_state.done_delete_confirming = False
                            st.session_state.done_delete_target_ids = []
                            st.rerun()

                if bool(st.session_state.done_delete_confirming):
                    _dlg_delete_done_files()
                for r in done_list:
                    rid = r["id"]
                    cols = st.columns([0.7, 4, 1, 1])
                    with cols[0]:
                        k = f"done_sel_{rid}"
                        if k not in st.session_state:
                            st.session_state[k] = False
                        prev = bool(st.session_state.get(k, False))
                        cur = st.checkbox("✓", key=k, label_visibility="collapsed")
                        sel = set(st.session_state.done_selected_ids or [])
                        if cur:
                            sel.add(rid)
                        else:
                            sel.discard(rid)
                        st.session_state.done_selected_ids = list(sel)
                        if cur and (cur != prev):
                            st.session_state.main_selected_kind = "file"
                            st.session_state.main_selected_id = rid
                            st.rerun()
                    with cols[1]:
                        if st.button(r.get("name", "文件"), key=f"done-name-{rid}", use_container_width=True):
                            st.session_state.main_selected_kind = "file"
                            st.session_state.main_selected_id = rid
                            st.rerun()
                        st.caption(f"{format_size(int(r.get('size', 0)))} | {r.get('mime','')}")
                    with cols[2]:
                        if st.button("×", key=f"done-del-{rid}", use_container_width=True):
                            ok, err = hard_delete([rid], cancel_task=cancel_task, clear_tasks=clear_tasks)
                            if ok:
                                st.success("已删除 1 个文件")
                                st.rerun()
                            else:
                                st.error(f"删除失败：{err}")
                    with cols[3]:
                        if st.button("↩", key=f"done-back-{rid}", use_container_width=True):
                            cancel_task(rid)
                            clear_tasks([rid])
                            move_files([rid], "active")
                            update_selected([rid], True)
                            update_order({rid: st.session_state.upload_order_counter})
                            st.session_state.upload_order_counter += 1
                            force_ids = set(st.session_state.get("force_recognize_ids") or [])
                            if rid:
                                force_ids.add(str(rid))
                            st.session_state.force_recognize_ids = list(force_ids)
                            st.session_state.main_selected_kind = "file"
                            st.session_state.main_selected_id = rid
                            st.success("已退回")
                            st.rerun()
        st.subheader("OCR 历史")
        with st.spinner("加载历史记录..."):
            try:
                history_list = history_manager.get_history_list()
            except Exception:
                history_list = []
        box2 = st.container(height=240)
        with box2:
            ids = [h["id"] for h in history_list]
            labels = {h["id"]: f"{h.get('display_time','')} | {h.get('file_name','')}" for h in history_list}

            cur_kind = st.session_state.get("main_selected_kind") or ""
            cur_id = st.session_state.get("main_selected_id") or ""
            target_id = str(st.session_state.get("history_pick_main") or "")
            if not target_id and cur_kind == "history":
                target_id = str(cur_id or "")

            bar1, bar2, bar3 = st.columns([2, 2, 2])
            with bar1:
                if st.button("删除选中", use_container_width=True, disabled=not bool(target_id)):
                    st.session_state.history_delete_confirming = True
                    st.session_state.history_delete_target = target_id
                    st.rerun()
            with bar2:
                if st.button("清空全部", use_container_width=True, disabled=not bool(ids)):
                    st.session_state.history_clear_all_confirming = True
                    st.rerun()
            with bar3:
                st.caption(f"{len(ids)} 条")

            if st.session_state.history_delete_confirming:
                del_id = str(st.session_state.get("history_delete_target") or "")
                st.warning("确认删除选中的历史记录？")
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("确认删除", type="primary", use_container_width=True, key="hist_del_ok"):
                        try:
                            if del_id:
                                history_manager.delete_history(del_id)
                        except Exception:
                            pass
                        st.session_state.history_delete_confirming = False
                        st.session_state.history_delete_target = ""
                        if str(st.session_state.get("history_pick_main") or "") == del_id:
                            st.session_state.history_pick_main = None
                        if (st.session_state.get("main_selected_kind") or "") == "history" and str(st.session_state.get("main_selected_id") or "") == del_id:
                            st.session_state.main_selected_kind = ""
                            st.session_state.main_selected_id = ""
                        st.rerun()
                with c2:
                    if st.button("取消", use_container_width=True, key="hist_del_cancel"):
                        st.session_state.history_delete_confirming = False
                        st.session_state.history_delete_target = ""
                        st.rerun()

            if st.session_state.history_clear_all_confirming:
                st.warning("确认清空全部历史记录？此操作不可恢复。")
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("确认清空", type="primary", use_container_width=True, key="hist_clear_ok"):
                        try:
                            history_manager.delete_all_history()
                        except Exception:
                            pass
                        st.session_state.history_clear_all_confirming = False
                        st.session_state.history_pick_main = None
                        if (st.session_state.get("main_selected_kind") or "") == "history":
                            st.session_state.main_selected_kind = ""
                            st.session_state.main_selected_id = ""
                        st.rerun()
                with c2:
                    if st.button("取消", use_container_width=True, key="hist_clear_cancel"):
                        st.session_state.history_clear_all_confirming = False
                        st.rerun()

            def _on_history_pick_change():
                picked = st.session_state.get("history_pick_main")
                if picked:
                    st.session_state.main_selected_kind = "history"
                    st.session_state.main_selected_id = picked
                    st.session_state.upload_expanded = False

            idx = None
            if ids and cur_kind == "history" and cur_id in ids:
                try:
                    idx = ids.index(cur_id)
                except Exception:
                    idx = None
            pick = st.radio(
                "历史",
                options=ids,
                index=idx,
                format_func=lambda x: labels.get(x, x),
                label_visibility="collapsed",
                key="history_pick_main",
                on_change=_on_history_pick_change,
            )
    with right_col:
        kind = st.session_state.get("main_selected_kind") or ""
        sel = st.session_state.get("main_selected_id") or ""
        if kind == "camera":
            st.subheader("📷 拍照上传")
            if "camera_ack_seq" not in st.session_state:
                st.session_state.camera_ack_seq = 0
            cam_payload = camera_auto(disabled=False, ack_seq=st.session_state.camera_ack_seq, key="camera_auto_compact", height=640)

            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "error":
                err_name = str(cam_payload.get("name") or "")
                err_msg = str(cam_payload.get("message") or "")
                if err_name in {"NotAllowedError", "SecurityError"}:
                    if err_name == "SecurityError":
                        st.error("相机无法打开：当前页面不是安全来源（HTTPS/localhost）。请使用 localhost 访问或启用 HTTPS 后重试。")
                    else:
                        st.error("相机权限被拒绝：请在浏览器地址栏右侧允许相机访问后重试。")
                elif err_name in {"NotFoundError"}:
                    st.error("未检测到可用摄像头设备。")
                elif err_name in {"NotReadableError"}:
                    st.error("摄像头被占用或无法读取，请关闭其他占用相机的软件后重试。")
                else:
                    st.error(f"相机启动失败：{err_name} {err_msg}".strip())

            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "capture":
                seq = int(cam_payload.get("seq") or 0)
                prev_ack = int(st.session_state.camera_ack_seq or 0)
                already = seq and seq <= prev_ack
                did_rerun = False
                if seq and seq > prev_ack:
                    st.session_state.camera_ack_seq = seq
                if not already:
                    data_url = str(cam_payload.get("data_url") or "")
                    if data_url.startswith("data:image/"):
                        try:
                            head, b64 = data_url.split(",", 1)
                        except Exception:
                            head, b64 = "", ""
                        mime_type = "image/jpeg"
                        if ";" in head and head.startswith("data:"):
                            mime_type = head[5:].split(";", 1)[0] or "image/jpeg"
                        raw = base64.b64decode(b64.encode("utf-8")) if b64 else b""
                        if raw:
                            photo_token = hashlib.sha256(raw).hexdigest()
                            if seq == 0 and photo_token == st.session_state.get("upload_last_camera_token"):
                                pass
                            else:
                                if seq == 0:
                                    st.session_state.upload_last_camera_token = photo_token
                                now_dt = datetime.datetime.now()
                                base = photo_basename(now_dt)
                                ms = now_dt.strftime("%f")[:3]
                                suffix = f"_{ms}"
                                if seq:
                                    suffix += f"_{seq}"
                                file_name = f"{base}{suffix}.jpg"
                                size = len(raw)
                                if exists_name_size(file_name, size):
                                    st.info("该照片已存在")
                                    if seq:
                                        st.session_state.camera_ack_seq = max(int(st.session_state.camera_ack_seq or 0), seq)
                                else:
                                    file_id = uuid.uuid4().hex
                                    src = str(cam_payload.get("source") or "camera")
                                    day = now_dt.strftime("%Y-%m-%d")
                                    subdir = os.path.join("camera", safe_filename(src), day)
                                    save_path, mime_type2, final_size = save_camera_bytes_to_disk(
                                        raw, file_id=file_id, file_name=file_name, mime_type=mime_type, subdir=subdir
                                    )
                                    now = now_dt.strftime("%Y-%m-%d %H:%M:%S")
                                    supported = is_ocr_supported(file_name, mime_type2)
                                    upsert_file(
                                        {
                                            "id": file_id,
                                            "name": file_name,
                                            "size": final_size,
                                            "mime": mime_type2,
                                            "path": save_path,
                                            "status": "active",
                                            "supported": supported,
                                            "selected": supported,
                                            "order_num": st.session_state.upload_order_counter,
                                            "created_at": now,
                                            "error": "",
                                        }
                                    )
                                    st.session_state.upload_order_counter += 1
                                    add_operation(
                                        "photo_added",
                                        {"id": file_id, "name": file_name, "mime": mime_type2, "size": final_size, "source": src},
                                    )
                                    st.success("照片已加入待识别")
                                    if seq:
                                        st.session_state.camera_ack_seq = max(int(st.session_state.camera_ack_seq or 0), seq)
                                    did_rerun = True
                                    st.rerun()
                if seq and (int(st.session_state.camera_ack_seq or 0) != prev_ack) and not did_rerun:
                    st.rerun()
            return
        if not kind or not sel:
            if ordered:
                st.session_state.main_selected_kind = "file"
                st.session_state.main_selected_id = ordered[0]["id"]
                kind = "file"
                sel = ordered[0]["id"]
            elif history_list:
                st.session_state.main_selected_kind = "history"
                st.session_state.main_selected_id = history_list[0]["id"]
                kind = "history"
                sel = history_list[0]["id"]
            else:
                st.info("👈 请在左侧上传文件或选择历史记录")
                return
        if kind == "file":
            rr = get_record_any(sel)
            task = get_task(sel)
            st.markdown(
                f"<div style='text-align:center;font-size:1.25rem;font-weight:700;margin:0.2rem 0 0.4rem 0;'>"
                f"{html.escape(rr.get('name', '文件') or '文件')}</div>",
                unsafe_allow_html=True,
            )
            path = rr.get("path", "")
            mime_type = rr.get("mime", "")
            try:
                if path and os.path.exists(path):
                    with open(path, "rb") as f:
                        b = f.read()
                    if rr.get("name", "").lower().endswith(".pdf") or mime_type == "application/pdf":
                        try:
                            page_total = int(FileProcessor.pdf_page_count(b) or 0)
                        except Exception:
                            page_total = 0
                        if page_total <= 1:
                            img0 = FileProcessor.pdf_page_to_image(b, 0) if page_total == 1 else None
                            if img0 is not None:
                                st.image(img0, caption="预览", use_container_width=True)
                        else:
                            def _on_pdf_page_change():
                                st.session_state.main_selected_kind = "file"
                                st.session_state.main_selected_id = sel
                                st.session_state.upload_expanded = False
                            page_key = f"pdf_preview_page_{sel}"
                            cur = int(st.session_state.get(page_key, 1) or 1)
                            if cur < 1:
                                cur = 1
                            if cur > page_total:
                                st.session_state[page_key] = page_total
                                cur = page_total
                            left_space, mid, right_space = st.columns([2, 6, 2])
                            with mid:
                                label_col, input_col = st.columns([1, 7])
                                with label_col:
                                    st.markdown(
                                        "<div style='text-align:right;padding-top:0.55rem;font-weight:600;'>页码</div>",
                                        unsafe_allow_html=True,
                                    )
                                with input_col:
                                    page = st.number_input(
                                        "",
                                        min_value=1,
                                        max_value=page_total,
                                        value=cur,
                                        step=1,
                                        key=page_key,
                                        on_change=_on_pdf_page_change,
                                        label_visibility="collapsed",
                                    )
                            img = FileProcessor.pdf_page_to_image(b, int(page) - 1)
                            if img is not None:
                                st.image(img, caption=f"预览（第 {int(page)}/{page_total} 页）", use_container_width=True)
                    elif mime_type.startswith("image/"):
                        imgs = FileProcessor.process_image(b)
                        if imgs:
                            st.image(imgs[0], caption="预览", use_container_width=True)
                    else:
                        st.text_area("预览", value=b[:6000].decode("utf-8", errors="ignore"), height=200, disabled=True)
                else:
                    st.caption("文件未保存或已被删除。")
            except Exception as e:
                st.caption(f"预览失败：{e}")
            status_raw = (task.status if task else rr.get("status", "")) or ""
            if status_raw in {"排队中", "识别中"}:
                st.progress(float(task.progress) if task else 0.0)
                if task and task.page_total:
                    st.caption(f"{task.page_index}/{task.page_total}")
                time.sleep(0.5)
                st.rerun()
            elif status_raw in {"已完成", "已完成（缓存）"} and task and task.result:
                md = strip_file_name_headers(task.result)
                render_download_buttons(md, rr.get("name", "ocr_result.md") or "ocr_result.md", key_prefix=f"one-{sel}")
                tab_preview, tab_source = st.tabs(["👁️ 渲染预览", "📝 源码"])
                with tab_source:
                    render_copy_button(md, key=f"one-source-{sel}")
                    st.text_area("Markdown", value=md, height=480, disabled=True, key=f"ta-{sel}")
                with tab_preview:
                    render_copy_button(markdown_to_visible_text(strip_file_name_headers(md)), key=f"one-preview-{sel}")
                    st.markdown(md, unsafe_allow_html=True)
            elif status_raw in {"失败", "上传失败", "已取消", "不支持"}:
                reason = rr.get("error", "") or (task.error if task else "") or ""
                st.text_area("错误", value=reason, height=200, disabled=True)
        elif kind == "history":
            record = next((h for h in history_list if h["id"] == sel), None)
            if record:
                st.subheader(record.get("file_name", "历史记录"))
                md = record.get("content", "") or ""
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("删除此记录", use_container_width=True):
                        st.session_state.history_delete_confirming = True
                        st.session_state.history_delete_target = str(record.get("id") or "")
                        st.rerun()
                with c2:
                    if st.button("清空全部历史", use_container_width=True):
                        st.session_state.history_clear_all_confirming = True
                        st.rerun()
                render_download_buttons(md, record.get("file_name", "ocr_report.md") or "ocr_report.md", key_prefix=f"hist-one-{sel}")
                tab_preview, tab_source = st.tabs(["👁️ 渲染预览", "📝 源码"])
                with tab_source:
                    render_copy_button(md, key=f"hist-source-{sel}")
                    st.text_area("Markdown", value=md, height=480, disabled=True, key=f"hist-ta-{sel}")
                with tab_preview:
                    render_copy_button(markdown_to_visible_text(strip_file_name_headers(md)), key=f"hist-preview-{sel}")
                    st.markdown(md, unsafe_allow_html=True)
    return

def main():
    history_manager = HistoryManager()

    config = render_sidebar()

    if "compact_ui" not in st.session_state:
        st.session_state.compact_ui = True
    if st.session_state.compact_ui:
        render_compact_ui(history_manager, config)
        return
    ensure_upload_state()
    _sync_records_from_db()
    if "history_clear_all_confirming" not in st.session_state:
        st.session_state.history_clear_all_confirming = False
    view = ""
    try:
        qp = st.query_params or {}
        view = qp.get("view", "")
        if isinstance(view, list):
            view = view[0] if view else ""
        view = str(view or "").strip().lower()
    except Exception:
        view = ""

    if view == "fullscreen":
        render_fullscreen_batch_view()
        if any(get_task(fid) and get_task(fid).status in {"排队中", "识别中"} for fid in (st.session_state.get("batch_file_ids") or [])):
            time.sleep(0.4)
            st.rerun()
        return

    st.markdown("")
    
    with st.sidebar:
        st.divider()
        st.header("🕒 识别历史")
        with st.spinner("正在加载历史记录..."):
            try:
                history_list = history_manager.get_history_list()
            except Exception:
                history_list = []
                st.error("历史记录加载失败")

        @st.dialog("清除全部历史记录")
        def _dlg_clear_all_history():
            st.write("确认要清除全部识别历史记录吗？")
            st.caption("此操作会删除本地 history 目录下的所有历史记录文件，且不可恢复。")
            c1, c2 = st.columns(2)
            with c1:
                if st.button("确认", type="primary", use_container_width=True, key="hist_clear_all_ok"):
                    deleted = history_manager.delete_all_history()
                    st.session_state.history_selected_id = None
                    st.session_state.current_result = ""
                    st.session_state.current_filename = ""
                    st.session_state.current_result_token = uuid.uuid4().hex
                    st.session_state.history_clear_all_confirming = False
                    st.session_state.op_banner = f"已清除全部历史记录（{deleted} 条）"
                    st.rerun()
            with c2:
                if st.button("取消", use_container_width=True, key="hist_clear_all_cancel"):
                    st.session_state.history_clear_all_confirming = False
                    st.rerun()
        
        if not history_list:
            st.caption("暂无历史记录")
        else:
            hbtn1, hbtn2 = st.columns([1, 3])
            with hbtn1:
                if st.button("清除全部", type="secondary", use_container_width=True):
                    st.session_state.history_clear_all_confirming = True
            with hbtn2:
                st.caption(f"共 {len(history_list)} 条记录")

            if st.session_state.history_clear_all_confirming:
                _dlg_clear_all_history()
                st.stop()

            page_size = st.selectbox("每页条数", options=[20, 50, 100], index=0, key="history_page_size")
            total_pages = max(1, (len(history_list) + page_size - 1) // page_size)
            page = st.number_input("页码", min_value=1, max_value=total_pages, value=1, step=1, key="history_page")
            start = (page - 1) * page_size
            end = start + page_size
            page_records = history_list[start:end]
            id_to_label = {
                r["id"]: f"{r.get('display_time','')} | {r.get('file_name','')} | {r.get('summary','')}"
                for r in page_records
            }

            def on_history_change():
                hist_id = st.session_state.history_selected_id
                if hist_id:
                    record = next((h for h in history_list if h["id"] == hist_id), None)
                    if record:
                        set_current_result(record.get("content", ""), record.get("file_name", "ocr_report.md"))
                        st.session_state.source_editor = st.session_state.current_result
                        st.session_state.source_editor_token = st.session_state.current_result_token
                    else:
                        st.error("未找到该历史记录内容")

            selected_history_id = st.selectbox(
                "选择历史记录",
                options=[r["id"] for r in page_records],
                format_func=lambda x: id_to_label.get(x, x),
                key="history_selected_id",
                index=None,
                placeholder="请选择历史记录...",
                on_change=on_history_change
            )
            
            if selected_history_id:
                record = next((h for h in history_list if h["id"] == selected_history_id), None)
                if record:
                    st.caption(f"时间: {record.get('display_time','')}")
                    if record.get("summary"):
                        st.caption(f"摘要: {record.get('summary')}")
                    with st.expander("预览内容", expanded=False):
                        st.text_area("内容预览", value=record.get("content", ""), height=200, disabled=True)
                    render_download_buttons(record.get("content", "") or "", record.get("file_name", "ocr_report.md") or "ocr_report.md", key_prefix=f"hist-{selected_history_id}")
                    
                    if st.button("删除此记录", type="primary"):
                        history_manager.delete_history(selected_history_id)
                        st.rerun()

    # Initialize Client
    client = LLMClient(
        base_url=config["api_base"],
        api_key=config["api_key"],
        service_type=config.get("service_type", "auto"),
    )

    # 2. File Upload
    st.markdown(
        """
        <style>
          .block-container { padding-top: 1.1rem; padding-bottom: 1.2rem; max-width: 100% !important; padding-left: 1.6rem; padding-right: 1.6rem; }
          h2, h3 { margin-top: 0.6rem; margin-bottom: 0.4rem; }
          h1 { margin-top: 0.2rem; margin-bottom: 0.4rem; line-height: 1.25; padding-top: 0.15rem; }
          div[data-testid="stMarkdownContainer"] h1 { overflow: visible !important; text-overflow: clip !important; white-space: normal !important; }
          header[data-testid="stHeader"] { overflow: visible !important; }
          header[data-testid="stHeader"] * { overflow: visible !important; }
          div[data-testid="stMarkdownContainer"] h1 { display: inline-flex; align-items: center; gap: 0.35rem; }
          [data-testid="stCaptionContainer"] p { margin-bottom: 0.25rem; }
          button[kind="secondary"] { transition: filter 120ms ease; }
          button[kind="secondary"]:hover { filter: brightness(1.08); }
          button[kind="primary"] { transition: filter 120ms ease, transform 80ms ease; }
          button[kind="primary"]:hover { filter: brightness(1.06); }
          button[kind="primary"]:active { transform: scale(0.99); }
          div[data-testid="stFileUploader"] [data-testid="stFileUploaderFile"] { display: none !important; }
          div[data-testid="stFileUploader"] [data-testid="stFileUploaderUploadedFile"] { display: none !important; }
          div[data-testid="stFileUploader"] ul { display: none !important; }
          section[data-testid="stFileUploaderDropzone"] div[data-testid="stFileUploaderDropzoneInstructions"] > * { display: none !important; }
          section[data-testid="stFileUploaderDropzone"] div[data-testid="stFileUploaderDropzoneInstructions"]::before { content: "拖拽文件到此处"; display: block; font-weight: 800; }
          section[data-testid="stFileUploaderDropzone"] div[data-testid="stFileUploaderDropzoneInstructions"]::after { content: "单个文件最大 100GB"; display: block; opacity: 0.75; font-size: 0.86rem; margin-top: 0.25rem; }
          section[data-testid="stFileUploaderDropzone"] button { font-size: 0 !important; }
          section[data-testid="stFileUploaderDropzone"] button::after { content: "选择文件"; font-size: 0.95rem; font-weight: 800; }
          div[role="dialog"] { z-index: 1000000 !important; }
          div[role="dialog"] ~ div { z-index: 1000000 !important; }
          div[data-testid="stDialog"] { z-index: 1000000 !important; }
          @media (max-width: 1024px) {
            .block-container { padding-left: 1.0rem; padding-right: 1.0rem; }
            div[data-testid="stHorizontalBlock"] { flex-wrap: wrap; }
            div[data-testid="stHorizontalBlock"] > div[data-testid="column"] { width: 100% !important; flex: 1 1 100% !important; }
          }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.expander("文件上传", expanded=True):
        st.caption("将文件拖拽到下方上传框，或点击选择文件；上传后会自动加入待识别队列。")

        uploaded_files = st.file_uploader(
            "拖放文件到此处或点击上传（支持多选）",
            type=None,
            accept_multiple_files=True,
            key="upload_picker",
            label_visibility="visible",
        )

        with st.expander("📷 拍照上传", expanded=False):
            if "camera_ack_seq" not in st.session_state:
                st.session_state.camera_ack_seq = 0
            cam_payload = camera_auto(disabled=False, ack_seq=st.session_state.camera_ack_seq, key="camera_auto")
            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "perf":
                try:
                    st.session_state.camera_perf = dict(cam_payload)
                except Exception:
                    st.session_state.camera_perf = {"action": "perf"}

            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "info":
                try:
                    st.session_state.camera_info = dict(cam_payload)
                except Exception:
                    st.session_state.camera_info = {"action": "info"}

            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "error":
                err_name = str(cam_payload.get("name") or "")
                err_msg = str(cam_payload.get("message") or "")
                st.session_state.camera_last_error = {"name": err_name, "message": err_msg}
                if err_name in {"NotAllowedError", "SecurityError"}:
                    if err_name == "SecurityError":
                        st.error("相机无法打开：当前页面不是安全来源（HTTPS/localhost）。请使用 localhost 访问或启用 HTTPS 后重试。")
                    else:
                        st.error("相机权限被拒绝：请在浏览器地址栏右侧允许相机访问后重试。")
                elif err_name in {"NotFoundError"}:
                    st.error("未检测到可用摄像头设备。")
                elif err_name in {"NotReadableError"}:
                    st.error("摄像头被占用或无法读取，请关闭其他占用相机的软件后重试。")
                else:
                    st.error(f"相机启动失败：{err_name} {err_msg}".strip())

            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "capture":
                seq = int(cam_payload.get("seq") or 0)
                prev_ack = int(st.session_state.camera_ack_seq or 0)
                already = seq and seq <= prev_ack
                did_rerun = False
                if seq and seq > prev_ack:
                    st.session_state.camera_ack_seq = seq
                if not already:
                    data_url = str(cam_payload.get("data_url") or "")
                    if data_url.startswith("data:image/"):
                        try:
                            head, b64 = data_url.split(",", 1)
                        except Exception:
                            head, b64 = "", ""
                        mime_type = "image/jpeg"
                        if ";" in head and head.startswith("data:"):
                            mime_type = head[5:].split(";", 1)[0] or "image/jpeg"
                        raw = base64.b64decode(b64.encode("utf-8")) if b64 else b""
                        if raw:
                            photo_token = hashlib.sha256(raw).hexdigest()
                            if seq == 0 and photo_token == st.session_state.upload_last_camera_token:
                                pass
                            else:
                                if seq == 0:
                                    st.session_state.upload_last_camera_token = photo_token
                                now_dt = datetime.datetime.now()
                                base = photo_basename(now_dt)
                                ms = now_dt.strftime("%f")[:3]
                                suffix = f"_{ms}"
                                if seq:
                                    suffix += f"_{seq}"
                                file_name = f"{base}{suffix}.jpg"
                                size = len(raw)
                                if exists_name_size(file_name, size):
                                    st.warning("该照片已存在")
                                    if seq:
                                        st.session_state.camera_ack_seq = max(int(st.session_state.camera_ack_seq or 0), seq)
                                else:
                                    file_id = uuid.uuid4().hex
                                    last_err = ""
                                    src = str(cam_payload.get("source") or "camera")
                                    day = now_dt.strftime("%Y-%m-%d")
                                    subdir = os.path.join("camera", safe_filename(src), day)
                                    for i in range(3):
                                        try:
                                            save_path, mime_type2, final_size = save_camera_bytes_to_disk(
                                                raw, file_id=file_id, file_name=file_name, mime_type=mime_type, subdir=subdir
                                            )
                                            last_err = ""
                                            break
                                        except Exception as e:
                                            last_err = str(e)
                                            time.sleep(0.15 * (i + 1))
                                    else:
                                        os.makedirs(os.path.join("uploads", "pending"), exist_ok=True)
                                        safe_name = safe_filename(file_name)
                                        save_path = os.path.join("uploads", "pending", f"{file_id}_{safe_name}")
                                        with open(save_path, "wb") as out:
                                            out.write(raw)
                                        mime_type2 = mime_type or "image/jpeg"
                                        final_size = int(os.path.getsize(save_path)) if os.path.exists(save_path) else len(raw)

                                    now = now_dt.strftime("%Y-%m-%d %H:%M:%S")
                                    supported = is_ocr_supported(file_name, mime_type2)
                                    err_text = "" if not last_err else f"待上传：{last_err}"
                                    upsert_file(
                                        {
                                            "id": file_id,
                                            "name": file_name,
                                            "size": final_size,
                                            "mime": mime_type2,
                                            "path": save_path,
                                            "status": "active",
                                            "supported": supported and not bool(last_err),
                                            "selected": supported and not bool(last_err),
                                            "order_num": st.session_state.upload_order_counter,
                                            "created_at": now,
                                            "error": err_text,
                                        }
                                    )
                                    try:
                                        meta = {
                                            "captured_at": str(cam_payload.get("captured_at") or now_dt.isoformat(timespec="seconds")),
                                            "source": str(cam_payload.get("source") or "camera"),
                                            "label": str(cam_payload.get("label") or ""),
                                            "device": cam_payload.get("device") or {},
                                            "mime": mime_type2,
                                            "size": int(final_size),
                                            "sha256": photo_token,
                                            "path": save_path,
                                        }
                                        os.makedirs("uploads_meta", exist_ok=True)
                                        with open(os.path.join("uploads_meta", f"{file_id}.json"), "w", encoding="utf-8") as f:
                                            json.dump(meta, f, ensure_ascii=False, indent=2)
                                    except Exception:
                                        pass
                                    st.session_state.upload_order_counter += 1
                                    st.session_state.camera_last_file_id = file_id
                                    st.session_state.camera_last_path = save_path
                                    add_operation(
                                        "photo_added",
                                        {"id": file_id, "name": file_name, "mime": mime_type2, "size": final_size, "source": src},
                                    )
                                    if last_err:
                                        st.warning("照片已保存到本地（待上传状态）")
                                    else:
                                        st.success("照片已添加")
                                    if seq:
                                        st.session_state.camera_ack_seq = max(int(st.session_state.camera_ack_seq or 0), seq)
                                    did_rerun = True
                                    st.rerun()

                if seq and (int(st.session_state.camera_ack_seq or 0) != prev_ack) and not did_rerun:
                    st.rerun()

            if cam_payload and isinstance(cam_payload, dict) and cam_payload.get("action") == "record":
                seq = int(cam_payload.get("seq") or 0)
                prev_ack = int(st.session_state.camera_ack_seq or 0)
                already = seq and seq <= prev_ack
                did_rerun = False
                if seq and seq > prev_ack:
                    st.session_state.camera_ack_seq = seq
                if not already:
                    data_url = str(cam_payload.get("data_url") or "")
                    if data_url.startswith("data:video/"):
                        try:
                            head, b64 = data_url.split(",", 1)
                        except Exception:
                            head, b64 = "", ""
                        mime_type = "video/webm"
                        if ";" in head and head.startswith("data:"):
                            mime_type = head[5:].split(";", 1)[0] or "video/webm"
                        raw = base64.b64decode(b64.encode("utf-8")) if b64 else b""
                        if raw:
                            video_token = hashlib.sha256(raw).hexdigest()
                            if seq == 0 and video_token == st.session_state.upload_last_camera_token:
                                pass
                            else:
                                if seq == 0:
                                    st.session_state.upload_last_camera_token = video_token
                                now_dt = datetime.datetime.now()
                                base = photo_basename(now_dt)
                                ext = "webm"
                                if "mp4" in mime_type:
                                    ext = "mp4"
                                elif "ogg" in mime_type:
                                    ext = "ogv"
                                ms = now_dt.strftime("%f")[:3]
                                suffix = f"_{ms}"
                                if seq:
                                    suffix += f"_{seq}"
                                file_name = f"{base}{suffix}.{ext}"
                                file_id = uuid.uuid4().hex
                                day = now_dt.strftime("%Y-%m-%d")
                                subdir = os.path.join("camera", "video", day)
                                save_path, mime_type2, final_size = save_camera_bytes_to_disk(
                                    raw, file_id=file_id, file_name=file_name, mime_type=mime_type, subdir=subdir
                                )
                                now = now_dt.strftime("%Y-%m-%d %H:%M:%S")
                                upsert_file(
                                    {
                                        "id": file_id,
                                        "name": file_name,
                                        "size": final_size,
                                        "mime": mime_type2,
                                        "path": save_path,
                                        "status": "active",
                                        "supported": False,
                                        "selected": False,
                                        "order_num": st.session_state.upload_order_counter,
                                        "created_at": now,
                                        "error": "",
                                    }
                                )
                                try:
                                    meta = {
                                        "captured_at": str(cam_payload.get("captured_at") or now_dt.isoformat(timespec="seconds")),
                                        "source": str(cam_payload.get("source") or "camera"),
                                        "label": str(cam_payload.get("label") or ""),
                                        "device": cam_payload.get("device") or {},
                                        "mime": mime_type2,
                                        "size": int(final_size),
                                        "sha256": video_token,
                                    }
                                    os.makedirs("uploads_meta", exist_ok=True)
                                    with open(os.path.join("uploads_meta", f"{file_id}.json"), "w", encoding="utf-8") as f:
                                        json.dump(meta, f, ensure_ascii=False, indent=2)
                                except Exception:
                                    pass
                                st.session_state.upload_order_counter += 1
                                add_operation("video_added", {"id": file_id, "name": file_name, "mime": mime_type2, "size": final_size})
                                st.success("录像已保存")
                                if seq:
                                    st.session_state.camera_ack_seq = max(int(st.session_state.camera_ack_seq or 0), seq)
                                did_rerun = True
                                st.rerun()

                if seq and (int(st.session_state.camera_ack_seq or 0) != prev_ack) and not did_rerun:
                    st.rerun()

            with st.expander("兼容模式（系统相机控件）", expanded=False):
                if "compat_camera_enabled" not in st.session_state:
                    st.session_state.compat_camera_enabled = False
                enabled = st.toggle("启用兼容模式相机", value=bool(st.session_state.compat_camera_enabled), key="compat_camera_enabled")
                if not enabled:
                    if "camera_picker" in st.session_state:
                        st.session_state.camera_picker = None
                    st.caption("关闭后将释放系统相机控件对摄像头的占用。")
                else:
                    photo = st.camera_input("拍照", key="camera_picker", label_visibility="visible")
                    if photo:
                        photo_token = f"{getattr(photo,'name','')}:{getattr(photo,'size',None)}:{getattr(photo,'type',None)}"
                        if photo_token and photo_token != st.session_state.upload_last_camera_token:
                            st.session_state.upload_last_camera_token = photo_token
                            now_dt = datetime.datetime.now()
                            base = photo_basename(now_dt)
                            file_name = f"{base}.jpg"
                            raw = photo.getvalue()
                            img = Image.open(io.BytesIO(raw))
                            if img.mode != "RGB":
                                img = img.convert("RGB")
                            img = _remove_camera_watermark(img)
                            buf = io.BytesIO()
                            img.save(buf, format="JPEG", quality=90)
                            data = buf.getvalue()
                            size = len(data)
                            if exists_name_size(file_name, size):
                                st.warning("该文件已存在")
                            else:
                                file_id = uuid.uuid4().hex
                                save_path, mime_type, final_size = save_bytes_to_disk(data, file_id=file_id, file_name=file_name, mime_type="image/jpeg")
                                now = now_dt.strftime("%Y-%m-%d %H:%M:%S")
                                supported = is_ocr_supported(file_name, mime_type)
                                upsert_file(
                                    {
                                        "id": file_id,
                                        "name": file_name,
                                        "size": final_size,
                                        "mime": mime_type,
                                        "path": save_path,
                                        "status": "active",
                                        "supported": supported,
                                        "selected": supported,
                                        "order_num": st.session_state.upload_order_counter,
                                        "created_at": now,
                                        "error": "",
                                    }
                                )
                                st.session_state.upload_order_counter += 1
                                add_operation("photo_added", {"id": file_id, "name": file_name, "mime": mime_type, "size": final_size})
                                st.success("照片已添加")
                                st.rerun()

        new_token = upload_token(uploaded_files)
        should_add = bool(uploaded_files) and (new_token and new_token != st.session_state.upload_last_add_token)

        if should_add and uploaded_files:
            st.session_state.upload_last_add_token = new_token or uuid.uuid4().hex
            overall = st.progress(0)
            status = st.empty()
            for idx, f in enumerate(uploaded_files):
                file_id = uuid.uuid4().hex
                file_name = f.name
                mime_type = getattr(f, "type", None) or mimetypes.guess_type(file_name)[0] or ""
                size = int(getattr(f, "size", None) or 0)
                now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                if exists_name_size(file_name, size):
                    st.warning("该文件已存在")
                    continue

                if not is_ocr_supported(file_name, mime_type):
                    st.warning(f"不支持的文件类型，已跳过：{file_name}")
                    continue

                status.text(f"正在保存: {file_name}")
                try:
                    save_path, mime_type, final_size = save_uploaded_file_to_disk(f, file_id=file_id)
                except Exception as e:
                    upsert_file(
                        {
                            "id": file_id,
                            "name": file_name,
                            "size": size,
                            "mime": mime_type,
                            "path": "",
                            "status": "active",
                            "supported": False,
                            "selected": False,
                            "order_num": st.session_state.upload_order_counter,
                            "created_at": now,
                            "error": str(e),
                        }
                    )
                    st.session_state.upload_order_counter += 1
                    continue

                if exists_name_size(file_name, final_size):
                    try:
                        if save_path and os.path.exists(save_path):
                            os.remove(save_path)
                    except Exception:
                        pass
                    st.warning("该文件已存在")
                    continue

                supported = is_ocr_supported(file_name, mime_type)
                upsert_file(
                    {
                        "id": file_id,
                        "name": file_name,
                        "size": final_size,
                        "mime": mime_type,
                        "path": save_path,
                        "status": "active",
                        "supported": supported,
                        "selected": supported,
                        "order_num": st.session_state.upload_order_counter,
                        "created_at": now,
                        "error": "",
                    }
                )
                st.session_state.upload_order_counter += 1
                add_operation("file_added", {"id": file_id, "name": file_name, "mime": mime_type, "size": final_size})

                overall.progress((idx + 1) / max(1, len(uploaded_files)))

            status.empty()
            overall.empty()
            st.rerun()

    st.divider()

    active_rows, removed_rows = _sync_records_from_db()
    records = list(st.session_state.upload_records.values())
    st.subheader("🗂️ 文件管理")
    selected_cnt = sum(1 for r in st.session_state.upload_records.values() if bool(r.get("supported")) and bool(r.get("selected")))
    st.caption(f"工作台已选：{selected_cnt} | 工作台文件：{len(st.session_state.upload_records)} | 文件夹文件：{len(removed_rows)}")
    if not records and not removed_rows:
        st.caption("暂无文件。请先在上方上传到工作台。")

    for rid, r in list(st.session_state.upload_records.items()):
        task = get_task(rid)
        if task:
            if task.status in {"排队中", "识别中", "已完成", "已完成（缓存）", "失败", "已取消"}:
                r["status"] = task.status
            if task.error:
                r["error"] = task.error

    ordered = sorted(st.session_state.upload_records.values(), key=lambda x: (int(x.get("order", 0)), x.get("uploaded_at", "")))
    for r in ordered:
        if "selected" not in r:
            r["selected"] = bool(r.get("supported"))

    batch_ids_active = list(st.session_state.get("batch_file_ids") or [])
    batch_running = bool(batch_ids_active) and any(get_task(fid) and get_task(fid).status in {"排队中", "识别中"} for fid in batch_ids_active)

    model_ready = bool(st.session_state.get("model_ready", True))
    if not model_ready:
        st.error("模型加载失败，无法启动OCR工作")

    start_bar_left, start_bar_right = st.columns([2, 1])
    with start_bar_left:
        start_clicked = st.button(
            "开始OCR识别",
            type="primary",
            use_container_width=True,
            disabled=batch_running or (not model_ready) or (not any(r.get("supported") and r.get("selected") for r in ordered)),
        )
    with start_bar_right:
        st.caption("勾选工作台文件后开始识别")

    if start_clicked:
        with st.spinner("正在启动 OCR 识别..."):
            selected_records = [r for r in ordered if r.get("supported") and r.get("selected")]
            batch_ids = [r["id"] for r in selected_records]

            seen_orders: set[int] = set()
            bad_orders = False
            for r in ordered:
                try:
                    o = int(r.get("order", 0) or 0)
                except Exception:
                    bad_orders = True
                    break
                if o <= 0:
                    bad_orders = True
                    break
                if o in seen_orders:
                    bad_orders = True
                    break
                seen_orders.add(o)

            if not batch_ids:
                st.error("未选择任何可识别文件，请先勾选文件。")
                st.stop()
            if bad_orders:
                st.error("检测到排序异常：文件序号不完整或存在重复。请检查右侧列表排序后再开始识别。")
                st.stop()

            snapshot = list(batch_ids)
            st.session_state.batch_order_snapshot = snapshot
            st.session_state.batch_order_digest = _order_digest(snapshot)
            st.session_state.batch_order_names = {r["id"]: r.get("name", "") for r in selected_records}

            st.session_state.batch_run_id = uuid.uuid4().hex
            st.session_state.batch_file_ids = batch_ids
            st.session_state.batch_started_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            st.session_state.batch_preview_generated_for = ""

            clear_tasks(batch_ids)
            task_config = dict(config)
            task_config["skip_cache"] = True
            for idx, r in enumerate(selected_records):
                one_cfg = dict(task_config)
                one_cfg["batch_run_id"] = st.session_state.batch_run_id
                one_cfg["batch_seq"] = idx
                if idx == 0:
                    one_cfg["batch_reset"] = True
                start_task(r["id"], dict(r), one_cfg)
            st.session_state.op_banner = f"已开始 OCR 识别：{len(batch_ids)} 个文件"
            add_operation("bulk_start", {"count": len(batch_ids), "run_id": st.session_state.batch_run_id, "skip_cache": True})
            st.rerun()

    dnd_payload = file_dnd(
        active=[{"id": r["id"], "name": r.get("name", ""), "size": int(r.get("size", 0) or 0), "mime": r.get("mime", "")} for r in ordered],
        removed=[{"id": r["id"], "name": r.get("name", ""), "size": int(r.get("size", 0) or 0), "mime": r.get("mime", "")} for r in removed_rows],
        disabled=batch_running,
        key="file_dnd",
    )
    if dnd_payload:
        sig = json.dumps(dnd_payload, ensure_ascii=False, sort_keys=True)
        if sig != (st.session_state.dnd_last_handled or ""):
            st.session_state.dnd_last_handled = sig
            action = dnd_payload.get("action")
            if action == "move":
                to_list = str(dnd_payload.get("to") or "")
                ids = [str(x) for x in (dnd_payload.get("ids") or []) if str(x)]
                if ids and to_list in {"active", "removed"}:
                    if to_list == "active":
                        active_sigs = {(r.get("name", ""), int(r.get("size", 0) or 0), r.get("id", "")) for r in ordered}
                        for fid in ids:
                            fr = (get_files([fid]) or [])
                            if not fr:
                                continue
                            rr = fr[0]
                            name = rr.get("name", "")
                            size = int(rr.get("size", 0) or 0)
                            dup = any((name, size, oid) for (n, s, oid) in active_sigs if n == name and s == size and oid != fid)
                            if dup:
                                add_operation("readd_skip_dup", {"id": fid, "name": name})
                                continue
                            move_files([fid], "active")
                            rr2 = (get_files([fid]) or [rr])[0]
                            rr2["status"] = "active"
                            rr2["selected"] = bool(rr2.get("supported"))
                            rr2["order_num"] = st.session_state.upload_order_counter
                            rr2["removed_at"] = ""
                            upsert_file(rr2)
                            st.session_state.upload_order_counter += 1
                            add_operation("readd", {"id": fid, "name": name})
                    else:
                        for fid in ids:
                            fr = (get_files([fid]) or [])
                            if not fr:
                                continue
                            rr = fr[0]
                            move_files([fid], "removed")
                            rr2 = (get_files([fid]) or [rr])[0]
                            rr2["status"] = "removed"
                            rr2["selected"] = False
                            upsert_file(rr2)
                            add_operation("remove", {"id": fid, "name": rr.get("name", "")})
                    st.rerun()
            elif action == "delete":
                ids = [str(x) for x in (dnd_payload.get("ids") or []) if str(x)]
                if ids:
                    st.session_state.pending_delete_ids = ids
                    st.session_state.pending_delete_confirming = True
            elif action == "clear_workbench":
                if not batch_running:
                    st.session_state.upload_clear_confirming = True

    if st.session_state.op_banner:
        st.success(st.session_state.op_banner)
        st.session_state.op_banner = ""

    @st.dialog("清除工作台")
    def _dlg_clear_workbench():
        ids = [str(r.get("id") or "") for r in st.session_state.upload_records.values() if str(r.get("id") or "")]
        st.write("确认要清除当前工作台内容吗？")
        st.caption("不会删除本地文件，只是把文件从工作台移到文件夹。")
        st.caption(f"待清除：{len(ids)} 个")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("确认", type="primary", use_container_width=True, disabled=not bool(ids), key="dlg_clear_ok"):
                for fid in ids:
                    cancel_task(fid)
                move_files(ids, "removed")
                update_selected(ids, False)
                for fid in ids:
                    st.session_state.pop(f"sel_{fid}", None)
                st.session_state.upload_order_counter = 1
                st.session_state.batch_run_id = ""
                st.session_state.batch_file_ids = []
                st.session_state.batch_started_at = ""
                st.session_state.batch_preview_generated_for = ""
                st.session_state.batch_selected_file_id = ""
                st.session_state.batch_selected_run_id = ""
                st.session_state.batch_playlist_ids = []
                st.session_state.batch_playing = False
                st.session_state.batch_last_switch_ts = 0.0
                st.session_state.ocr_feedback = {}
                st.session_state.current_result = ""
                st.session_state.current_filename = ""
                st.session_state.current_result_token = uuid.uuid4().hex
                st.session_state.upload_clear_confirming = False
                st.session_state.op_banner = "已清除工作台待识别文件"
                add_operation("workbench_cleared", {"count": len(ids)})
                st.rerun()
        with c2:
            if st.button("取消", use_container_width=True, key="dlg_clear_cancel"):
                st.session_state.upload_clear_confirming = False
                st.rerun()

    @st.dialog("删除文件")
    def _dlg_delete_files():
        del_ids = [str(x) for x in (st.session_state.pending_delete_ids or []) if str(x)]
        name_map = {str(r.get("id") or ""): str(r.get("name") or "") for r in (removed_rows or [])}
        shown = [name_map.get(i, i) for i in del_ids][:12]
        st.write("确定要删除所选文件吗？")
        st.caption("将从本地文件夹中删除，且不可恢复。")
        if shown:
            with st.expander(f"查看将删除的文件（{len(del_ids)}）", expanded=False):
                st.text("\n".join(shown))
        dc1, dc2 = st.columns(2)
        with dc1:
            if st.button("确认", type="primary", use_container_width=True, key="dlg_delete_ok"):
                ok, err = hard_delete(del_ids, cancel_task=cancel_task, clear_tasks=clear_tasks)
                st.session_state.pending_delete_confirming = False
                st.session_state.pending_delete_ids = []
                if ok:
                    st.session_state.op_banner = f"已删除 {len(del_ids)} 个文件"
                    add_operation("delete_batch", {"count": len(del_ids)})
                    st.rerun()
                else:
                    st.error(f"删除失败：{err}")
        with dc2:
            if st.button("取消", use_container_width=True, key="dlg_delete_cancel"):
                st.session_state.pending_delete_confirming = False
                st.session_state.pending_delete_ids = []
                st.rerun()

    if st.session_state.upload_clear_confirming:
        _dlg_clear_workbench()
        st.stop()

    if st.session_state.pending_delete_confirming and st.session_state.pending_delete_ids:
        _dlg_delete_files()
        st.stop()

        batch_failed_ids = []
        if batch_ids_active:
            for fid in batch_ids_active:
                rr = st.session_state.upload_records.get(fid) or {}
                t = get_task(fid)
                status_raw = (t.status if t else rr.get("status", "")) or ""
                if status_raw in {"失败", "已取消"} or rr.get("status") in {"上传失败", "不支持"}:
                    batch_failed_ids.append(fid)

        bulk_col2, bulk_col3, bulk_col4 = st.columns([1, 1, 2])
        with bulk_col2:
            if st.button(
                "重试失败文件",
                disabled=batch_running or (not bool(batch_ids_active)) or (not bool(batch_failed_ids)),
            ):
                snap = list(st.session_state.get("batch_order_snapshot") or list(st.session_state.batch_file_ids or []))
                failed_set = set(batch_failed_ids)
                retry_ids = [fid for fid in snap if fid in failed_set]
                retry_records = [st.session_state.upload_records.get(fid) for fid in retry_ids]
                retry_records = [r for r in retry_records if r and r.get("supported")]

                if not retry_records:
                    st.error("没有可重试的失败文件（可能是不支持的格式或记录已被删除）。")
                    st.stop()

                clear_tasks([r["id"] for r in retry_records])
                task_config = dict(config)
                task_config["skip_cache"] = True
                for r in retry_records:
                    start_task(r["id"], dict(r), dict(task_config))
                add_operation("bulk_retry_failed", {"count": len(retry_records)})
                st.rerun()
        with bulk_col3:
            if st.button("全部取消", disabled=not any(get_task(r["id"]) and get_task(r["id"]).status in {"排队中", "识别中"} for r in ordered)):
                for r in ordered:
                    cancel_task(r["id"])
                add_operation("bulk_cancel", {})
                st.rerun()
        with bulk_col4:
            open_fs = st.button("打开全屏批量界面", disabled=not bool(st.session_state.get("batch_file_ids")), use_container_width=True)
            st.caption("提示：本次批量为强制重识别（不读取/不写入缓存）；结果会自动写入历史记录。")
            if open_fs:
                try:
                    st.query_params["view"] = "fullscreen"
                except Exception:
                    pass
                st.rerun()

        if st.session_state.batch_run_id and st.session_state.batch_file_ids:
            tracked = []
            for fid in st.session_state.batch_file_ids:
                rr = st.session_state.upload_records.get(fid)
                if rr:
                    tracked.append(rr)

            total = len(tracked)
            done_status = {"已完成", "已完成（缓存）", "失败", "已取消", "不支持", "上传失败"}
            done = 0
            current = ""
            success = 0
            waiting = 0
            failed_items = []
            for rr in tracked:
                stt = rr.get("status", "")
                if stt in done_status:
                    done += 1
                if stt in {"已完成", "已完成（缓存）"}:
                    success += 1
                if stt == "排队中":
                    waiting += 1
                if stt in {"失败", "已取消", "上传失败", "不支持"}:
                    t = get_task(rr.get("id", "")) if rr.get("id") else None
                    reason = rr.get("error", "") or (t.error if (t and t.error) else "") or stt
                    failed_items.append({"name": rr.get("name", ""), "reason": reason})
                if not current and stt in {"识别中", "排队中"}:
                    current = rr.get("name", "")

            overall = done / max(1, total)
            st.subheader("⏳ 批量识别进度")
            st.progress(overall)
            st.caption(f"当前文件：{current or '—'}")
            st.caption(f"已完成：{done}/{total}（{overall * 100:.0f}%） | 成功：{success} | 失败：{len(failed_items)}")
            st.caption(f"等待：{waiting} | 剩余：{max(0, total - done)}")
            st.caption(f"批次开始时间：{st.session_state.batch_started_at or '—'}")
            if failed_items:
                with st.expander(f"失败文件列表（{len(failed_items)}）", expanded=False):
                    for it in failed_items:
                        st.text_area(it.get("name", "文件"), value=it.get("reason", "") or "", height=90, disabled=True)

            if done == total and total > 0:
                snap = list(st.session_state.get("batch_order_snapshot") or [])
                if snap and list(st.session_state.batch_file_ids) != snap:
                    st.error("检测到排序异常：批次输出顺序与启动时快照不一致，请检查文件列表排序后重试。")
                else:
                    st.success("✅ 批量识别已完成")
            if batch_running:
                snap = list(st.session_state.get("batch_order_snapshot") or [])
                if snap:
                    current_ui = [r["id"] for r in ordered if r.get("id") in set(snap)]
                    if current_ui != snap:
                        for fid in list(st.session_state.batch_file_ids or []):
                            cancel_task(fid)
                        st.error("检测到排序异常：识别过程中页面排序发生变化，已中止识别。请确认排序后重新开始。")
                        st.stop()

        file_list_box = st.container(height=360)
        with file_list_box:
            for r in ordered:
                rid = r["id"]
                task = get_task(rid)
                status_raw = task.status if task else r.get("status", "等待中")
                status_text = "等待中" if status_raw == "排队中" else ("已完成" if status_raw == "已完成（缓存）" else status_raw)
                progress = float(task.progress) if task else 0.0

                row0, row1, row2, row3, row4, row5, row6, row7 = st.columns([0.7, 0.7, 3.4, 1.7, 0.6, 0.6, 0.9, 0.6])
                with row0:
                    sel_key = f"sel_{rid}"
                    if sel_key not in st.session_state:
                        st.session_state[sel_key] = bool(r.get("selected")) if r.get("supported") else False
                    st.checkbox("选中", key=sel_key, disabled=batch_running or (not bool(r.get("supported"))), label_visibility="collapsed")
                    prev_sel = bool(r.get("selected"))
                    new_sel = bool(st.session_state.get(sel_key))
                    r["selected"] = new_sel
                    if new_sel != prev_sel:
                        update_selected([rid], new_sel)
                with row1:
                    st.write(f"{int(r.get('order', 0))}")
                with row2:
                    st.write(r.get("name", ""))
                    st.caption(f"{format_size(int(r.get('size', 0)))} | {r.get('mime','')}")
                with row3:
                    st.write(status_text)
                    if status_raw in {"排队中", "识别中"}:
                        st.progress(progress)
                    if task and task.page_total:
                        st.caption(f"{task.page_index}/{task.page_total}")
                with row4:
                    if st.button("↑", key=f"up-{rid}", help="上移", disabled=batch_running or (int(r.get("order", 0)) <= 1), use_container_width=True):
                        cur = int(r.get("order", 0))
                        target = cur - 1
                        other = next((x for x in st.session_state.upload_records.values() if int(x.get("order", 0)) == target), None)
                        if other:
                            update_order({rid: target, str(other.get("id")): cur})
                        else:
                            update_order({rid: target})
                        add_operation("move_up", {"id": rid})
                        st.rerun()
                with row5:
                    if st.button("↓", key=f"down-{rid}", help="下移", disabled=batch_running or (int(r.get("order", 0)) >= len(ordered)), use_container_width=True):
                        cur = int(r.get("order", 0))
                        target = cur + 1
                        other = next((x for x in st.session_state.upload_records.values() if int(x.get("order", 0)) == target), None)
                        if other:
                            update_order({rid: target, str(other.get("id")): cur})
                        else:
                            update_order({rid: target})
                        add_operation("move_down", {"id": rid})
                        st.rerun()
                with row6:
                    can_retry = bool(r.get("supported")) and (status_raw in {"失败", "已取消"} or r.get("status") in {"上传失败"})
                    if st.button("重试", key=f"retry-{rid}", help="重试识别该文件", disabled=batch_running or (not can_retry), use_container_width=True):
                        clear_tasks([rid])
                        one_cfg = dict(config)
                        one_cfg["skip_cache"] = True
                        start_task(rid, dict(r), one_cfg)
                        add_operation("retry_single", {"id": rid, "name": r.get("name", "")})
                        st.rerun()
                with row7:
                    if st.button("×", key=f"del-{rid}", help="移除", use_container_width=True):
                        cancel_task(rid)
                        move_files([rid], "removed")
                        update_selected([rid], False)
                        st.session_state.pop(f"sel_{rid}", None)
                        add_operation("remove", {"id": rid, "name": r.get("name", "")})
                        st.rerun()

        auto_archive_ids = []
        for r in ordered:
            t = get_task(r["id"])
            if t and t.status in {"已完成", "已完成（缓存）"} and t.result:
                history_manager.save_history(r.get("name", "file"), t.result)
                add_operation("history_saved", {"id": r.get("id"), "name": r.get("name", "")})
                auto_archive_ids.append(str(r.get("id") or ""))

        auto_archive_ids = [x for x in auto_archive_ids if x]
        if auto_archive_ids:
            move_files(auto_archive_ids, "removed")
            update_selected(auto_archive_ids, False)
            for fid in auto_archive_ids:
                st.session_state.pop(f"sel_{fid}", None)
            add_operation("auto_archive", {"count": len(auto_archive_ids)})
            st.session_state.op_banner = f"已自动归档 {len(auto_archive_ids)} 个已识别文件"
            st.rerun()

    if st.session_state.batch_run_id and st.session_state.batch_file_ids:
        results_rows = []
        for fid in st.session_state.batch_file_ids:
            rr = get_record_any(fid)
            task = get_task(fid)
            status_raw = (task.status if task else rr.get("status", "")) or ""
            content = ""
            if status_raw in {"排队中"}:
                status_show = "等待中"
            elif status_raw in {"识别中"}:
                status_show = "识别中"
            elif status_raw in {"已完成", "已完成（缓存）"}:
                status_show = "已完成"
                content = (task.result if task else "") or ""
            elif status_raw in {"失败", "上传失败"}:
                status_show = "失败"
                content = rr.get("error", "") or (task.error if task else "")
            elif status_raw in {"已取消"}:
                status_show = "失败"
                content = rr.get("error", "") or (task.error if task else "") or "已取消"
            elif status_raw in {"不支持"}:
                status_show = "失败"
                content = "文件格式不支持 OCR（仅支持 PDF/图片）"
            else:
                status_show = status_raw
                content = ""

            ts = ""
            if task and task.finished_at:
                ts = datetime.datetime.fromtimestamp(task.finished_at).strftime("%Y-%m-%d %H:%M:%S")
            elif rr.get("uploaded_at"):
                ts = rr.get("uploaded_at")

            snippet = (markdown_to_visible_text(strip_file_name_headers(content)) if content else "").replace("\n", " ")
            if len(snippet) > 80:
                snippet = snippet[:79] + "…"

            q = {}
            if status_raw in {"已完成", "已完成（缓存）"}:
                q = quality_metrics(markdown_to_visible_text(strip_file_name_headers(content)))
            fb = st.session_state.ocr_feedback.get(fid, {})
            fb_status = fb.get("status", "")

            results_rows.append(
                {
                    "文件名": rr.get("name", ""),
                    "状态": status_show,
                    "时间戳": ts,
                    "结果摘要": snippet,
                    "质量分": q.get("score", ""),
                    "质量": q.get("level", ""),
                    "反馈": fb_status,
                    "_id": fid,
                }
            )

        done_status = {"已完成", "已完成（缓存）", "失败", "已取消", "不支持", "上传失败"}
        tracked_ids = [str(fid) for fid in st.session_state.batch_file_ids if str(fid)]
        total = len(tracked_ids)
        done = sum(1 for fid in tracked_ids if (get_task(fid) and get_task(fid).status in done_status) or (get_record_any(fid).get("status", "") in done_status))
        running = any((get_task(fid) and get_task(fid).status in {"排队中", "识别中"}) or (get_record_any(fid).get("status", "") in {"排队中", "识别中"}) for fid in tracked_ids)

        if results_rows:
            st.divider()
            st.header("📄 批量识别结果")
            st.caption(f"文件：{len(results_rows)} | 完成：{done}/{total} | 运行中：{'是' if running else '否'}")
            st.session_state.batch_selected_run_id, st.session_state.batch_selected_file_id = ensure_selected_file(
                batch_run_id=st.session_state.batch_run_id,
                selected_run_id=st.session_state.batch_selected_run_id,
                selected_file_id=st.session_state.batch_selected_file_id,
                file_ids_in_order=[r["_id"] for r in results_rows],
            )

            file_id_to_row = {r["_id"]: r for r in results_rows}
            options = [r["_id"] for r in results_rows]

            def build_md_for(fid: str) -> str:
                rr = get_record_any(fid)
                task = get_task(fid)
                status_raw = (task.status if task else rr.get("status", "")) or ""
                ts = ""
                if task and task.finished_at:
                    ts = datetime.datetime.fromtimestamp(task.finished_at).strftime("%Y-%m-%d %H:%M:%S")
                elif rr.get("uploaded_at"):
                    ts = rr.get("uploaded_at")
                if status_raw in {"已完成", "已完成（缓存）"} and task and task.result:
                    return str(task.result)
                reason = rr.get("error", "") or (task.error if task else "") or ""
                return f"## {rr.get('name','文件')}\n\n❌ 失败（{ts}）：{reason}\n"

            md_parts = []
            for fid in options:
                part = build_md_for(fid)
                if part is None:
                    continue
                part_s = str(part)
                if part_s == "":
                    continue
                md_parts.append(part_s)
            all_md = "\n\n".join(md_parts)
            all_visible = markdown_to_visible_text(strip_file_name_headers(all_md))
            op_col1, op_col2, op_col3 = st.columns([2, 2, 6])
            with op_col1:
                render_copy_button(all_visible, key=f"copy-all-visible-{st.session_state.batch_run_id}", label="复制所有预览结果", aria_label="复制所有预览结果到剪贴板")
            with op_col2:
                render_copy_button(all_md, key=f"copy-all-md-{st.session_state.batch_run_id}", label="复制所有MD内容", aria_label="复制所有MD内容到剪贴板")
            with op_col3:
                st.caption("提示：预览结果为纯文本；MD 内容为原始 Markdown。")

            render_download_buttons(all_md, f"ocr_batch_{st.session_state.batch_run_id}.md", key_prefix=f"batch-all-{st.session_state.batch_run_id}")

            results_overview = []
            for r in results_rows:
                row = {}
                for k, v in r.items():
                    if k == "_id":
                        continue
                    row[k] = "" if v is None else str(v)
                results_overview.append(row)
            st.dataframe(results_overview, use_container_width=True, hide_index=True, height=220)

            preview_col, result_col = st.columns([5, 7])
            with preview_col:
                def fmt(fid: str) -> str:
                    row = file_id_to_row.get(fid, {})
                    return f'{row.get("文件名","")} | {row.get("状态","")}'

                file_list_container = st.container(height=260)
                with file_list_container:
                    selected_id = st.radio(
                        "文件列表",
                        options=options,
                        key="batch_selected_file_id",
                        format_func=fmt,
                        label_visibility="collapsed",
                    )

                row = file_id_to_row.get(selected_id) or results_rows[0]
                fid = row["_id"]
                rr = get_record_any(fid)
                path = rr.get("path", "")
                mime_type = rr.get("mime", "")
                with st.container(height=320):
                    try:
                        if path and os.path.exists(path):
                            with open(path, "rb") as f:
                                b = f.read()
                            if rr.get("name", "").lower().endswith(".pdf") or mime_type == "application/pdf":
                                try:
                                    page_total = int(FileProcessor.pdf_page_count(b) or 0)
                                except Exception:
                                    page_total = 0
                                if page_total <= 1:
                                    img0 = FileProcessor.pdf_page_to_image(b, 0) if page_total == 1 else None
                                    if img0 is not None:
                                        st.image(img0, caption="PDF 预览", use_container_width=True)
                                else:
                                    def _on_pdf_page_change_batch():
                                        st.session_state.batch_selected_file_id = fid
                                    page_key = f"pdf_preview_page_batch_{fid}"
                                    cur = int(st.session_state.get(page_key, 1) or 1)
                                    if cur < 1:
                                        cur = 1
                                    if cur > page_total:
                                        st.session_state[page_key] = page_total
                                        cur = page_total
                                    left_space, mid, right_space = st.columns([2, 6, 2])
                                    with mid:
                                        label_col, input_col = st.columns([1, 7])
                                        with label_col:
                                            st.markdown(
                                                "<div style='text-align:right;padding-top:0.55rem;font-weight:600;'>页码</div>",
                                                unsafe_allow_html=True,
                                            )
                                        with input_col:
                                            page = st.number_input(
                                                "",
                                                min_value=1,
                                                max_value=page_total,
                                                value=cur,
                                                step=1,
                                                key=page_key,
                                                on_change=_on_pdf_page_change_batch,
                                                label_visibility="collapsed",
                                            )
                                    img = FileProcessor.pdf_page_to_image(b, int(page) - 1)
                                    if img is not None:
                                        st.image(img, caption=f"PDF 预览（第 {int(page)}/{page_total} 页）", use_container_width=True)
                            elif mime_type.startswith("image/"):
                                imgs = FileProcessor.process_image(b)
                                if imgs:
                                    st.image(imgs[0], caption="图片缩略图", use_container_width=True)
                            else:
                                st.caption("暂不支持该格式预览缩略图。")
                        else:
                            st.caption("文件未保存或已被删除。")
                    except Exception as e:
                        st.caption(f"预览失败：{e}")

            with result_col:
                row = file_id_to_row.get(selected_id) or results_rows[0]
                fid = row["_id"]
                rr = get_record_any(fid)
                task = get_task(fid)
                status_raw = (task.status if task else rr.get("status", "")) or ""
                ts = row.get("时间戳", "")
                st.subheader(f"🧾 当前预览：{row.get('文件名','文件')}")
                st.caption(f"状态：{row.get('状态','—')} | 时间：{ts or '—'}")

                if status_raw in {"已完成", "已完成（缓存）"} and task and task.result:
                    md = strip_file_name_headers(task.result)
                else:
                    reason = rr.get("error", "") or (task.error if task else "") or ""
                    md = f"## {row.get('文件名','文件')}\n\n❌ 失败（{ts}）：{reason}\n"

                render_download_buttons(md, row.get("文件名", "ocr_result.md") or "ocr_result.md", key_prefix=f"batch-one-{st.session_state.batch_run_id}-{fid}")

                visible = markdown_to_visible_text(strip_file_name_headers(md))
                q = quality_metrics(visible)
                info_col1, info_col2, info_col3 = st.columns([1, 1, 2])
                with info_col1:
                    st.metric("质量分", q.get("score", 0))
                with info_col2:
                    st.metric("质量", q.get("level", ""))
                with info_col3:
                    issues = q.get("issues", []) or []
                    st.caption("问题：" + ("；".join(issues) if issues else "—"))

                fb = st.session_state.ocr_feedback.get(fid, {})
                fb_key = f"fb_status_{fid}"
                if fb_key not in st.session_state:
                    st.session_state[fb_key] = fb.get("status", "")
                status_choice = st.selectbox(
                    "用户反馈",
                    options=["", "准确", "不准确"],
                    key=fb_key,
                    format_func=lambda x: "未反馈" if x == "" else x,
                )
                note_key = f"fb_note_{fid}"
                if note_key not in st.session_state:
                    st.session_state[note_key] = fb.get("note", "")
                if status_choice == "不准确":
                    st.text_input("反馈备注", key=note_key)
                    if st.button("提交反馈", key=f"fb_submit_{fid}"):
                        st.session_state.ocr_feedback[fid] = {
                            "status": "不准确",
                            "note": st.session_state.get(note_key, ""),
                            "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        }
                        add_operation("ocr_feedback", {"file_id": fid, "status": "不准确"})
                        st.toast("✅ 已记录反馈", icon="✅")
                        st.rerun()
                elif status_choice == "准确":
                    if st.button("提交反馈", key=f"fb_submit_{fid}"):
                        st.session_state.ocr_feedback[fid] = {
                            "status": "准确",
                            "note": "",
                            "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        }
                        add_operation("ocr_feedback", {"file_id": fid, "status": "准确"})
                        st.toast("✅ 已记录反馈", icon="✅")
                        st.rerun()

                token = f"batch-{st.session_state.batch_run_id}-{fid}"
                tab_preview, tab_source = st.tabs(["👁️ 渲染预览", "📝 源码"])
                with tab_source:
                    render_copy_button(md, key=f"batch-source-{token}")
                    ta_key = f"batch-source-ta-{token}"
                    prev_md = st.session_state.get(ta_key)
                    if prev_md is not None and prev_md != md:
                        add_operation(
                            "batch_source_sync",
                            {"file_id": fid, "prev_len": len(str(prev_md)), "new_len": len(str(md))},
                        )
                    if prev_md != md:
                        st.session_state[ta_key] = md
                    st.text_area("Markdown", value=md, height=520, disabled=True, key=ta_key)
                with tab_preview:
                    render_copy_button(markdown_to_visible_text(strip_file_name_headers(md)), key=f"batch-preview-{token}")
                    st.markdown(md, unsafe_allow_html=True)

    error_records = [r for r in st.session_state.upload_records.values() if r.get("error")]
    if error_records:
        with st.expander("查看错误日志", expanded=False):
            for r in sorted(error_records, key=lambda x: (x.get("status", ""), x.get("order", 0))):
                st.text_area(r.get("name", "文件"), value=r.get("error", ""), height=120, disabled=True)

    with st.expander("操作历史（最近 200 条）", expanded=False):
        for it in reversed(st.session_state.operation_history[-200:]):
            st.caption(f"{it.get('time','')} | {it.get('event','')} | {it.get('payload',{})}")

    if any(get_task(r["id"]) and get_task(r["id"]).status in {"排队中", "识别中"} for r in ordered):
        time.sleep(0.5)
        st.rerun()

    # Display Results (from Session State)
    if "current_result" in st.session_state:
        st.divider()
        st.header(f"📝 识别结果")
        
        full_report = st.session_state.current_result
        if "current_result_token" not in st.session_state:
            st.session_state.current_result_token = uuid.uuid4().hex
        render_download_buttons(full_report, st.session_state.get("current_filename", "ocr_result.md") or "ocr_result.md", key_prefix=f"current-{st.session_state.current_result_token}")
        if "source_editor_token" not in st.session_state:
            st.session_state.source_editor_token = ""
        if st.session_state.source_editor_token != st.session_state.current_result_token:
            st.session_state.source_editor = full_report
            st.session_state.source_editor_token = st.session_state.current_result_token

        # View Mode Toggle (Tabs)
        tab_preview, tab_source = st.tabs(["👁️ 渲染预览", "📝 源码编辑"])
        
        with tab_source:
             render_copy_button(
                 st.session_state.get("source_editor", full_report),
                 key=f"source-{st.session_state.current_result_token}",
             )

             edited_report = st.text_area("Markdown 源码 (可直接编辑)", height=600, key="source_editor")
             
             if edited_report != full_report:
                 st.session_state.current_result = edited_report
                 st.rerun()

        with tab_preview:
            render_copy_button(
                markdown_to_visible_text(strip_file_name_headers(st.session_state.current_result)),
                key=f"preview-{st.session_state.current_result_token}",
            )
            
            st.divider()
            st.markdown(st.session_state.current_result, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
