import os
import sys
import time
import threading
import traceback
import subprocess
import webbrowser
import atexit
import signal
import ctypes
from ctypes import wintypes
from urllib.request import urlopen


APP_NAME = "本地 OCR 工作台"
APP_HOST = "127.0.0.1"
APP_URL = f"http://{APP_HOST}:8501/"
APP_PORT = 8501
STARTUP_TIMEOUT_S = 30
WELCOME_SECONDS = 2.5


def _base_dir() -> str:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def _work_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _ensure_runtime_files():
    base = _base_dir()
    wd = _work_dir()
    os.makedirs(os.path.join(wd, ".streamlit"), exist_ok=True)
    src_cfg = os.path.join(base, ".streamlit", "config.toml")
    dst_cfg = os.path.join(wd, ".streamlit", "config.toml")
    if os.path.exists(src_cfg) and not os.path.exists(dst_cfg):
        try:
            with open(src_cfg, "rb") as rf, open(dst_cfg, "wb") as wf:
                wf.write(rf.read())
        except Exception:
            pass


def _write_log(message: str):
    try:
        log_path = os.path.join(_work_dir(), "exe.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(message.rstrip() + "\n")
    except Exception:
        pass


def _http_ready(url: str, timeout_s: float = 2.0) -> bool:
    try:
        with urlopen(url, timeout=float(timeout_s)) as resp:
            code = int(getattr(resp, "status", 200) or 200)
            return 200 <= code < 500
    except Exception:
        return False


def _kill_process_tree(pid: int):
    if not pid:
        return
    try:
        import psutil  # type: ignore

        p = psutil.Process(pid)
        for c in p.children(recursive=True):
            try:
                c.kill()
            except Exception:
                pass
        try:
            p.kill()
        except Exception:
            pass
        return
    except Exception:
        pass


def _create_kill_on_close_job():
    if os.name != "nt":
        return None
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    job = kernel32.CreateJobObjectW(None, None)
    if not job:
        return None

    class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", wintypes.LARGE_INTEGER),
            ("PerJobUserTimeLimit", wintypes.LARGE_INTEGER),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    class IO_COUNTERS(ctypes.Structure):
        _fields_ = [
            ("ReadOperationCount", wintypes.ULARGE_INTEGER),
            ("WriteOperationCount", wintypes.ULARGE_INTEGER),
            ("OtherOperationCount", wintypes.ULARGE_INTEGER),
            ("ReadTransferCount", wintypes.ULARGE_INTEGER),
            ("WriteTransferCount", wintypes.ULARGE_INTEGER),
            ("OtherTransferCount", wintypes.ULARGE_INTEGER),
        ]

    class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
            ("IoInfo", IO_COUNTERS),
            ("ProcessMemoryLimit", ctypes.c_size_t),
            ("JobMemoryLimit", ctypes.c_size_t),
            ("PeakProcessMemoryUsed", ctypes.c_size_t),
            ("PeakJobMemoryUsed", ctypes.c_size_t),
        ]

    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    info.BasicLimitInformation.LimitFlags = 0x00002000
    ok = kernel32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info))
    if not ok:
        try:
            kernel32.CloseHandle(job)
        except Exception:
            pass
        return None
    return job
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], check=False, capture_output=True)
    except Exception:
        pass


def _kill_listeners_on_port(port: int):
    try:
        import psutil  # type: ignore
    except Exception:
        return
    try:
        for c in psutil.net_connections(kind="tcp"):
            if int(getattr(c, "laddr", (None, None))[1] or 0) != int(port):
                continue
            pid = int(getattr(c, "pid", 0) or 0)
            if pid:
                try:
                    psutil.Process(pid).kill()
                except Exception:
                    pass
    except Exception:
        pass


def run_server():
    os.environ.setdefault("STREAMLIT_GLOBAL_DEVELOPMENT_MODE", "false")
    os.environ.setdefault("STREAMLIT_SERVER_HEADLESS", "true")
    os.environ.setdefault("STREAMLIT_BROWSER_GATHER_USAGE_STATS", "false")
    os.environ.setdefault("STREAMLIT_SERVER_ADDRESS", APP_HOST)
    os.environ.setdefault("STREAMLIT_SERVER_PORT", str(APP_PORT))

    _ensure_runtime_files()
    os.chdir(_work_dir())

    try:
        from streamlit.web import cli as stcli
    except Exception:
        _write_log("import streamlit failed")
        _write_log(traceback.format_exc())
        raise

    sys.argv = [
        "streamlit",
        "run",
        os.path.join(_base_dir(), "app.py"),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--server.address",
        APP_HOST,
        "--server.port",
        str(APP_PORT),
    ]
    _write_log("launch server")
    stcli.main()


INDEX_HTML = f"""
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>{APP_NAME}</title>
  <style>
    :root {{
      --bg: #0b0f14;
      --panel: rgba(255,255,255,0.06);
      --panel2: rgba(255,255,255,0.10);
      --text: rgba(255,255,255,0.92);
      --muted: rgba(255,255,255,0.70);
      --ok: #23c55e;
      --warn: #f59e0b;
      --err: #ef4444;
      --accent: #60a5fa;
      --shadow: 0 10px 30px rgba(0,0,0,0.35);
      --radius: 14px;
      --mono: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
      --sans: "Segoe UI", "Microsoft YaHei UI", system-ui, -apple-system, Arial, sans-serif;
    }}
    @media (prefers-color-scheme: light) {{
      :root {{
        --bg: #f7f7fb;
        --panel: rgba(0,0,0,0.05);
        --panel2: rgba(0,0,0,0.08);
        --text: rgba(0,0,0,0.92);
        --muted: rgba(0,0,0,0.62);
        --shadow: 0 10px 30px rgba(0,0,0,0.12);
      }}
    }}
    html, body {{
      height: 100%;
      margin: 0;
      background: radial-gradient(1200px 800px at 15% 10%, rgba(96,165,250,0.20), transparent 55%),
                  radial-gradient(900px 600px at 85% 20%, rgba(34,197,94,0.18), transparent 55%),
                  var(--bg);
      color: var(--text);
      font-family: var(--sans);
      overflow: hidden;
    }}
    .root {{
      height: 100%;
      display: grid;
      grid-template-rows: auto 1fr auto;
      gap: 12px;
      padding: 14px 14px 10px 14px;
      box-sizing: border-box;
    }}
    .top {{
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      border-radius: var(--radius);
      background: linear-gradient(180deg, var(--panel), rgba(255,255,255,0.03));
      box-shadow: var(--shadow);
      backdrop-filter: blur(10px);
    }}
    .logo {{
      width: 34px;
      height: 34px;
      border-radius: 10px;
      background: linear-gradient(135deg, rgba(96,165,250,0.9), rgba(34,197,94,0.75));
      display: grid;
      place-items: center;
      font-weight: 800;
      color: rgba(0,0,0,0.75);
      user-select: none;
    }}
    .title {{
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
      flex: 1;
    }}
    .title .name {{
      font-size: 15.5px;
      font-weight: 800;
      letter-spacing: 0.2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    .title .sub {{
      font-size: 12.5px;
      color: var(--muted);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      font-family: var(--mono);
    }}
    .status {{
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
      justify-content: flex-end;
    }}
    .pill {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 7px 10px;
      border-radius: 999px;
      background: var(--panel2);
      color: var(--text);
      font-size: 12.5px;
    }}
    .dot {{
      width: 9px;
      height: 9px;
      border-radius: 99px;
      background: var(--warn);
      box-shadow: 0 0 0 4px rgba(245,158,11,0.18);
      transition: all 240ms ease;
    }}
    .dot.ok {{
      background: var(--ok);
      box-shadow: 0 0 0 4px rgba(34,197,94,0.18);
    }}
    .dot.err {{
      background: var(--err);
      box-shadow: 0 0 0 4px rgba(239,68,68,0.18);
    }}
    .progress {{
      height: 6px;
      width: 160px;
      border-radius: 99px;
      overflow: hidden;
      background: rgba(255,255,255,0.12);
      position: relative;
    }}
    .bar {{
      height: 100%;
      width: 40%;
      border-radius: 99px;
      background: linear-gradient(90deg, rgba(96,165,250,0.0), rgba(96,165,250,0.95), rgba(34,197,94,0.95), rgba(34,197,94,0.0));
      animation: slide 1.2s linear infinite;
    }}
    @keyframes slide {{
      from {{ transform: translateX(-60%); }}
      to {{ transform: translateX(220%); }}
    }}
    .main {{
      border-radius: var(--radius);
      background: rgba(0,0,0,0.18);
      box-shadow: var(--shadow);
      overflow: hidden;
      position: relative;
    }}
    iframe {{
      width: 100%;
      height: 100%;
      border: 0;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 240ms ease, transform 240ms ease;
    }}
    iframe.ready {{
      opacity: 1;
      transform: translateY(0);
    }}
    .overlay {{
      position: absolute;
      inset: 0;
      display: grid;
      place-items: center;
      padding: 18px;
      box-sizing: border-box;
    }}
    .card {{
      width: min(680px, 94vw);
      border-radius: var(--radius);
      background: linear-gradient(180deg, var(--panel), rgba(255,255,255,0.04));
      box-shadow: var(--shadow);
      padding: 16px 16px 14px 16px;
      backdrop-filter: blur(12px);
    }}
    .card h2 {{
      margin: 0 0 8px 0;
      font-size: 16px;
    }}
    .card p {{
      margin: 0;
      color: var(--muted);
      font-size: 13px;
      line-height: 1.6;
    }}
    .row {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-top: 10px;
      flex-wrap: wrap;
    }}
    .btn {{
      appearance: none;
      border: 0;
      border-radius: 12px;
      padding: 10px 12px;
      font-size: 13px;
      font-weight: 700;
      background: rgba(255,255,255,0.10);
      color: var(--text);
      cursor: pointer;
      transition: transform 120ms ease, background 120ms ease;
    }}
    .btn:hover {{
      transform: translateY(-1px);
      background: rgba(255,255,255,0.14);
    }}
    .btn.primary {{
      background: linear-gradient(135deg, rgba(96,165,250,0.95), rgba(34,197,94,0.85));
      color: rgba(0,0,0,0.78);
    }}
    .btn.danger {{
      background: rgba(239,68,68,0.18);
      color: var(--text);
    }}
    .footer {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 10px 12px;
      border-radius: var(--radius);
      background: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02));
      box-shadow: var(--shadow);
      backdrop-filter: blur(10px);
    }}
    .footer .left {{
      display: flex;
      align-items: center;
      gap: 10px;
      color: var(--muted);
      font-size: 12.5px;
      font-family: var(--mono);
    }}
    .footer .actions {{
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      justify-content: flex-end;
    }}
  </style>
</head>
<body>
  <div class="root">
    <div class="top">
      <div class="logo">OCR</div>
      <div class="title">
        <div class="name">{APP_NAME}</div>
        <div class="sub" id="sub">{APP_URL}</div>
      </div>
      <div class="status">
        <div class="pill"><span class="dot" id="dot"></span><span id="statusText">欢迎使用</span></div>
        <div class="pill"><div class="progress"><div class="bar" id="bar"></div></div></div>
      </div>
    </div>
    <div class="main">
      <iframe id="frame" title="app"></iframe>
      <div class="overlay" id="overlay">
        <div class="card">
          <h2 id="overlayTitle">欢迎使用</h2>
          <p id="overlayDesc">正在准备运行环境，请稍候…</p>
          <div class="row" id="overlayRow">
            <button class="btn primary" onclick="openBrowser()">打开系统浏览器</button>
            <button class="btn" onclick="restartService()">重启服务</button>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">
      <div class="left">
        <span>内存</span><span id="mem">—</span>
      </div>
      <div class="actions">
        <button class="btn" onclick="restartService()">重启服务</button>
        <button class="btn" onclick="openBrowser()">打开系统浏览器</button>
        <button class="btn danger" onclick="exitApp()">退出程序</button>
      </div>
    </div>
  </div>
  <script>
    function safeCall(fn) {{
      try {{ return fn(); }} catch (e) {{ return null; }}
    }}
    function setStatus(text, level) {{
      const dot = document.getElementById('dot');
      const st = document.getElementById('statusText');
      st.textContent = text || '';
      dot.classList.remove('ok','err');
      if (level === 'ok') dot.classList.add('ok');
      if (level === 'err') dot.classList.add('err');
    }}
    function setOverlay(title, desc, showActions) {{
      document.getElementById('overlayTitle').textContent = title || '';
      document.getElementById('overlayDesc').textContent = desc || '';
      document.getElementById('overlayRow').style.display = showActions ? 'flex' : 'none';
      document.getElementById('overlay').style.display = 'grid';
    }}
    function hideOverlay() {{
      document.getElementById('overlay').style.display = 'none';
    }}
    function setFrame(url) {{
      const f = document.getElementById('frame');
      f.src = url;
    }}
    function setReady(url) {{
      setFrame(url);
      const f = document.getElementById('frame');
      f.classList.add('ready');
      hideOverlay();
      setStatus('服务已就绪', 'ok');
    }}
    function setError(msg) {{
      setStatus('启动失败', 'err');
      setOverlay('服务启动失败', msg || '未知错误', true);
    }}
    function setMem(text) {{
      document.getElementById('mem').textContent = text || '—';
    }}
    function openBrowser() {{
      safeCall(() => window.pywebview?.api?.open_browser());
    }}
    function restartService() {{
      setStatus('正在重启服务…', 'warn');
      setOverlay('正在重启服务', '请稍候…', false);
      safeCall(() => window.pywebview?.api?.restart_service());
    }}
    function exitApp() {{
      const ok = confirm('确认退出？将先关闭服务进程。');
      if (!ok) return;
      safeCall(() => window.pywebview?.api?.exit_app());
    }}
    window.__ocrwb = {{ setStatus, setReady, setError, setMem, setOverlay }};
  </script>
</body>
</html>
"""


class DesktopController:
    def __init__(self):
        self._lock = threading.Lock()
        self._proc: subprocess.Popen | None = None
        self._closing = False
        self._window = None
        self._job = _create_kill_on_close_job()
        atexit.register(self._stop_server)

    def bind_window(self, window):
        self._window = window

    def _js(self, code: str):
        w = self._window
        if not w:
            return
        try:
            w.evaluate_js(code)
        except Exception:
            pass

    def _set_status(self, text: str, level: str = "warn"):
        self._js(f"window.__ocrwb?.setStatus?.({text!r}, {level!r});")

    def _set_overlay(self, title: str, desc: str, show_actions: bool):
        self._js(f"window.__ocrwb?.setOverlay?.({title!r}, {desc!r}, {bool(show_actions)!r});")

    def _set_ready(self):
        self._js(f"window.__ocrwb?.setReady?.({APP_URL!r});")

    def _set_error(self, message: str):
        self._js(f"window.__ocrwb?.setError?.({message!r});")

    def _set_mem(self, message: str):
        self._js(f"window.__ocrwb?.setMem?.({message!r});")

    def _spawn_server(self) -> subprocess.Popen:
        if getattr(sys, "frozen", False):
            cmd = [sys.executable, "--server"]
        else:
            cmd = [sys.executable, os.path.abspath(__file__), "--server"]
        flags = 0
        try:
            flags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
        except Exception:
            flags = 0
        p = subprocess.Popen(cmd, cwd=_work_dir(), creationflags=flags)
        try:
            if self._job and getattr(p, "_handle", None):
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.AssignProcessToJobObject(self._job, wintypes.HANDLE(p._handle))
        except Exception:
            pass
        return p

    def _stop_server(self):
        with self._lock:
            p = self._proc
            self._proc = None
        if not p:
            _kill_listeners_on_port(APP_PORT)
            return
        try:
            if p.poll() is None:
                p.terminate()
        except Exception:
            pass
        t0 = time.time()
        while time.time() - t0 < 6.0:
            if p.poll() is not None:
                break
            time.sleep(0.2)
        if p.poll() is None:
            _kill_process_tree(int(getattr(p, "pid", 0) or 0))
        _kill_listeners_on_port(APP_PORT)

    def _start_server_async(self):
        def worker():
            if self._closing:
                return
            self._set_status("正在启动服务…", "warn")
            self._set_overlay("正在启动服务", "正在启动本地服务并加载界面…", False)
            try:
                self._stop_server()
                proc = self._spawn_server()
                with self._lock:
                    self._proc = proc
            except Exception as e:
                self._set_error(f"无法启动服务进程：{e}")
                return

            deadline = time.time() + float(STARTUP_TIMEOUT_S)
            last = ""
            while time.time() < deadline:
                if self._closing:
                    return
                with self._lock:
                    proc = self._proc
                if proc and proc.poll() is not None:
                    code = proc.returncode
                    self._set_error(f"服务进程异常退出（code={code}）。请点击“重启服务”重试。")
                    return
                if _http_ready(APP_URL, timeout_s=1.5):
                    self._set_ready()
                    return
                if last != "等待服务响应…":
                    self._set_status("等待服务响应…", "warn")
                    last = "等待服务响应…"
                time.sleep(0.4)

            self._set_error("服务启动超时（30 秒）。可能端口被占用或模型服务连接异常。可点击“重启服务”重试。")

        threading.Thread(target=worker, daemon=True).start()

    def _mem_loop(self):
        try:
            import psutil  # type: ignore
        except Exception:
            psutil = None
        while True:
            if self._closing:
                return
            try:
                if psutil:
                    p = psutil.Process(os.getpid())
                    rss = int(getattr(p.memory_info(), "rss", 0) or 0)
                    mb = rss / (1024 * 1024)
                    self._set_mem(f"{mb:.0f} MB")
                else:
                    self._set_mem("—")
            except Exception:
                pass
            time.sleep(1.0)

    def on_window_loaded(self):
        def boot():
            self._set_status("欢迎使用", "warn")
            self._set_overlay("欢迎使用", "正在准备运行环境，请稍候…", False)
            time.sleep(float(WELCOME_SECONDS))
            self._start_server_async()
            threading.Thread(target=self._mem_loop, daemon=True).start()

        threading.Thread(target=boot, daemon=True).start()

    def restart_service(self):
        self._start_server_async()

    def open_browser(self):
        try:
            webbrowser.open(APP_URL)
        except Exception:
            pass

    def exit_app(self):
        self._closing = True
        try:
            self._set_status("正在退出…", "warn")
        except Exception:
            pass

        def worker():
            try:
                self._stop_server()
            finally:
                try:
                    import webview  # type: ignore

                    webview.destroy_window()
                except Exception:
                    os._exit(0)

        threading.Thread(target=worker, daemon=True).start()

    def on_window_closing(self):
        self._closing = True
        try:
            self._stop_server()
        except Exception:
            pass


def run_desktop():
    try:
        import webview  # type: ignore
    except Exception as e:
        _write_log(f"import webview failed: {e}")
        webbrowser.open(APP_URL)
        raise

    controller = DesktopController()
    window = webview.create_window(
        APP_NAME,
        html=INDEX_HTML,
        width=1280,
        height=820,
        resizable=True,
        js_api=controller,
    )
    controller.bind_window(window)
    window.events.loaded += lambda: controller.on_window_loaded()
    window.events.closing += lambda: controller.on_window_closing()
    webview.start(http_server=True)


def main():
    if "--server" in sys.argv:
        run_server()
        return
    def _sig(_signum, _frame):
        try:
            os._exit(0)
        except Exception:
            raise SystemExit(0)
    try:
        signal.signal(signal.SIGINT, _sig)
        signal.signal(signal.SIGTERM, _sig)
    except Exception:
        pass
    run_desktop()


if __name__ == "__main__":
    main()
