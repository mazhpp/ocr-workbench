param(
  [string]$FilePath,
  [string]$PfxPath = "",
  [string]$PfxPassword = "",
  [string]$TimestampUrl = "http://timestamp.digicert.com"
)

$ErrorActionPreference = "Stop"

if (-Not (Test-Path $FilePath)) {
  Write-Error "File not found: $FilePath"
}

if ($PfxPath -and (Test-Path $PfxPath)) {
  $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
  $cert.Import($PfxPath, $PfxPassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet)
  & signtool sign /f $PfxPath /p $PfxPassword /fd SHA256 /tr $TimestampUrl /td SHA256 $FilePath
  Write-Host "Signed with PFX: $FilePath"
} else {
  try {
    $certs = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.HasPrivateKey }
    if ($certs.Count -gt 0) {
      Set-AuthenticodeSignature -FilePath $FilePath -Certificate $certs[0] -TimestampServer $TimestampUrl | Out-Null
      Write-Host "Signed with CurrentUser certificate: $FilePath"
    } else {
      Write-Warning "No certificate found. Skipped signing."
    }
  } catch {
    Write-Warning "Signing failed: $_"
  }
}
