import os

# Default Configuration
DEFAULT_API_BASE = "http://localhost:1234/v1"
DEFAULT_API_KEY = "lm-studio"
DEFAULT_MODEL = "local-model"

DEFAULT_API_BASE_LMSTUDIO = DEFAULT_API_BASE
DEFAULT_API_BASE_OLLAMA = "http://localhost:11434"
DEFAULT_API_BASE_OPENAI = "https://api.openai.com/v1"

# Supported Models (Display names)
SUPPORTED_MODELS = [
    "Qwen2-VL-7B-Instruct",
    "Llama-3.2-Vision",
    "local-model",
]

# Prompt Templates
PROMPTS = {
    "通用模式": """请识别图片中的文字并输出结果。

智能格式识别：
1. 结合视觉排版特征（位置、缩进、对齐、加粗/斜体倾向、行距差异）判断是否存在结构化元素：标题、列表、表格、强调、代码块。
2. 对模糊格式采用保守策略：宁可少加标记，不要错加标记。

动态输出规则：
1. 纯文本内容：
   - 保持原始换行与空格。
   - 可在不损失信息的前提下合并明显断裂的段落（把同一段中被硬换行切断的行合并）。
2. 结构化内容（仅在确有把握时使用 Markdown）：
   - 标题：使用 # 到 ###### 的层级。
   - 列表：使用有序(1. )/无序(- )列表，保留缩进层级。
   - 表格：使用 Markdown 表格语法并对齐。
   - 强调：用 **加粗** 或 *斜体* 表示。
   - 代码块：仅在确认是代码/配置/JSON/命令等需要等宽展示时，用 ```language ... ``` 包裹，并尽量识别 language（如 json/yaml/bash/python）。

严格限制：
- 不要添加任何解释性前缀/后缀，只输出识别内容本身。
- 不得在最外层使用 ```markdown 或 ``` 将整个输出包裹为代码块。
- 必须保留所有特殊字符和 Unicode 字符，保留原始层级关系与技术符号（如数学公式、JSON 等）。""",
    
    "表格提取": "请提取图片中的表格，并将其还原为 Markdown 表格格式。确保列对齐准确。如果表格周围有文字，请将其作为普通段落保留。",
    
    "文档校对": """请识别图片中的文字并输出结果。

规则：
1. 优先输出纯文本；仅在确有把握表达结构时使用 Markdown（标题/列表/表格/引用/强调）。
2. 代码块仅用于需要等宽展示的内容（代码/配置/JSON/命令等），使用 ```language 包裹并确保闭合。
3. 禁止将整个输出用 ```markdown 或 ``` 包裹。
4. 不要添加解释性文字，只输出识别内容本身；保留特殊字符与 Unicode 字符。
5. 对模糊格式采取保守策略，避免误判导致错误 Markdown。""",
}
